import game_framework


import logo

game_framework.run(logo)