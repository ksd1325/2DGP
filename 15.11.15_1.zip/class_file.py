


from pico2d import*
from read_or_write import*


import block
import fake





class Guy:

    guy_state_table = {
        'True' : True,
        'False': False
    }
    global checkbar
    global guy_data



    def __init__(self, choice_data):

        guy_data = read()
        self.guyimage = load_image('Guy(25X23).png')
        self.frame = guy_data[choice_data]['frame']
        self.state = guy_data[choice_data]['state']
        self.canmove = Guy.guy_state_table[guy_data[choice_data]['canmove']]
        self.x, self.y = guy_data[choice_data]['x'], guy_data[choice_data]['y']
        self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
        self.body = [self.x - 30, self.y + 11, self.x + 10, self.y - 20]
        self.step = Guy.guy_state_table[guy_data[choice_data]['step']]
        self.stage = guy_data[choice_data]['stage']
        print(self.stage)
        self.move = guy_data[choice_data]['move']
        self.jump = Guy.guy_state_table[guy_data[choice_data]['jump']]
        self.ablejump = guy_data[choice_data]['ablejump']
        self.height = guy_data[choice_data]['height']

    def draw(self):
        self.guyimage.clip_draw(25 * self.frame, self.state * 23, 25, 23, self.x, self.y)
    def update(self):
        if self.state == 0:
            self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
            self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        elif self.state == 1:
            self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
            self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        for p in range(0, 26):
            for q in range(0, 19):
                if p <= 24 and block.Maparr[self.stage - 1][p+1][q][0] == 1:
                    if (self.move == 1 and self.body[0] < block.Maparr[self.stage - 1][p+1][q][3] + 16 and self.body[2]+5 > block.Maparr[self.stage - 1][p+1][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p+1][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p+1][q][2] + 16):
                        #print("collision")
                        if self.canmove == True:
                            self.x -= 5
                        elif self.canmove == False:
                            self.x = block.Maparr[self.stage - 1][p+1][q][1] + 16 - 15
                        self.canmove = False
                    else:
                        self.canmove = True
                elif block.Maparr[self.stage - 1][p-1][q][0] == 1 and p >= 0:
                    if (self.move == 2 and self.body[0]- 10 < block.Maparr[self.stage - 1][p-1][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p-1][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p-1][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p-1][q][2] + 16):
                        #print("collision")
                        if self.canmove == True:
                            self.x += 5
                        elif self.canmove == False:
                            self.x = block.Maparr[self.stage - 1][p-1][q][3] + 16 + 15
                        self.canmove = False

                    else:
                        self.canmove = True
                        if (self.move == 2 and block.Maparr[self.stage - 1][p][q][0] == 1 and self.body[0]- 5 < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p][q][2] + 16) :
                            self.x = block.Maparr[self.stage - 1][p][q][3] + 16 + 15
                            self.canmove = False

                if block.Maparr[self.stage - 1][p][q][0] == 1:
                    if (self.body[0] < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p][q][2] + 16):
                        #print("col",jump)
                        self.step = True
                        if self.move == 1:
                            self.x += 5
                        elif self.move == 2:
                            self.x -= 5
                        if ( self.y >= block.Maparr[self.stage - 1][p][q][2] + 16  and self.jump == False):
                            self.y = block.Maparr[self.stage - 1][p][q][2] + 27
                        elif ( self.y <= block.Maparr[self.stage - 1][p][q][2] -16  and self.jump):
                            self.y = block.Maparr[self.stage - 1][p][q][2] - 27
                            self.jump = False
                            self.step = False
                            if(self.stage == 4 and p == 1 and q == 8):
                                fake.Fake4[0][0] = 1
                            elif self.stage == 4 and p == 2 and q == 10:
                                fake.Fake4[1][0] = 1

                elif block.Maparr[self.stage - 1][p][q - 1][0] != 1:
                    if (self.body[0] + 18 < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2]- 19 > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] - 1 < block.Maparr[self.stage - 1][p][q][2] + 16):
                        self.step = False


class Dialog:
    def __init__(self):
        self.diaimage = load_image('Dialog.png')
        self.dialog = 0

    def show(self,font):
        if self.dialog != 0:
            self.diaimage.draw(400, 150)
            if self.dialog == 1:
                font.draw(200, 180, 'Hello, I am Programmer K.')
            elif self.dialog == 2:
                font.draw(200, 180, 'There are too Much Error and Bug.')
            elif self.dialog == 3:
                font.draw(200, 180, 'Please Help me.')
            elif self.dialog == 4:
                font.draw(200, 180, 'You can Shot press button Z.')
                font.draw(200, 150, 'And can Jump press button X.')
            elif self.dialog == 5:
                font.draw(200, 180, 'If you want to Save,')
                font.draw(200, 150, 'press UP in Save Zone.')
            elif self.dialog == 6:
                font.draw(200, 180, 'You can Restart press button R.')
            elif self.dialog == 7:
                font.draw(200, 180, 'Gook LUCK, GUY.')
            elif self.dialog == 8:
                self.dialog = 0


class Bullet:
    Bulletimage = None
    def __init__(self, x, y, state, stage):
        self.x = x
        self.y = y + 1
        self.length = 0
        self.direction = state
        self.stage = stage
        if Bullet.Bulletimage == None:
            Bullet.Bulletimage = load_image('Bullet(4x4).png')
    def update(self, bullet):
        if self.direction == 0:
            self.length -= 20
            self.x -= 20
            if self.length < -500:
                bullet.remove(self)
        elif self.direction == 1:
            self.length += 20
            self.x += 20
            if self.length > 500:
                bullet.remove(self)
        for p in range(26):
            for q in range(19):
                if self.x >= block.Maparr[self.stage - 1][p][q][1] and self.x <= block.Maparr[self.stage - 1][p][q][3] + 32 and self.y <= block.Maparr[self.stage - 1][p][q][2] + 16 and self.y >= block.Maparr[self.stage - 1][p][q][4] + 16 and block.Maparr[self.stage - 1][p][q][0] == 1:
                    bullet.remove(self)
        self.Bulletimage.draw(self.x, self.y)
