

from class_file import*
from pico2d import*
from read_or_write import*
import game_framework

import block
import fake
import morejumping
import stage2
import stage4
name = "stage3"

#open_canvas()

#Bulletimage = None
def update():
    pass
def pause():
    pass
def resume():
    pass
def draw():
    pass
def exit():
    global guy
    global dialogue
    global bullet
    global enemy
    global map3
    global savezone
    global blank
    global Thorn
    del(dialogue)
    del(bullet)
    del(enemy)
    del(Thorn)
    del(map3)
    del(savezone)
    del(blank)
    del(guy)
    pass
def enter():
    global guy
    global bar
    global font
    global blank
    global Thorn
    global Itemimage
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map3
    global running
    global candia


    blank = load_image('blank.png')
    line = load_image('Line.png')
    Thorn = load_image('Thorn(32x32).png')
    Itemimage = load_image('Morejumping(10x10).png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy('guy_playing')
    reset_guy_playing()
    dialogue = Dialog()
    enemy = Enemy()
    bullet = []
    candia = 0
    showboundary = 0
    map3 = load_image('3.png')


    font = load_font('HYTBRB.TTF')
    main()




class Bar():
    Barimage = None
    def __init__(self):
        self.checkbar = 0
        self.bar_x = 704
        self.bar_y = 100
        if Bar.Barimage == None:
            Bar.Barimage = load_image('Bar(128x10).png')

    def update(self):
        if guy.stage == 4 or guy.stage == 5 or guy.stage == 6:
            if bar.checkbar == 1:
                bar.bar_y += 2
                if guy.step == True and guy.x < bar.bar_x + 64 and guy.x > bar.bar_x - 64 and guy.y >= bar.bar_y + 10 and guy.y < bar.bar_y + 30:
                    guy.y += 2
            if guy.stage == 6 and bar.bar_y > block.Maparr[5][0][9][2]:
                bar.checkbar = 2
            bar.Barimage.draw(bar.bar_x, bar.bar_y)

class Enemy():
    Enemyimage = None

    def __init__(self):
        self.stage = 1
        self.ex = 19 * 32 + 16
        self.ey = 2 * 32 + 16
        self.box = [self.ex - 15, self.ey + 15, self.ex + 15, self.ey - 15]
        self.frame = 0
        self.state = 0
        self.count = 0
        self.crash = 0
        if Enemy.Enemyimage == None:
            Enemy.Enemyimage = load_image('Enemy(30x30).png')

    def update(self):
        if(self.stage != guy.stage):
            self.stage = guy.stage
            self.count = 0
            self.state = 0
            self.frame = 0
            self.crash = 0
        if self.crash == 0:
            if self.count == 0:
                if self.stage == 2:
                    self.ex = 19 * 32 + 16
                    self.ey = 2 * 32 + 16
                elif self.stage == 3:
                    self.ex = 21 * 32 + 16
                    self.ey = 16 * 32 + 16
                elif self.stage == 4:
                    self.ex = 8 * 32 + 16
                    self.ey = 9 * 32 + 16
                elif self.stage == 11:
                    self.ex = 8 * 32 + 16
                    self.ey = 7 * 32 + 16

                self.count = 1
            if self.state == 0:
                self.ex += 5
                self.frame = (self.frame + 1) % 2
                if self.ex > 23 * 32 + 16 and self.stage == 2:
                    self.state = 1
                elif self.ex > 21 * 32 + 16 and self.stage == 3:
                    self.state = 1
                elif self.ex > 12 * 32 + 16 and self.stage == 4:
                    self.state = 1
                elif self.ex > 10 * 32 + 16 and self.stage == 11:
                    self.state = 1
            elif self.state == 1:
                self.ex -= 5
                self.frame = (self.frame + 1) % 2
                if self.ex < 13 * 32 + 16 and self.stage == 2:
                    self.state = 0
                elif self.ex < 16 * 32 + 16 and self.stage == 3:
                    self.state = 0
                elif self.ex < 6 * 32 + 16 and self.stage == 4:
                    self.state = 0
                elif self.ex < 5 * 32 + 16 and self.stage == 11:
                    self.state = 0

            self.box = [self.ex - 15, self.ey + 15, self.ex + 15, self.ey - 15]
        for i in bullet:
            if i.x >= self.box[0] and i.x <= self.box[2] and i.y <= self.box[1] and i.y >= self.box[3] and self.crash == 0:
                bullet.remove(i)
                self.crash = 1
        if self.crash == 1:
            if self.count == 1:
                self.frame = 1
                self.count = 2
            self.frame += 1
            if self.frame > 4:
                self.state = 2

        if self.state < 2 and (self.stage == 2 or self.stage == 3 or self.stage == 4 or self.stage == 11):
            self.Enemyimage.clip_draw(30 * self.frame, 30 * self.state, 30, 30, self.ex, self.ey)


def morejump():
    if guy.stage == 3:
        for p in range(5):
            for q in range(4):
                if morejumping.item[p][0] == 0:
                    Itemimage.draw(morejumping.item[p][1], morejumping.item[p][2])
                elif morejumping.item[p][0] == 1:
                    morejumping.item[p][3] += 1
                    if morejumping.item[p][3] == 100:
                        morejumping.item[p][3] = 0
                        morejumping.item[p][0] = 0
                if morejumping.item[p][0] == 0 and morejumping.item[p][1] >= guy.body[0] and  morejumping.item[p][1] <= guy.body[2] and  morejumping.item[p][2] >= guy.body[3] and  morejumping.item[p][2] <= guy.body[1] :
                    morejumping.item[p][0] = 1
                    guy.ablejump = 1
    elif guy.stage == 4:
        if morejumping.item[5][0] == 0:
            Itemimage.draw(morejumping.item[5][1], morejumping.item[5][2])
        elif morejumping.item[5][0] == 1:
            morejumping.item[5][3] += 1
            if morejumping.item[5][3] == 100:
                morejumping.item[5][3] = 0
                morejumping.item[5][0] = 0
        if morejumping.item[5][0] == 0 and morejumping.item[5][1] >= guy.body[0] and  morejumping.item[5][1] <= guy.body[2] and  morejumping.item[5][2] >= guy.body[3] and  morejumping.item[5][2] <= guy.body[1] :
            morejumping.item[5][0] = 1
            guy.ablejump = 1





def handle_events():
    global running
    global ground
    global top
    global bullet
    global showboundary
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                    close_canvas()
                    running = False
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    guy.move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    guy.move = 2
                    guy.state = 0
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet(guy.x, guy.y, guy.state, guy.stage)]
                elif event.key == SDLK_x:
                    guy.step = False
                    saveY = guy.y
                    guy.jump = True
                    guy.ablejump = guy.ablejump + 1
                    if guy.ablejump > 2:
                        guy.jump = False
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

            if guy.stage == 7 or guy.stage == 8:
                if event.key == SDLK_n:
                    guy.x = 100
                    guy.y = 500
                    if guy.stage == 7 :
                        guy.stage = 8
                    elif guy.stage == 8:
                        guy.stage = 9

        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and guy.move == 1:
                guy.move = 0
            elif event.key == SDLK_LEFT and guy.move == 2:
                guy.move = 0
            elif event.key == SDLK_x:
                guy.jump = False



def drawThorn():
    for p in range(26):
        for r in range(19):
            if block.Maparr[guy.stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[guy.stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[guy.stage - 1][p][r][3],  block.Maparr[guy.stage - 1][p][r][2])


def main():
    global guy
    global bar
    global font
    global Boss
    global blank
    global Thorn
    global tile
    global Itemimage
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map3
    global Bossframe
    global running
    global candia


    fake.redefine()
    while(running):
        clear_canvas()

        if guy.step == False and guy.jump == False:
            guy.y = guy.y - 10
        elif guy.step == True:
            guy.ablejump =0


        if guy.stage == 3:
            map3.draw(400, 302)
            if guy.x > 800:
                write(4, 10, guy.y, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step)
                game_framework.change_state(stage4)
            elif guy.y > 600:
                write(2, guy.x, 0, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step)
                game_framework.change_state(stage2)

            if guy.x > block.Maparr[2][4][0][3] and guy.y < block.Maparr[2][1][3][2] and fake.Fake3[0][0] == 0:
                fake.Fake3[0][0] = 1

            if guy.y < block.Maparr[2][2][3][2] and fake.Fake3[1][0] == 0:
                fake.Fake3[1][0] = 1

            if guy.x > block.Maparr[2][3][0][3] and  guy.y < block.Maparr[2][0][4][2] and fake.Fake3[2][0] == 0:
                fake.Fake3[2][0] = 1

            if guy.x > block.Maparr[2][16][0][3] + 25 and fake.Fake3[3][0] == 0:
                fake.Fake3[3][0] = 1

            if guy.x > block.Maparr[2][20][0][3] and guy.y < block.Maparr[2][0][11][2] and fake.Fake3[4][0] == 0:
                fake.Fake3[4][0] = 1


            if fake.Fake3[0][0] == 1:
                fake.Fake3[0][2] += 5
                if fake.Fake3[0][2] > block.Maparr[2][11][0][3]:
                    fake.Fake3[0][2] = block.Maparr[2][11][0][3]
                    fake.Fake3[0][0] = 2

            if fake.Fake3[1][0] == 1:
                fake.Fake3[1][2] -= 16
                if fake.Fake3[1][2] == block.Maparr[2][1][0][3]:
                    fake.Fake3[1][0] = 2

            if fake.Fake3[2][0] == 1:
                fake.Fake3[2][3] -= 32
                if fake.Fake3[2][3] < - 10:
                    fake.Fake3[2][0] = 2

            if fake.Fake3[3][0] == 1:
                fake.Fake3[3][3] -= 16
                if fake.Fake3[3][3] < - 10:
                    fake.Fake3[3][0] = 2

            if fake.Fake3[4][0] == 1:
                fake.Fake3[4][2] += 16
                if fake.Fake3[4][2] == block.Maparr[2][22][0][3]:
                    fake.Fake3[4][0] = 2


            Thorn.clip_draw(32 * fake.Fake3[0][1], 0, 32, 32, fake.Fake3[0][2], fake.Fake3[0][3])
            Thorn.clip_draw(32 * fake.Fake3[1][1], 0, 32, 32, fake.Fake3[1][2], fake.Fake3[1][3])
            Thorn.clip_draw(32 * fake.Fake3[2][1], 0, 32, 32, fake.Fake3[2][2], fake.Fake3[2][3])
            Thorn.clip_draw(32 * fake.Fake3[3][1], 0, 32, 32, fake.Fake3[3][2], fake.Fake3[3][3])
            Thorn.clip_draw(32 * fake.Fake3[4][1], 0, 32, 32, fake.Fake3[4][2], fake.Fake3[4][3])


        drawThorn()




        if(guy.move == False and guy.jump == False and guy.step == True):
            guy.frame = (guy.frame + 1) % 2
        elif(guy.move == 1):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove and guy.stage != 8:
                guy.x += 5
            if guy.stage == 8:
                for p in range(100):
                    fake.Fake8[p][2] -= 16




        elif(guy.move == 2):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove:
                guy.x -= 5
            if(guy.stage == 1 and guy.x < 5):
                guy.x += 5

        for p in range(0, 26):
            for q in range(0, 18):
                if block.Maparr[guy.stage - 1][p][q][0] == 6:
                    savezone.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                if (guy.jump == False and guy.step == False) :
                    if guy.ablejump == 0:
                        guy.ablejump = 1
                    guy.height = 0

        if guy.jump :
            #print("guy.jump")
            if guy.height < 80:
                guy.y += 10
                guy.height += 10
                guy.frame = 6
            elif guy.height >= 80:
                guy.frame = 7
                guy.jump = False
                guy.height = 0
        elif guy.jump == False and guy.step == False :
                guy.frame = (guy.frame) % 2 + 7

        if showboundary == 1 :
            for p in range(0, 26):
                for q in range(0, 19):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
            for p in range(0, 26):
                for q in range(0, 19):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                        draw_rectangle(block.Maparr[guy.stage - 1][p][q][1] + 16,block.Maparr[guy.stage - 1][p][q][4] + 16, block.Maparr[guy.stage - 1][p][q][3] + 16,block.Maparr[guy.stage - 1][p][q][2] + 16)


        enemy.update()
        morejump()
        font.draw(10,520,'%2d' % guy.body[0])
        font.draw(10,500,'%2d' % guy.body[2])
        font.draw(10,470,'%2d' % guy.y)
        guy.update()
        draw_rectangle(guy.body[0], guy.body[3], guy.body[2], guy.body[1])
        guy.draw()
        if bullet != None:
            for i in bullet:
                i.update(bullet)
        line.draw(400, 15)
        line.draw(400, 585)
        update_canvas()
        handle_events()
        delay(0.04)

    running = False


if __name__ == '__main__':
    main()

