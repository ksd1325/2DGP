
from class_file import*
from pico2d import*
from read_or_write import*
import game_framework

import block
import fake
import morejumping
import stage6
import stage8
name = "stage7"

#open_canvas()

#Bulletimage = None
def update():
    pass
def pause():
    pass
def resume():
    pass
def draw():
    pass
def exit():
    global guy
    global dialogue
    global bullet
    global enemy
    global bar
    global map7
    global savezone
    global blank
    global Thorn
    del(dialogue)
    del(bullet)
    del(enemy)
    del(bar)
    del(Thorn)
    del(map7)
    del(savezone)
    del(blank)
    del(guy)
    pass
def enter():
    global guy
    global bar
    global font
    global blank
    global Thorn
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map7
    global Bossframe
    global running
    global candia

    blank = load_image('blank.png')
    line = load_image('Line.png')
    Thorn = load_image('Thorn(32x32).png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy('guy_playing')
    reset_guy_playing()
    dialogue = Dialog()
    bar = Bar()
    enemy = Enemy()
    bullet = []


    candia = 0
    showboundary = 0
    Bossframe  = 0
    map7 = load_image('7.png')


    font = load_font('HYTBRB.TTF')
    main()




class Bar():
    Barimage = None
    def __init__(self):
        self.checkbar = 0
        self.bar_x = 704
        self.bar_y = 100
        if Bar.Barimage == None:
            Bar.Barimage = load_image('Bar(128x10).png')

    def update(self):
        if guy.stage == 4 or guy.stage == 5 or guy.stage == 6:
            if bar.checkbar == 1:
                bar.bar_y += 2
                if guy.step == True and guy.x < bar.bar_x + 64 and guy.x > bar.bar_x - 64 and guy.y >= bar.bar_y + 10 and guy.y < bar.bar_y + 30:
                    guy.y += 2
            if guy.stage == 6 and bar.bar_y > block.Maparr[5][0][9][2]:
                bar.checkbar = 2
            bar.Barimage.draw(bar.bar_x, bar.bar_y)

class Enemy():
    Enemyimage = None

    def __init__(self):
        self.stage = 1
        self.ex = 19 * 32 + 16
        self.ey = 2 * 32 + 16
        self.box = [self.ex - 15, self.ey + 15, self.ex + 15, self.ey - 15]
        self.frame = 0
        self.state = 0
        self.count = 0
        self.crash = 0
        if Enemy.Enemyimage == None:
            Enemy.Enemyimage = load_image('Enemy(30x30).png')

    def update(self):
        if(self.stage != guy.stage):
            self.stage = guy.stage
            self.count = 0
            self.state = 0
            self.frame = 0
            self.crash = 0
        if self.crash == 0:
            if self.count == 0:
                if self.stage == 2:
                    self.ex = 19 * 32 + 16
                    self.ey = 2 * 32 + 16
                elif self.stage == 3:
                    self.ex = 21 * 32 + 16
                    self.ey = 16 * 32 + 16
                elif self.stage == 4:
                    self.ex = 8 * 32 + 16
                    self.ey = 9 * 32 + 16
                elif self.stage == 11:
                    self.ex = 8 * 32 + 16
                    self.ey = 7 * 32 + 16

                self.count = 1
            if self.state == 0:
                self.ex += 5
                self.frame = (self.frame + 1) % 2
                if self.ex > 23 * 32 + 16 and self.stage == 2:
                    self.state = 1
                elif self.ex > 21 * 32 + 16 and self.stage == 3:
                    self.state = 1
                elif self.ex > 12 * 32 + 16 and self.stage == 4:
                    self.state = 1
                elif self.ex > 10 * 32 + 16 and self.stage == 11:
                    self.state = 1
            elif self.state == 1:
                self.ex -= 5
                self.frame = (self.frame + 1) % 2
                if self.ex < 13 * 32 + 16 and self.stage == 2:
                    self.state = 0
                elif self.ex < 16 * 32 + 16 and self.stage == 3:
                    self.state = 0
                elif self.ex < 6 * 32 + 16 and self.stage == 4:
                    self.state = 0
                elif self.ex < 5 * 32 + 16 and self.stage == 11:
                    self.state = 0

            self.box = [self.ex - 15, self.ey + 15, self.ex + 15, self.ey - 15]
        for i in bullet:
            if i.x >= self.box[0] and i.x <= self.box[2] and i.y <= self.box[1] and i.y >= self.box[3] and self.crash == 0:
                bullet.remove(i)
                self.crash = 1
        if self.crash == 1:
            if self.count == 1:
                self.frame = 1
                self.count = 2
            self.frame += 1
            if self.frame > 4:
                self.state = 2

        if self.state < 2 and (self.stage == 2 or self.stage == 3 or self.stage == 4 or self.stage == 11):
            self.Enemyimage.clip_draw(30 * self.frame, 30 * self.state, 30, 30, self.ex, self.ey)




def handle_events():
    global running
    global ground
    global top
    global bullet
    global showboundary
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                    close_canvas()
                    running = False
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    guy.move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    guy.move = 2
                    guy.state = 0
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet(guy.x, guy.y, guy.state, guy.stage)]
                elif event.key == SDLK_x:
                    guy.step = False
                    saveY = guy.y
                    guy.jump = True
                    guy.ablejump = guy.ablejump + 1
                    if guy.ablejump > 2:
                        guy.jump = False
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

            if guy.stage == 7 or guy.stage == 8:
                if event.key == SDLK_n:
                    guy.x = 100
                    guy.y = 500
                    if guy.stage == 7 :
                        guy.stage = 8
                    elif guy.stage == 8:
                        guy.stage = 9
                
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and guy.move == 1:
                guy.move = 0
            elif event.key == SDLK_LEFT and guy.move == 2:
                guy.move = 0
            elif event.key == SDLK_x:
                guy.jump = False



def drawThorn():
    for p in range(26):
        for r in range(19):
            if block.Maparr[guy.stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[guy.stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[guy.stage - 1][p][r][3],  block.Maparr[guy.stage - 1][p][r][2])
                

def main():
    global guy
    global bar
    global font
    global blank
    global Thorn
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map7
    global running
    global candia

    fake.redefine()
    global saveY
    while(running):
        clear_canvas()

        if guy.step == False and guy.jump == False:
            guy.y = guy.y - 10
        elif guy.step == True:
            guy.ablejump =0

        if guy.stage == 7:
            map7.draw(400, 302)
            if guy.x < 0:
                write(6, 790, guy.y, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step)
                game_framework.change_state(stage6)



        drawThorn()




        if(guy.move == False and guy.jump == False and guy.step == True):
            guy.frame = (guy.frame + 1) % 2
        elif(guy.move == 1):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove and guy.stage != 8:
                guy.x += 5
            if guy.stage == 8:
                for p in range(100):
                    fake.Fake8[p][2] -= 16




        elif(guy.move == 2):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove:
                guy.x -= 5
            if(guy.stage == 1 and guy.x < 5):
                guy.x += 5

        for p in range(0, 26):
            for q in range(0, 18):
                if block.Maparr[guy.stage - 1][p][q][0] == 6:
                    savezone.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                if (guy.jump == False and guy.step == False) :
                    if guy.ablejump == 0:
                        guy.ablejump = 1
                    guy.height = 0

        if guy.jump :
            #print("guy.jump")
            if guy.height < 80:
                guy.y += 10
                guy.height += 10
                guy.frame = 6
            elif guy.height >= 80:
                guy.frame = 7
                guy.jump = False
                guy.height = 0
        elif guy.jump == False and guy.step == False :
                guy.frame = (guy.frame) % 2 + 7

        if showboundary == 1 :
            for p in range(0, 26):
                for q in range(0, 19):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
            for p in range(0, 26):
                for q in range(0, 19):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                        draw_rectangle(block.Maparr[guy.stage - 1][p][q][1] + 16,block.Maparr[guy.stage - 1][p][q][4] + 16, block.Maparr[guy.stage - 1][p][q][3] + 16,block.Maparr[guy.stage - 1][p][q][2] + 16)



        enemy.update()

        font.draw(10,520,'%2d' % guy.body[0])
        font.draw(10,500,'%2d' % guy.body[2])
        font.draw(10,470,'%2d' % guy.y)
        guy.update()
        draw_rectangle(guy.body[0], guy.body[3], guy.body[2], guy.body[1])
        guy.draw()
        if bullet != None:
            for i in bullet:
                i.update(bullet)
        line.draw(400, 15)
        line.draw(400, 585)
        update_canvas()
        handle_events()
        delay(0.04)

    running = False


if __name__ == '__main__':
    main()

