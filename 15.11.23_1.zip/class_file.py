


from pico2d import*
from read_or_write import*


import block
import fake
import random





class Guy:
    RIGHT, LEFT, DEAD = 0, 1 , 2

    guy_state_table = {
        'True' : True,
        'False': False
    }
    global checkbar
    global guy_data



    def __init__(self, choice_data):

        guy_data = read_guy()
        self.guyimage = load_image('Guy(25X23).png')
        self.bloodimage = load_image('Blood(259x259).png')
        self.gameoverimage = load_image('GameOver(754X155).png')
        self.frame = guy_data[choice_data]['frame']
        self.bloodframe = 0
        self.state = guy_data[choice_data]['state']
        self.canmove = Guy.guy_state_table[guy_data[choice_data]['canmove']]
        self.x, self.y = guy_data[choice_data]['x'], guy_data[choice_data]['y']
        self.body = [self.x - 30, self.y + 11, self.x + 10, self.y - 20]
        self.step = Guy.guy_state_table[guy_data[choice_data]['step']]
        self.stage = guy_data[choice_data]['stage']
        print(self.stage)
        self.move = guy_data[choice_data]['move']
        self.jump = Guy.guy_state_table[guy_data[choice_data]['jump']]
        self.ablejump = guy_data[choice_data]['ablejump']
        self.height = guy_data[choice_data]['height']
        self.rangex = int(self.x / 32)
        self.rangey = int(self.y / 32)
        self.savestage = guy_data['guy_saved']['stage']
        self.savestate = guy_data['guy_saved']['state']
        self.savex = guy_data['guy_saved']['x']
        self.savey = guy_data['guy_saved']['y']

    def _guydraw(self):
        self.guyimage.clip_draw(25 * self.frame, self.state * 23, 25, 23, self.x, self.y)

    def _blooddraw(self):
        self.bloodimage.clip_draw(259 * int(self.bloodframe / 4), (self.state - 2), 259, 259, self.x, self.y)

    def _overdraw(self):
        self.gameoverimage.draw(400,300)


    def update(self):
        self.rangex = int(self.x / 32)
        self.rangey = int(self.y / 32)
        self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        if self.state < self.DEAD:
            for p in range(self.rangex - 1, self.rangex + 2):
                for q in range(self.rangey - 1, self.rangey + 2):
                    if p <= 24 and q <= 18 and p >= -1 and q >= 0 and block.Maparr[self.stage - 1][p+1][q][0] == 1:
                        if (self.move == 1 and self.body[0] < block.Maparr[self.stage - 1][p+1][q][3] + 16 and self.body[2]+5 > block.Maparr[self.stage - 1][p+1][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p+1][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p+1][q][2] + 16):
                            #print("collision")
                            if self.canmove == True:
                                self.x -= 5
                            #elif self.canmove == False:
                            #    self.x = block.Maparr[self.stage - 1][p+1][q][1] + 16 - 15
                            self.canmove = False
                        else:
                            self.canmove = True
                    elif p <= 26 and q <= 18 and p >= 1 and q >= 0 and block.Maparr[self.stage - 1][p-1][q][0] == 1:
                        if (self.move == 2 and self.body[0]- 5 < block.Maparr[self.stage - 1][p-1][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p-1][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p-1][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p-1][q][2] + 16):
                            #print("collision")
                            if self.canmove == True:
                                self.x += 5
                            #elif self.canmove == False:
                            #    self.x = block.Maparr[self.stage - 1][p-1][q][3] + 16 + 15
                            self.canmove = False

                        elif p <= 25 and q <= 18 and p >= 0 and q >= 0:
                            self.canmove = True
                            if (self.move == 1 and block.Maparr[self.stage - 1][p][q][0] == 1 and self.body[0]- 5 < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p][q][2] + 16) :
                                #self.x = block.Maparr[self.stage - 1][p][q][3] + 16 + 15
                                self.canmove = False

                    if p <= 25 and q <= 18 and p >= 0 and q >= 0 and  block.Maparr[self.stage - 1][p][q][0] == 1:
                        if (self.body[0] < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p][q][2] + 16):
                            #print("col",jump)
                            self.step = True
                            if self.move == 1:
                                self.x += 5
                            elif self.move == 2:
                                self.x -= 5
                            if ( self.y >= block.Maparr[self.stage - 1][p][q][2] + 16  and self.jump == False):
                                self.y = block.Maparr[self.stage - 1][p][q][2] + 27
                            elif ( self.y <= block.Maparr[self.stage - 1][p][q + 1][4]  and self.jump):
                                self.y = block.Maparr[self.stage - 1][p][q + 1][4] - 27
                                self.jump = False
                                self.step = False
                                if(self.stage == 4 and p == 1 and q == 8):
                                    fake.Fake4[0][0] = 1
                                elif self.stage == 4 and p == 2 and q == 10:
                                    fake.Fake4[1][0] = 1

                    elif p <= 25 and q <= 19 and p >= 0 and q >= 1 and block.Maparr[self.stage - 1][p][q - 1][0] != 1:
                        if (self.body[0] + 18 < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2]- 19 > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] - 1 < block.Maparr[self.stage - 1][p][q][2] + 16):
                            self.step = False

                    for k in range(17):
                        if p <= 25 and q <= 18 and p >= 0 and q >= 0:
                            if self.state == self.DEAD:
                                break
                            if ( block.Maparr[self.stage - 1][p][q][0] == 2 and self.body[3] >= block.Maparr[self.stage - 1][p][q][4] + 16 + 2 * k and self.body[3] <= block.Maparr[self.stage - 1][p][q][4] + 16 + 2 * (k + 1) and ((self.body[0] <= block.Maparr[self.stage - 1][p][q][1] + 16 + k and self.body[2] >= block.Maparr[self.stage - 1][p][q][1] + 16 + k) or (self.body[0] <= block.Maparr[self.stage - 1][p][q][3] + 16 - k and self.body[2] >= block.Maparr[self.stage - 1][p][q][3] + 16 - k))):
                                self.state = self.DEAD
                            elif ( block.Maparr[self.stage - 1][p][q][0] == 3 and (self.body[2] <= block.Maparr[self.stage - 1][p][q][3] + 16 - 2 * k and self.body[2] >= block.Maparr[self.stage - 1][p][q][3] + 16 - 2 * (k + 1) and ((self.body[1] >= block.Maparr[self.stage - 1][p][q][4] + 32 - k and self.body[3] <= block.Maparr[self.stage - 1][p][q][4] + 32 - k ) or (self.body[1] >= block.Maparr[self.stage - 1][p][q][4] + 32 + k and self.body[3] <= block.Maparr[self.stage - 1][p][q][4] + 32 + k )) )):
                                self.state = self.DEAD
                            elif ( block.Maparr[self.stage - 1][p][q][0] == 4 and (self.body[0] >= block.Maparr[self.stage - 1][p][q][1] + 16 + 2 * k and self.body[0] <= block.Maparr[self.stage - 1][p][q][1] + 16 + 2 * (k + 1) and ((self.body[1] >= block.Maparr[self.stage - 1][p][q][4] + 16 + k and self.body[3] <= block.Maparr[self.stage - 1][p][q][4] + 16 + k ) or (self.body[1] >= block.Maparr[self.stage - 1][p][q][2] + 16 - k and self.body[3] <= block.Maparr[self.stage - 1][p][q][2] + 16 - k )) )):
                                self.state = self.DEAD
                            elif ( block.Maparr[self.stage - 1][p][q][0] == 5 and self.body[1] <= block.Maparr[self.stage - 1][p][q][2] + 16 - 2 * k and self.body[1] >= block.Maparr[self.stage - 1][p][q][2] + 16 - 2 * (k + 1) and ((self.body[0] <= block.Maparr[self.stage - 1][p][q][1] + 32 - k and self.body[2] >= block.Maparr[self.stage - 1][p][q][1] + 32 - k) or (self.body[0] <= block.Maparr[self.stage - 1][p][q][1] + 32 + k and self.body[2] >= block.Maparr[self.stage - 1][p][q][1] + 32 + k))):
                                self.state = self.DEAD

        if self.state < self.DEAD:
            self._guydraw()
        else:
            self.bloodframe += 1
            self.move = 0

            if self.bloodframe > 16:
                self.bloodframe = 16
            self._blooddraw()
            if self.bloodframe == 16:
                self._overdraw()



class Dialog:
    def __init__(self):
        self.diaimage = load_image('Dialog.png')
        self.dialog = 0

    def show(self,font):
        if self.dialog != 0:
            self.diaimage.draw(400, 150)
            if self.dialog == 1:
                font.draw(200, 180, 'Hello, I am Programmer K.')
            elif self.dialog == 2:
                font.draw(200, 180, 'There are too Much Error and Bug.')
            elif self.dialog == 3:
                font.draw(200, 180, 'Please Help me.')
            elif self.dialog == 4:
                font.draw(200, 180, 'You can Shot press button Z.')
                font.draw(200, 150, 'And can Jump press button X.')
            elif self.dialog == 5:
                font.draw(200, 180, 'If you want to Save,')
                font.draw(200, 150, 'press UP in Save Zone.')
            elif self.dialog == 6:
                font.draw(200, 180, 'You can Restart press button R.')
            elif self.dialog == 7:
                font.draw(200, 180, 'Gook LUCK, GUY.')
            elif self.dialog == 8:
                self.dialog = 0


class Bullet:
    Bulletimage = None
    def __init__(self, x, y, state, stage):
        self.x = x
        self.y = y + 1
        self.length = 0
        self.direction = state
        self.stage = stage
        self.crash = 0
        if Bullet.Bulletimage == None:
            Bullet.Bulletimage = load_image('Bullet(4x4).png')
    def update(self, bullet):
        if self.direction == 0:
            self.length -= 20
            self.x -= 20
            if self.length < -500:
                self.crash = 1
        elif self.direction == 1:
            self.length += 20
            self.x += 20
            if self.length > 500:
                self.crash = 1

        self._checkcrash()
        self._drawbullet()
        if self.crash == 1:
            self._deletebullet(bullet)

    def _deletebullet(self, bullet):
        bullet.remove(self)

    def _drawbullet(self):
        self.Bulletimage.draw(self.x, self.y)

    def _checkcrash(self):
        for p in range(26):
            for q in range(19):
                if self.x >= block.Maparr[self.stage - 1][p][q][1] and self.x <= block.Maparr[self.stage - 1][p][q][3] + 32 and self.y <= block.Maparr[self.stage - 1][p][q][2] + 16 and self.y >= block.Maparr[self.stage - 1][p][q][4] + 16 and block.Maparr[self.stage - 1][p][q][0] == 1:
                    self.crash = 1



class Enemy:
    enemyimage = None
    RIGHT, LEFT, DEAD = 0, 1, 2

    def __init__(self, stage):
        enemy_data = read_enemy()
        self.stage = stage
        self.enemyin = enemy_data[str(stage)]['enemyin']
        self.x = enemy_data[str(stage)]['x']
        self.y = enemy_data[str(stage)]['y']
        self.box = [self.x - 15, self.y + 15, self.x + 15, self.y - 15]
        self.frame = enemy_data[str(stage)]['frame']
        self.state = self.RIGHT
        self.count = enemy_data[str(stage)]['count']
        self.crash = enemy_data[str(stage)]['crash']
        self.left_limit = enemy_data[str(stage)]['left_limit']
        self.right_limit = enemy_data[str(stage)]['right_limit']
        if Enemy.enemyimage == None:
            Enemy.enemyimage = load_image('Enemy(30x30).png')

    def update(self, bullet, guy):
        if self.crash == 0 and self.enemyin == 1:
            if self.state == self.RIGHT:
                self.x += 5
                self.frame = (self.frame + 1) % 2
                if self.x > self.right_limit:
                    self.state = self.LEFT
            elif self.state == self.LEFT:
                self.x -= 5
                self.frame = (self.frame + 1) % 2
                if self.x < self.left_limit:
                    self.state = self.RIGHT

            self.box = [self.x - 15, self.y + 15, self.x + 15, self.y - 15]
            for i in bullet:
                if i.x >= self.box[0] and i.x <= self.box[2] and i.y <= self.box[1] and i.y >= self.box[3]:
                    #bullet.remove(i)
                    i.crash = 1
                    self.crash = 1
        if self.crash == 1 and self.state != self.DEAD:
            if self.count == 0:
                self.frame = 1
                self.count = 1
            self.frame += 1
            if self.frame > 4:
                self.state = self.DEAD

        if self.state != self.DEAD:
            self.enemyimage.clip_draw(30 * self.frame, 30 * self.state, 30, 30, self.x, self.y)

        if self._crashcheck(guy):
            guy.state = guy.DEAD

    def _crashcheck(self, guy):
        if self.state == self.DEAD: return False
        if guy.body[0] > self.box[2]: return False
        if guy.body[2] < self.box[0]: return False
        if guy.body[1] < self.box[3]: return False
        if guy.body[3] > self.box[1]: return False

        return True




class Bar:
    barimage = None
    def __init__(self, stage):
        bar_data = read_bar()
        self.stage = stage
        self.bar_in = bar_data[str(self.stage)]['in']
        self.bar_x = bar_data[str(self.stage)]['x']
        self.bar_y = bar_data[str(self.stage)]['y']
        self.checkbar = bar_data[str(self.stage)]['checkbar']
        self.boundary = [self.bar_x - 64, self.bar_y + 5, self.bar_x + 64, self.bar_y - 5]
        if Bar.barimage == None:
            Bar.barimage = load_image('Bar(128x10).png')

    def update(self, guy):
        if self.bar_in:
            self.boundary = [self.bar_x - 64, self.bar_y + 5, self.bar_x + 64, self.bar_y - 5]
            if(guy.jump == False and (guy.body[2] > self.boundary[0] and guy.body[0] < self.boundary[2]) and (guy.body[3] < self.boundary[1] + 10 and guy.body[3] > self.boundary[3])):
                self.checkbar = 1
                self.bar_y += 2
                guy.y = self.bar_y + 10
                guy.step = True
            elif self.checkbar == 1:
                self.bar_y += 2
            if guy.stage == 6 and self.bar_y > block.Maparr[5][0][9][2]:
                self.checkbar = 2
            self.barimage.draw(self.bar_x, self.bar_y)


class Fake:
    thornimage = None
    blockimage = None
    UP, DOWN, UP_DOWN = 0, 1, 2
    MOVETYPE, APEENDTHORNTYPE, APEENDTILETYPE = 0, 1, 2
    fake_state_table = {
        'UP' : UP,
        'DOWN': DOWN,
        'UD' : UP_DOWN
    }
    def __init__(self, guy, fake_data, count):
        self.stage = guy.stage
        if self.stage != 8:
            self.shape = fake_data[str(guy.stage)][str(count)]['shape']
            self.x = fake_data[str(guy.stage)][str(count)]['x'] * 32 + 16 - 1
            self.y = fake_data[str(guy.stage)][str(count)]['y'] * 32 + 16 - 2
            self.fakein = 0
            self.triggerx, self.triggery =  fake_data[str(guy.stage)][str(count)]['trigger']['x'] * 32 + 16 - 1, fake_data[str(guy.stage)][str(count)]['trigger']['y'] * 32 + 16 - 2
            self.checkx, self.checky =  Fake.fake_state_table[fake_data[str(guy.stage)][str(count)]['trigger']['checkx']], Fake.fake_state_table[fake_data[str(guy.stage)][str(count)]['trigger']['checky']]
            self.direction = fake_data[str(guy.stage)][str(count)]['direction']
            self.speed = fake_data[str(guy.stage)][str(count)]['speed']
            self.min, self.max = fake_data[str(guy.stage)][str(count)]['limit']['min'] * 32 + 16, fake_data[str(guy.stage)][str(count)]['limit']['max'] * 32 + 16
            self.type = fake_data[str(guy.stage)][str(count)]['type']
            self.box = [self.x - 16, self.y + 16, self.x + 16, self.y - 16]
            if Fake.blockimage == None:
                Fake.blockimage = load_image('Tile(32X32).png')
                Fake.thornimage = load_image('Thorn(32X32).png')


        elif self.stage == 8:
            self.shape = random.randint(0, 3)
            if self.shape == 0 or self.shape == 3:
                self.x = 300 * (count + 3)
            elif self.shape == 1:
                self.x = 310 * (count + 3)
            elif self.shape == 2:
                self.x = 290 * (count + 3)

            if self.shape == 3:
                self.y = 8 * 32 + 16 - 2
            else:
                self.y = 7 * 32 + 16 - 2
            self.fakein = 1
            self.triggerx, self.triggery = 0, 0
            self.checkx, self.checky =  self.UP, self.UP
            self.direction = 0
            self.speed = -5
            self.min, self.max = -20, 9999
            self.type = self.MOVETYPE

    def update(self, guy, fake):
        if self.checkx == self.UP:
            if self.checky == self.UP:
                if guy.x > self.triggerx and guy.y > self.triggery:
                    self.fakein = 1
            elif self.checky == self.DOWN:
                if guy.x > self.triggerx and guy.y < self.triggery:
                    self.fakein = 1
            elif self.checky == self.UP_DOWN:
                if guy.x > self.triggerx and guy.y < self.triggery + 32 and guy.y > self.triggery - 32:
                    self.fakein = 1
        elif self.checkx == self.DOWN:
            if self.checky == self.UP:
                if guy.x < self.triggerx and guy.y > self.triggery:
                    self.fakein = 1
            elif self.checky == self.DOWN:
                if guy.x < self.triggerx and guy.y < self.triggery:
                    self.fakein = 1
            elif self.checky == self.UP_DOWN:
                if guy.x < self.triggerx and guy.y < self.triggery + 32 and guy.y > self.triggery - 32:
                    self.fakein = 1
        elif self.checkx == self.UP_DOWN:
            if self.checky == self.UP:
                if guy.x > self.triggerx - 32 and guy.x < self.triggerx + 32 and guy.y > self.triggery:
                    self.fakein = 1
            elif self.checky == self.DOWN:
                if guy.x > self.triggerx - 32 and guy.x < self.triggerx + 32 and guy.y < self.triggery:
                    self.fakein = 1
            elif self.checky == self.UP_DOWN:
                if guy.x > self.triggerx - 32 and guy.x < self.triggerx + 32 and guy.y < self.triggery + 32 and guy.y > self.triggery - 32:
                    self.fakein = 1

        if self.fakein == 1:
            if self.direction == 0:
                self.x += self.speed
                if self.x > self.max or self.x < self.min:
                    self.x -= self.speed
                    self.speed = 0
                    if self.max > 26 * 32 + 16 or self.min < 16:
                        fake.remove(self)
                if self.max == 14 * 32 + 16 and self.min == 12 * 32 + 16:
                    if guy.x >= self.x:
                        self.speed = 5
                    else:
                        self.speed = -5


            elif self.direction == 1:
                self.y += self.speed
                if self.y > self.max or self.y < self.min:
                    self.y -= self.speed
                    self.speed = 0
                    if self.max > 26 * 32 + 16 or self.min < 16:
                        fake.remove(self)

        self.box = [self.x - 16, self.y + 16, self.x + 16, self.y - 16]

        if self.type == self.MOVETYPE:
            self.thornimage.clip_draw(32 * self.shape, 0, 32, 32, self.x, self.y)
        elif self.type == self.APEENDTHORNTYPE and self.fakein == 1:
            self.thornimage.clip_draw(32 * self.shape, 0, 32, 32, self.x, self.y)
        elif self.type == self.APEENDTILETYPE and self.fakein == 1:
            self.blockimage.clip_draw(32 * self.shape, 0, 32, 32, self.x, self.y)

        self._crashcheck(guy)

    def _crashcheck(self, guy):
        for k in range(17):
            if guy.state == guy.DEAD:
                break
            if self.type != self.APEENDTILETYPE:
                if ( self.shape == 0 and guy.body[3] >=  self.y + 2 * k and guy.body[3] <= self.y + 2 * (k + 1) and ((guy.body[0] <=  self.x - 16 + k and guy.body[2] >=  self.x - 16 + k) or (guy.body[0] <=  self.x + 16 - k and guy.body[2] >=  self.x + 16 - k))):
                    guy.state = guy.DEAD
                elif ( self.shape == 1 and (guy.body[2] <=  self.x + 16 - 2 * k and guy.body[2] >=  self.x + 16 - 2 * (k + 1) and ((guy.body[1] >= self.y + 16 - k and guy.body[3] <= self.y + 16 - k ) or (guy.body[1] >= self.y - 16 + k and guy.body[3] <= self.y - 16 + k )) )):
                    guy.state = guy.DEAD
                elif ( self.shape == 2 and (guy.body[0] >= self.x - 16 + 2 * k and guy.body[0] <=  self.x - 16 + 2 * (k + 1) and ((guy.body[1] >= self.y - 16 + k and guy.body[3] <= self.y - 16 + k ) or (guy.body[1] >= self.y + 16 - k and guy.body[3] <= self.y + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( self.shape == 3 and guy.body[1] <= self.y + 16 - 2 * k and guy.body[1] >= self.y + 16 - 2 * (k + 1) and ((guy.body[0] <=  self.x + 16 - k and guy.body[2] >=  self.x + 16 - k) or (guy.body[0] <=  self.x - 16 + k and guy.body[2] >=  self.x - 16 + k))):
                    guy.state = guy.DEAD

