
import json


def read_guy():
    guy_file = open("guy_data.txt", "r")
    data = json.load(guy_file)
    guy_file.close()
    return data

def write(stage, x, y, frame, ablejump, canmove, state, move, jump, height, step):
    my_dict={
	"guy_playing" : {"stage" : stage, "frame" : frame, "ablejump" : ablejump, "canmove" : str(canmove), "state" : state, "x" : x, "y" : y, "move" : move, "jump" : str(jump), "step" : str(step), "height" : height},
	"guy_saved" : {"stage" : 1, "frame" : 0, "ablejump" : 0, "canmove" : "True", "state" : 1, "x" : 175, "y" : 201, "move" : 0, "jump" : "False", "step" : "True", "height" : 0}
    }


    with open("guy_data.txt", "w") as data_file:
        json.dump(my_dict, data_file)

    data_file.close()

def reset_guy_playing():
    my_dict={
	"guy_saved": {"x": 175, "canmove": "True", "move": 0, "stage": 1, "height": 0, "state": 1, "y": 201, "frame": 0, "step": "True", "ablejump": 0, "jump": "False"},
	"guy_playing": {"x": 10, "canmove": "True", "move": 0 , "stage": 1, "height": 0, "state": 1, "y": 201, "frame": 0, "step": "True", "ablejump": 0, "jump": "False"}
    }

    with open("guy_data.txt", "w") as data_file:
        json.dump(my_dict, data_file)

    data_file.close()


def read_enemy():
    enemy_file = open("enemy_data.txt", "r")
    data = json.load(enemy_file)
    enemy_file.close()
    return data
