

from class_file import*
from pico2d import*
import game_framework

import block
import fake
import morejumping
import stage2
from read_or_write import*
name = "stage1"



#open_canvas()

#Bulletimage = None
def update():
    pass
def pause():
    pass
def resume():
    pass
def draw():
    pass
def exit():
    global guy
    global dialogue
    global bullet
    global map1
    global savezone
    global blank
    global Thorn
    del(dialogue)
    del(bullet)
    del(map1)
    del(savezone)
    del(blank)
    del(guy)
    pass
def enter():
    global guy
    global font
    global Boss
    global blank
    global savezone
    global bullet
    global dialogue
    global line
    global showboundary
    global map1
    global Bossframe
    global running
    global candia
    global Thorn


    Boss = load_image('Boss(87X98).png')
    blank = load_image('blank.png')
    line = load_image('Line.png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy('guy_playing')
    Thorn = load_image('Thorn(32x32).png')
    reset_guy_playing()
    dialogue = Dialog()
    bullet = []


    guy.height = 0
    candia = 0
    showboundary = 0
    Bossframe  = 0
    map1 = load_image('1.png')


    font = load_font('HYTBRB.TTF')
    main()





def handle_events():
    global running
    global ground
    global top
    global bullet
    global showboundary
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                    close_canvas()
                    running = False
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    guy.move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    guy.move = 2
                    guy.state = 0
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet(guy.x, guy.y, guy.state, guy.stage)]
                elif event.key == SDLK_x:
                    guy.step = False
                    guy.jump = True
                    guy.ablejump += 1
                    if guy.ablejump > 2:
                        guy.jump = False
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and guy.move == 1:
                guy.move = 0
            elif event.key == SDLK_LEFT and guy.move == 2:
                guy.move = 0
            elif event.key == SDLK_x:
                guy.jump = False


def drawThorn():
    for p in range(26):
        for r in range(19):
            if block.Maparr[guy.stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[guy.stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[guy.stage - 1][p][r][3],  block.Maparr[guy.stage - 1][p][r][2])
            if block.Maparr[guy.stage - 1][p][r][0] == 6:
                savezone.draw(block.Maparr[guy.stage - 1][p][r][3], block.Maparr[guy.stage - 1][p][r][2])

def main():
    global guy
    global font
    global Boss
    global blank
    global savezone
    global bullet
    global dialogue
    global line
    global showboundary
    global map1
    global Bossframe
    global running
    global candia


    while(running):
        clear_canvas()

        if guy.step == False and guy.jump == False:
            guy.y = guy.y - 10
        elif guy.step == True:
            guy.ablejump =0

        if guy.stage == 1:
            map1.draw(400, 302)
            Boss.clip_draw(87 * Bossframe, 0, 87, 98, 450, 176 + 63)
            if guy.x > 800:
                write(2, 10, guy.y, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step)
                game_framework.change_state(stage2)
            if guy.x >= 420 and guy.x <= 480:
                candia = 1
            else:
                candia = 0

        drawThorn()


        if(guy.move == False and guy.jump == False and guy.step == True):
            guy.frame = (guy.frame + 1) % 2
        elif(guy.move == 1):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove and guy.stage != 8:
                guy.x += 5
            if guy.stage == 8:
                for p in range(100):
                    fake.Fake8[p][2] -= 16




        elif(guy.move == 2):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove:
                guy.x -= 5
            if(guy.stage == 1 and guy.x < 5):
                guy.x += 5


        if (guy.jump == False and guy.step == False) :
            if guy.ablejump == 0:
                guy.ablejump = 1
            guy.height = 0

        if guy.jump :
            if guy.height < 80:
                guy.y += 10
                guy.height += 10
                guy.frame = 6
            elif guy.height >= 80:
                guy.frame = 7
                guy.jump = False
                guy.height = 0
        elif guy.jump == False and guy.step == False :
                guy.frame = (guy.frame) % 2 + 7

        if showboundary == 1 :
            for p in range(guy.rangex, guy.rangex +1):
                for q in range(guy.rangey, guy.rangey + 1):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
            for p in range(guy.rangex, guy.rangex +1):
                for q in range(guy.rangey, guy.rangey + 1):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                        draw_rectangle(block.Maparr[guy.stage - 1][p][q][1] + 16,block.Maparr[guy.stage - 1][p][q][4] + 16, block.Maparr[guy.stage - 1][p][q][3] + 16,block.Maparr[guy.stage - 1][p][q][2] + 16)


        font.draw(10,520,'%2d' % guy.body[0])
        font.draw(10,500,'%2d' % guy.body[2])
        font.draw(10,470,'%2d' % guy.y)
        guy.update()
        draw_rectangle(guy.body[0], guy.body[3], guy.body[2], guy.body[1])
        if bullet != None:
            for i in bullet:
                i.update(bullet)
        line.draw(400, 15)
        line.draw(400, 585)
        dialogue.show(font)
        update_canvas()
        handle_events()
        delay(0.04)

    running = False


if __name__ == '__main__':
    main()

