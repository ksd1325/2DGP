import random


Fake2 = [[[0] for p in range(4)] for q in range(3)]
Fake3 = [[[0] for p in range(4)] for q in range(5)]
Fake4 = [[[0] for p in range(4)] for q in range(8)]
Fake5 = [[[0] for p in range(4)] for q in range(7)]
Fake6 = [[[0] for p in range(4)] for q in range(3)]
Fake8 = [[[0] for p in range(4)] for q in range(100)]
Fake10 = [[[0] for p in range(4)] for q in range(10)]

def redefine():
    for p in range(100):
        for q in range(4):
            if p < 3:
                Fake2[p][q] = 0
                Fake6[p][q] = 0
            if p < 5:
                Fake3[p][q] = 0
            if p < 7:
                Fake5[p][q] = 0
            if p < 8:
                Fake4[p][q] = 0
            if p < 10:
                Fake10[p][q] = 0
            Fake8[p][q] = 0
         

    Fake2[0][2] = 10 * 32 + 16 - 1
    Fake2[0][3] = -10


    Fake2[1][2] = 15 * 32 + 16 - 1
    Fake2[1][3] = 2 * 32 + 16 -2


    Fake2[2][1] = 1
    Fake2[2][2] = 23 * 32 + 16 - 1
    Fake2[2][3] = 5 * 32 + 16 - 2

#----------------------------------------------#

    Fake3[0][1] = 2
    Fake3[0][2] = 1 * 32 + 16 - 1
    Fake3[0][3] = 4 * 32 + 16 - 2

    Fake3[1][2] = 2 * 32 + 16 - 1
    Fake3[1][3] = 1 * 32 + 16 - 2

    Fake3[2][1] = 3
    Fake3[2][2] = 4 * 32 + 16 - 1
    Fake3[2][3] = 5 * 32 + 16 - 2

    Fake3[3][1] = 3
    Fake3[3][2] = 18 * 32 + 16 - 1
    Fake3[3][3] = 17 * 32 + 16 - 1

    Fake3[4][1] = 2
    Fake3[4][2] = 21 * 32 + 16 - 1
    Fake3[4][3] = 9 * 32 + 16 - 2

#---------------------------------------------------#

    Fake4[0][2] = 1 * 32 + 16 - 1
    Fake4[0][3] = 8 * 32 + 16 - 2

    Fake4[1][2] = 2 * 32 + 16 - 1
    Fake4[1][3] = 10 * 32 + 16 - 2

    Fake4[2][2] = 4 * 32 + 16 - 1
    Fake4[2][3] = 7 * 32 + 16 - 2

    Fake4[3][2] = 5 * 32 + 16 - 1
    Fake4[3][3] = 7 * 32 + 16 - 2

    Fake4[4][2] = 4 * 32 + 16 - 1
    Fake4[4][3] = 11 * 32 + 16 - 2

    Fake4[5][2] = 6 * 32 + 16 - 1
    Fake4[5][3] = 9 * 32 + 16 - 2

    Fake4[6][2] = 7 * 32 + 16 - 1
    Fake4[6][3] = 9 * 32 + 16 - 2

    Fake4[7][2] = 12 * 32 + 16 - 1
    Fake4[7][3] = 4 * 32 + 16 - 2

#-------------------------------------------#

    Fake5[0][2] = 19 * 32 + 16 - 1
    Fake5[0][3] = 13 * 32 + 16 - 2

    for p in range(6):
        Fake5[1 + p][2] = (18 - p) * 32 + 16 - 1
        Fake5[1 + p][3] = 2 * 32 + 16 - 2


#-------------------------------------------#

    Fake6[0][1] = 3
    Fake6[0][2] = 20 * 32 + 16 - 1
    Fake6[0][3] = 9 * 32 + 16 - 2

#-------------------------------------------#

    for p in range(100):
        Fake8[p][1] = random.randint(0, 3)

        if Fake8[p][1] == 0 or Fake8[p][1] == 3:
            Fake8[p][2] = 300 * (p + 3)
        elif Fake8[p][1] == 1:
            Fake8[p][2] = 310 * (p + 3)
        elif Fake8[p][1] == 2:
            Fake8[p][2] = 290 * (p + 3)

        if Fake8[p][1] == 3:
            Fake8[p][3] = 8 * 32 + 16 - 2
        else:
            Fake8[p][3] = 7 * 32 + 16 - 2

#------------------------------------------------------------#

    for p in range(10):
        Fake10[p][2] = 0 * 32 + 16 - 1
        Fake10[p][3] = (6 + p) * 32 + 16 - 2


def fake_crash(guy):
    fake2_box = []
    fake3_box = []
    fake4_box = []
    fake5_box = []
    fake6_box = []
    fake8_box = []
    fake10_box = []

    if guy.stage == 2:
        for q in range(3):
            fake2_box += [[Fake2[q][1], Fake2[q][2] - 16, Fake2[q][3] - 16, Fake2[q][2] + 16, Fake2[q][3] + 16]]
            for k in (0, 17):
                if ( fake2_box[q][0] == 0 and guy.body[3] >= fake2_box[q][4] + 16 + 2 * k and guy.body[3] <= fake2_box[q][4] + 16 + 2 * (k + 1) and ((guy.body[0] <= fake2_box[q][1] + 16 + k and guy.body[2] >= fake2_box[q][1] + 16 + k) or (guy.body[0] <= fake2_box[q][3] + 16 - k and guy.body[2] >= fake2_box[q][3] + 16 - k))):
                    guy.state = guy.DEAD
                elif ( fake2_box[q][0] == 1 and (guy.body[2] <= fake2_box[q][3] + 16 - 2 * k and guy.body[2] >= fake2_box[q][3] + 16 - 2 * (k + 1) and ((guy.body[1] >= fake2_box[q][4] + 32 - k and guy.body[3] <= fake2_box[q][4] + 32 - k ) or (guy.body[1] >= fake2_box[q][4] + 32 + k and guy.body[3] <= fake2_box[q][4] + 32 + k )) )):
                    guy.state = guy.DEAD
                elif ( fake2_box[q][0] == 2 and (guy.body[2] <= fake2_box[q][1] + 16 + 2 * k and guy.body[2] >= fake2_box[q][1] + 16 + 2 * (k + 1) and ((guy.body[1] >= fake2_box[q][4] + 16 + k and guy.body[3] <= fake2_box[q][4] + 16 + k ) or (guy.body[1] >= fake2_box[q][2] + 16 - k and guy.body[3] <= fake2_box[q][2] + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( fake2_box[q][0] == 3 and guy.body[1] >= fake2_box[q][2] + 16 - 2 * k and guy.body[1] <= fake2_box[q][2] + 16 - 2 * (k + 1) and ((guy.body[0] <= fake2_box[q][1] + 32 - k and guy.body[2] >= fake2_box[q][1] + 32 - k) or (guy.body[0] <= fake2_box[q][1] + 32 + k and guy.body[2] >= fake2_box[q][1] + 32 + k))):
                    guy.state = guy.DEAD

    if guy.stage == 3:
        for q in range(5):
            fake3_box += [[Fake3[q][1], Fake3[q][2] - 16, Fake3[q][3] - 16, Fake3[q][2] + 16, Fake3[q][3] + 16]]
            for k in (0, 17):
                if ( fake3_box[q][0] == 0 and guy.body[3] >= fake3_box[q][4] + 16 + 2 * k and guy.body[3] <= fake3_box[q][4] + 16 + 2 * (k + 1) and ((guy.body[0] <= fake3_box[q][1] + 16 + k and guy.body[2] >= fake3_box[q][1] + 16 + k) or (guy.body[0] <= fake3_box[q][3] + 16 - k and guy.body[2] >= fake3_box[q][3] + 16 - k))):
                    guy.state = guy.DEAD
                elif ( fake3_box[q][0] == 1 and (guy.body[2] <= fake3_box[q][3] + 16 - 2 * k and guy.body[2] >= fake3_box[q][3] + 16 - 2 * (k + 1) and ((guy.body[1] >= fake3_box[q][4] + 32 - k and guy.body[3] <= fake3_box[q][4] + 32 - k ) or (guy.body[1] >= fake3_box[q][4] + 32 + k and guy.body[3] <= fake3_box[q][4] + 32 + k )) )):
                    guy.state = guy.DEAD
                elif ( fake3_box[q][0] == 2 and (guy.body[2] <= fake3_box[q][1] + 16 + 2 * k and guy.body[2] >= fake3_box[q][1] + 16 + 2 * (k + 1) and ((guy.body[1] >= fake3_box[q][4] + 16 + k and guy.body[3] <= fake3_box[q][4] + 16 + k ) or (guy.body[1] >= fake3_box[q][2] + 16 - k and guy.body[3] <= fake3_box[q][2] + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( fake3_box[q][0] == 3 and guy.body[1] >= fake3_box[q][2] + 16 - 2 * k and guy.body[1] <= fake3_box[q][2] + 16 - 2 * (k + 1) and ((guy.body[0] <= fake3_box[q][1] + 32 - k and guy.body[2] >= fake3_box[q][1] + 32 - k) or (guy.body[0] <= fake3_box[q][1] + 32 + k and guy.body[2] >= fake3_box[q][1] + 32 + k))):
                    guy.state = guy.DEAD

    if guy.stage == 4:
        for q in range(8):
            fake4_box += [[Fake4[q][1], Fake4[q][2] - 16, Fake4[q][3] - 16, Fake4[q][2] + 16, Fake4[q][3] + 16]]
            for k in (0, 17):
                if ( fake4_box[q][0] == 0 and guy.body[3] >= fake4_box[q][4] + 16 + 2 * k and guy.body[3] <= fake4_box[q][4] + 16 + 2 * (k + 1) and ((guy.body[0] <= fake4_box[q][1] + 16 + k and guy.body[2] >= fake4_box[q][1] + 16 + k) or (guy.body[0] <= fake4_box[q][3] + 16 - k and guy.body[2] >= fake4_box[q][3] + 16 - k))):
                    guy.state = guy.DEAD
                elif ( fake4_box[q][0] == 1 and (guy.body[2] <= fake4_box[q][3] + 16 - 2 * k and guy.body[2] >= fake4_box[q][3] + 16 - 2 * (k + 1) and ((guy.body[1] >= fake4_box[q][4] + 32 - k and guy.body[3] <= fake4_box[q][4] + 32 - k ) or (guy.body[1] >= fake4_box[q][4] + 32 + k and guy.body[3] <= fake4_box[q][4] + 32 + k )) )):
                    guy.state = guy.DEAD
                elif ( fake4_box[q][0] == 2 and (guy.body[2] <= fake4_box[q][1] + 16 + 2 * k and guy.body[2] >= fake4_box[q][1] + 16 + 2 * (k + 1) and ((guy.body[1] >= fake4_box[q][4] + 16 + k and guy.body[3] <= fake4_box[q][4] + 16 + k ) or (guy.body[1] >= fake4_box[q][2] + 16 - k and guy.body[3] <= fake4_box[q][2] + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( fake4_box[q][0] == 3 and guy.body[1] >= fake4_box[q][2] + 16 - 2 * k and guy.body[1] <= fake4_box[q][2] + 16 - 2 * (k + 1) and ((guy.body[0] <= fake4_box[q][1] + 32 - k and guy.body[2] >= fake4_box[q][1] + 32 - k) or (guy.body[0] <= fake4_box[q][1] + 32 + k and guy.body[2] >= fake4_box[q][1] + 32 + k))):
                    guy.state = guy.DEAD

    if guy.stage == 5:
        for q in range(7):
            fake5_box += [[Fake5[q][1], Fake5[q][2] - 16, Fake5[q][3] - 16, Fake5[q][2] + 16, Fake5[q][3] + 16]]
            for k in (0, 17):
                if ( fake5_box[q][0] == 0 and guy.body[3] >= fake5_box[q][4] + 16 + 2 * k and guy.body[3] <= fake5_box[q][4] + 16 + 2 * (k + 1) and ((guy.body[0] <= fake5_box[q][1] + 16 + k and guy.body[2] >= fake5_box[q][1] + 16 + k) or (guy.body[0] <= fake5_box[q][3] + 16 - k and guy.body[2] >= fake5_box[q][3] + 16 - k))):
                    guy.state = guy.DEAD
                elif ( fake5_box[q][0] == 1 and (guy.body[2] <= fake5_box[q][3] + 16 - 2 * k and guy.body[2] >= fake5_box[q][3] + 16 - 2 * (k + 1) and ((guy.body[1] >= fake5_box[q][4] + 32 - k and guy.body[3] <= fake5_box[q][4] + 32 - k ) or (guy.body[1] >= fake5_box[q][4] + 32 + k and guy.body[3] <= fake5_box[q][4] + 32 + k )) )):
                    guy.state = guy.DEAD
                elif ( fake5_box[q][0] == 2 and (guy.body[2] <= fake5_box[q][1] + 16 + 2 * k and guy.body[2] >= fake5_box[q][1] + 16 + 2 * (k + 1) and ((guy.body[1] >= fake5_box[q][4] + 16 + k and guy.body[3] <= fake5_box[q][4] + 16 + k ) or (guy.body[1] >= fake5_box[q][2] + 16 - k and guy.body[3] <= fake5_box[q][2] + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( fake5_box[q][0] == 3 and guy.body[1] >= fake5_box[q][2] + 16 - 2 * k and guy.body[1] <= fake5_box[q][2] + 16 - 2 * (k + 1) and ((guy.body[0] <= fake5_box[q][1] + 32 - k and guy.body[2] >= fake5_box[q][1] + 32 - k) or (guy.body[0] <= fake5_box[q][1] + 32 + k and guy.body[2] >= fake5_box[q][1] + 32 + k))):
                    guy.state = guy.DEAD
    if guy.stage == 6:
        for q in range(3):
            fake6_box += [[Fake6[q][1], Fake6[q][2] - 16, Fake6[q][3] - 16, Fake6[q][2] + 16, Fake6[q][3] + 16]]
            for k in (0, 17):
                if ( fake6_box[q][0] == 0 and guy.body[3] >= fake6_box[q][4] + 16 + 2 * k and guy.body[3] <= fake6_box[q][4] + 16 + 2 * (k + 1) and ((guy.body[0] <= fake6_box[q][1] + 16 + k and guy.body[2] >= fake6_box[q][1] + 16 + k) or (guy.body[0] <= fake6_box[q][3] + 16 - k and guy.body[2] >= fake6_box[q][3] + 16 - k))):
                    guy.state = guy.DEAD
                elif ( fake6_box[q][0] == 1 and (guy.body[2] <= fake6_box[q][3] + 16 - 2 * k and guy.body[2] >= fake6_box[q][3] + 16 - 2 * (k + 1) and ((guy.body[1] >= fake6_box[q][4] + 32 - k and guy.body[3] <= fake6_box[q][4] + 32 - k ) or (guy.body[1] >= fake6_box[q][4] + 32 + k and guy.body[3] <= fake6_box[q][4] + 32 + k )) )):
                    guy.state = guy.DEAD
                elif ( fake6_box[q][0] == 2 and (guy.body[2] <= fake6_box[q][1] + 16 + 2 * k and guy.body[2] >= fake6_box[q][1] + 16 + 2 * (k + 1) and ((guy.body[1] >= fake6_box[q][4] + 16 + k and guy.body[3] <= fake6_box[q][4] + 16 + k ) or (guy.body[1] >= fake6_box[q][2] + 16 - k and guy.body[3] <= fake6_box[q][2] + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( fake6_box[q][0] == 3 and guy.body[1] >= fake6_box[q][2] + 16 - 2 * k and guy.body[1] <= fake6_box[q][2] + 16 - 2 * (k + 1) and ((guy.body[0] <= fake6_box[q][1] + 32 - k and guy.body[2] >= fake6_box[q][1] + 32 - k) or (guy.body[0] <= fake6_box[q][1] + 32 + k and guy.body[2] >= fake6_box[q][1] + 32 + k))):
                    guy.state = guy.DEAD
    if guy.stage == 8:
        for q in range(100):
            fake8_box += [[Fake8[q][1], Fake8[q][2] - 16, Fake8[q][3] - 16, Fake8[q][2] + 16, Fake8[q][3] + 16]]
            for k in (0, 17):
                if ( fake8_box[q][0] == 0 and guy.body[3] >= fake8_box[q][4] + 16 + 2 * k and guy.body[3] <= fake8_box[q][4] + 16 + 2 * (k + 1) and ((guy.body[0] <= fake8_box[q][1] + 16 + k and guy.body[2] >= fake8_box[q][1] + 16 + k) or (guy.body[0] <= fake8_box[q][3] + 16 - k and guy.body[2] >= fake8_box[q][3] + 16 - k))):
                    guy.state = guy.DEAD
                elif ( fake8_box[q][0] == 1 and (guy.body[2] <= fake8_box[q][3] + 16 - 2 * k and guy.body[2] >= fake8_box[q][3] + 16 - 2 * (k + 1) and ((guy.body[1] >= fake8_box[q][4] + 32 - k and guy.body[3] <= fake8_box[q][4] + 32 - k ) or (guy.body[1] >= fake8_box[q][4] + 32 + k and guy.body[3] <= fake8_box[q][4] + 32 + k )) )):
                    guy.state = guy.DEAD
                elif ( fake8_box[q][0] == 2 and (guy.body[2] <= fake8_box[q][1] + 16 + 2 * k and guy.body[2] >= fake8_box[q][1] + 16 + 2 * (k + 1) and ((guy.body[1] >= fake8_box[q][4] + 16 + k and guy.body[3] <= fake8_box[q][4] + 16 + k ) or (guy.body[1] >= fake8_box[q][2] + 16 - k and guy.body[3] <= fake8_box[q][2] + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( fake8_box[q][0] == 3 and guy.body[1] >= fake8_box[q][2] + 16 - 2 * k and guy.body[1] <= fake8_box[q][2] + 16 - 2 * (k + 1) and ((guy.body[0] <= fake8_box[q][1] + 32 - k and guy.body[2] >= fake8_box[q][1] + 32 - k) or (guy.body[0] <= fake8_box[q][1] + 32 + k and guy.body[2] >= fake8_box[q][1] + 32 + k))):
                    guy.state = guy.DEAD
    if guy.stage == 10:
        for q in range(10):
            fake10_box += [[Fake10[q][1], Fake10[q][2] - 16, Fake10[q][3] - 16, Fake10[q][2] + 16, Fake10[q][3] + 16]]
            for k in (0, 17):
                if ( fake10_box[q][0] == 0 and guy.body[3] >= fake10_box[q][4] + 16 + 2 * k and guy.body[3] <= fake10_box[q][4] + 16 + 2 * (k + 1) and ((guy.body[0] <= fake10_box[q][1] + 16 + k and guy.body[2] >= fake10_box[q][1] + 16 + k) or (guy.body[0] <= fake10_box[q][3] + 16 - k and guy.body[2] >= fake10_box[q][3] + 16 - k))):
                    guy.state = guy.DEAD
                elif ( fake10_box[q][0] == 1 and (guy.body[2] <= fake10_box[q][3] + 16 - 2 * k and guy.body[2] >= fake10_box[q][3] + 16 - 2 * (k + 1) and ((guy.body[1] >= fake10_box[q][4] + 32 - k and guy.body[3] <= fake10_box[q][4] + 32 - k ) or (guy.body[1] >= fake10_box[q][4] + 32 + k and guy.body[3] <= fake10_box[q][4] + 32 + k )) )):
                    guy.state = guy.DEAD
                elif ( fake10_box[q][0] == 2 and (guy.body[2] <= fake10_box[q][1] + 16 + 2 * k and guy.body[2] >= fake10_box[q][1] + 16 + 2 * (k + 1) and ((guy.body[1] >= fake10_box[q][4] + 16 + k and guy.body[3] <= fake10_box[q][4] + 16 + k ) or (guy.body[1] >= fake10_box[q][2] + 16 - k and guy.body[3] <= fake10_box[q][2] + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( fake10_box[q][0] == 3 and guy.body[1] >= fake10_box[q][2] + 16 - 2 * k and guy.body[1] <= fake10_box[q][2] + 16 - 2 * (k + 1) and ((guy.body[0] <= fake10_box[q][1] + 32 - k and guy.body[2] >= fake10_box[q][1] + 32 - k) or (guy.body[0] <= fake10_box[q][1] + 32 + k and guy.body[2] >= fake10_box[q][1] + 32 + k))):
                    guy.state = guy.DEAD

    return guy.state

