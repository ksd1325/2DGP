from pico2d import*


open_canvas()


Guyimage = None
Boss = load_image('Boss(87X98).png')

class Guy:
    def __init__(self):
        self.Guyimage = load_image('Guy(25X23).png')
        self.frame = 0
        self.state = 0
        self.x, self.y = 0, 176
        self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
        self.body = [self.x - 6, self.y, self.x + 10, self.y + 11]
    def draw(self):
        self.Guyimage.clip_draw(25 * self.frame, self.state * 23, 25, 23, self.x, self.y)
    def update(self):
        pass


global Guyframe
Guyframe = 0
Bossframe  = 0
map1 = load_image('1.png')
map2 = load_image('2.png')
map2_1 = load_image('2-1.png')
map3 = load_image('3.png')
map4 = load_image('4.png')
map5 = load_image('5.png')
map6 = load_image('6.png')
map6_1 = load_image('6-1.png')
map7 = load_image('7.png')
map8 = load_image('8.png')
map9 = load_image('9.png')
        

stage = float(3)
tx = 0
ty = 0

def save():
    global sx
    global sy
    global sstage
    global sground
    global stop
    global stage
    global ground
    global top
    sx = guy.x
    sy = guy.y
    sstage = stage
    sground = ground
    stop = top

def load():
    global sx
    global sy
    global sstage
    global sground
    global stop
    global stage
    global ground
    global top
    global Ablejump
    stage = sstage
    ground = sground
    guy.x = sx
    guy.y = sy
    top = stop
    Ablejump = 0


def handle_events():
    global running
    global Move
    global jump
    global Ablejump
    global ground
    global height
    global top
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_RIGHT:
                Move = 1
                guy.state = 1
            elif event.key == SDLK_LEFT:
                Move = 2
                guy.state = 0
            elif event.key == SDLK_ESCAPE:
                close_canvas()
                running = False
            elif event.key == SDLK_x:
                jump = True
                Ablejump = Ablejump + 1
                if Ablejump > 2:
                    jump = False
            elif event.key == SDLK_s:
                save()
            elif event.key == SDLK_r:
                load()
            elif event.key == SDLK_p:
                print((guy.x, guy.y))
                
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and Move == 1:
                Move = 0
            elif event.key == SDLK_LEFT and Move == 2:
                Move = 0
            elif event.key == SDLK_x:
                jump = False

ground = 176
running = True
#x = 10
#y = ground + 23
guy = Guy()
guy.x = 520
guy.y = 495
guy.state = 1
Move = 0
jump = False
Ablejump = 0
height = 0
top = 800
sx = 0
sy = 0
sstage = 1
stop = 0
sground = 0

while(running):
    clear_canvas()
    if stage == 1:
        top = 800
        map1.draw(400, 302)
        guy.draw()
        if guy.x > 800:
            stage = 2
            guy.x = 0
            ground = 176
    elif stage == 2:
        top = 800
        map2.draw(400, 302)

        guy.update()
        if guy.x < 0 and guy.y >= ground + 25:
            stage = 1
            guy.x = 800
            ground = 176
        elif guy.x > 325 and guy.x <= 410:
            ground = -100
            if guy.y <= -20:
                stage = 3
                ground = 320 + 16
                guy.y = 620
        elif guy.x < 35:
            ground = 176
        elif guy.x > 800:
            ground = 176
            stage = 2.5
            guy.x = 0
        elif guy.x > 765:
            ground = 176
        elif guy.x > 35:
            ground = 32 + 16
    elif stage == 2.5:
        map2_1.draw(400, 302)
        
        guy.draw()
        if guy.x < 290 and guy.y >= 176:
            ground = 176
        elif guy.x >= 290:
            ground = -100
    elif stage == 3.0:
        map3.draw(400, 302)
        
        guy.draw()
        if guy.x > 325 and guy.x <= 410 and guy.y > 330:
            ground = 336
            top = 800
        elif guy.x > 255 and guy.x <= 325 and guy.y >= 368 and guy.y + 25 < 464:
            ground = 368
            top = 464
        elif guy.x > 220 and guy.x <= 255 and guy.y >= 400 and guy.y + 25 < 496:
            ground = 400
            top = 496
        elif guy.x > 190 and guy.x <= 220 and guy.y >= 432 and guy.y + 25 < 528:
            ground = 432
            top = 528
        elif guy.x > 90 and guy.x <= 190 and guy.y >= 464 and guy.y + 25 < 528:
            ground = 464
            top = 528
        elif guy.x <= 90 and guy.y < 300:
            ground = 16
            top = 528
        elif guy.x > 90 and guy.x <= 215 and guy.y < 300 :
            ground = 16
            if guy.x >= 110 and guy.x < 145:
                top = 60
            else:
                top = 178
        elif guy.x > 215 and guy.x <= 320 and guy.y < 300:
            ground = 110
            top = 178
        elif guy.x > 320 and guy.x <= 375 and guy.y < 300:
            ground = -100
            top = 178
        elif guy.x > 375 and guy.x <= 430 and guy.y < 300:
            ground = 110
            top = 178
        elif guy.x > 450 and guy.x <= 500:
            ground = - 100
            top = 560
        elif guy.x > 500:
            ground = 495
            top = 560

    
    update_canvas()
        

   # Boss.clip_draw(87 * Bossframe, 0, 87, 98, 200, 209)
            
    if(Move == False and jump == False and guy.y == ground + 25):
        guy.frame = (guy.frame + 1) % 2
    elif(Move == 1):
        if jump == False:
            guy.frame = (guy.frame + 1) % 4 + 2
        if stage == 1:
            guyx = guyx + 5
        elif stage == 2:
            if( guy.x >= 760 and guy.y < 176 + 25):
                guy.x = 760
            elif ( guy.x >= 410 and guy.y < 48):
                guy.x = 410
            else:
                guy.x = guy.x + 5
        elif stage == 2.5:
            guy.x = guy.x + 5
        elif stage == 3:
            if guy.x >= 500 and guy.x < 510 and guy.y < 550:
                guy.x = 500
            if guy.x >= 410 and guy.x < 420 and guy.y >= 310:
                guy.x = 410
            elif guy.x >= 375 and guy.x < 385 and guy.y < 135:
                guy.x= 375
            elif guy.x >= 215  and guy.x < 225 and guy.y < 128:
                guy.x = 215
            elif guy.x >= 90 and guy.x < 100 and guy.y >= 60:
                guy.x = 90
            else:
                guy.x = guy.x + 5




                
    elif(Move == 2):
        if jump == False:
            guy.frame = (guy.frame + 1) % 4 + 2
        if stage == 1:
            if( guy.x > 5):
                guy.x = guy.x - 5
        elif stage == 2:
            if( guy.x < 45 and guy.y < 176 + 25):
                guy.x = 40
            elif ( guy.x <= 330 and guy.y < 48):
                guy.x = 330  
            else:
                guy.x = guy.x - 5
        elif stage == 2.5:
            if guy.x <= 170 and guy.y < 48:
                guy.x = 170
                top = 48
                ground = -100
            elif guy.x <= 200 and guy.y < 80 and guy.y >= 48:
                guy.x = 200
                top = 80
                ground = -100
            elif guy.x <= 230 and guy.y < 112 and guy.y >= 80:
                guy.x = 230
                top = 112
                ground = -100
            elif guy.x <= 265 and guy.y  < 144 and guy.y  >= 112:
                guy.x = 265
                top = 144 
                ground = -100
            elif guy.x <= 300 and guy.y < 176 and guy.y >= 144:
                guy.x = 300
                top = 800
                ground = -100
            else:
                guy.x = guy.x - 5

        elif stage == 3:
            if guy.x <= 40 and guy.y < 496:
                guy.x= 40
            elif guy.x <= 200 and guy.x > 100 and guy.y < 464:
                guy.x = 200
            elif guy.x <= 230 and guy.x > 200 and guy.y < 432:
                guy.x = 230
            elif guy.x <= 265 and guy.x > 230 and guy.y < 400:
                guy.x= 265
            elif guy.x <= 325 and guy.x > 315 and guy.y < 368:
                guy.x = 325
            elif guy.x <= 325 and guy.x >= 315 and guy.y > 464:
                guy.x = 325
            elif guy.x <= 455 and guy.y + 10 > 178 or guy.y < 110:
                guy.x = 455
            else:
                guy.x = guy.x - 5
    if (jump == False) and (guy.y > ground + 25):
        if Ablejump == 0:
            Ablejump = 1
        guy.y = guy.y - 10
        height = 0
        guy.frame = (guy.frame) % 2 + 7
        if(guy.y <= ground + 25):
            guy.y = ground + 25
            Ablejump = 0
    elif jump:
        if top <= guy.y + 25:
            jump = False
            guy.y = top
        elif height < 60:
            guy.y = guy.y + 5
            height = height + 10
            Guyframe = 6
        elif height >= 60:
            Guyframe = 7
            jump = False
            height = 0
    elif jump == False and guy.y < ground + 25 and guy.y + 25 < top:
        guy.y = ground + 25
                

    delay(0.04)
    update_canvas()
    handle_events()

running = False
