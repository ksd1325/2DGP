

from class_file import*
from pico2d import*
from read_or_write import*
import game_framework

import block
import fake
import morejumping
import stage2
name = "stage2_1"

#open_canvas()

#Bulletimage = None
def update():
    pass
def pause():
    pass
def resume():
    pass
def draw():
    pass
def exit():
    global guy
    global dialogue
    global bullet
    global enemy
    global bar
    global map2_1
    global savezone
    global blank
    global Thorn
    del(dialogue)
    del(bullet)
    del(enemy)
    del(bar)
    del(Thorn)
    del(map2_1)
    del(savezone)
    del(blank)
    del(guy)
    pass
def enter():
    global guy
    global bar
    global font
    global blank
    global Thorn
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map2_1
    global running
    global candia

    blank = load_image('blank.png')
    line = load_image('Line.png')
    Thorn = load_image('Thorn(32x32).png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy('guy_playing')
    reset_guy_playing()
    dialogue = Dialog()
    bar = Bar(guy.stage)
    enemy = Enemy(guy.stage)
    bullet = []

    showboundary = 0
    candia = 0
    map2_1 = load_image('2-1.png')


    font = load_font('HYTBRB.TTF')
    main()



def morejump():
    if guy.stage == 3:
        for p in range(5):
            for q in range(4):
                if morejumping.item[p][0] == 0:
                    Itemimage.draw(morejumping.item[p][1], morejumping.item[p][2])
                elif morejumping.item[p][0] == 1:
                    morejumping.item[p][3] += 1
                    if morejumping.item[p][3] == 100:
                        morejumping.item[p][3] = 0
                        morejumping.item[p][0] = 0
                if morejumping.item[p][0] == 0 and morejumping.item[p][1] >= guy.body[0] and  morejumping.item[p][1] <= guy.body[2] and  morejumping.item[p][2] >= guy.body[3] and  morejumping.item[p][2] <= guy.body[1] :
                    morejumping.item[p][0] = 1
                    guy.ablejump = 1
    elif guy.stage == 4:
        if morejumping.item[5][0] == 0:
            Itemimage.draw(morejumping.item[5][1], morejumping.item[5][2])
        elif morejumping.item[5][0] == 1:
            morejumping.item[5][3] += 1
            if morejumping.item[5][3] == 100:
                morejumping.item[5][3] = 0
                morejumping.item[5][0] = 0
        if morejumping.item[5][0] == 0 and morejumping.item[5][1] >= guy.body[0] and  morejumping.item[5][1] <= guy.body[2] and  morejumping.item[5][2] >= guy.body[3] and  morejumping.item[5][2] <= guy.body[1] :
            morejumping.item[5][0] = 1
            guy.ablejump = 1





def handle_events():
    global running
    global ground
    global top
    global bullet
    global showboundary
    global candia
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                    close_canvas()
                    running = False
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    guy.move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    guy.move = 2
                    guy.state = 0
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet(guy.x, guy.y, guy.state, guy.stage)]
                elif event.key == SDLK_x:
                    guy.step = False
                    saveY = guy.y
                    guy.jump = True
                    guy.ablejump = guy.ablejump + 1
                    if guy.ablejump > 2:
                        guy.jump = False
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

            if guy.stage == 7 or guy.stage == 8:
                if event.key == SDLK_n:
                    guy.x = 100
                    guy.y = 500
                    if guy.stage == 7 :
                        guy.stage = 8
                    elif guy.stage == 8:
                        guy.stage = 9
                
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and guy.move == 1:
                guy.move = 0
            elif event.key == SDLK_LEFT and guy.move == 2:
                guy.move = 0
            elif event.key == SDLK_x:
                guy.jump = False

def drawThorn():
    for p in range(26):
        for r in range(19):
            if block.Maparr[guy.stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[guy.stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[guy.stage - 1][p][r][3],  block.Maparr[guy.stage - 1][p][r][2])
            if block.Maparr[guy.stage - 1][p][r][0] == 6:
                savezone.draw(block.Maparr[guy.stage - 1][p][r][3], block.Maparr[guy.stage - 1][p][r][2])

def main():
    global guy
    global bar
    global font
    global Boss
    global blank
    global Thorn
    global tile
    global Itemimage
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map2_1
    global Bossframe
    global running
    global candia


    fake.redefine()
    global saveY
    while(running):
        clear_canvas()

        if guy.step == False and guy.jump == False:
            guy.y = guy.y - 10
        elif guy.step == True:
            guy.ablejump =0

        if guy.stage == 10:
            map2_1.draw(400, 302)

            if guy.x > block.Maparr[0][1][0][3] or fake.Fake10[0][0] == 1 :
                for p in range(10):
                    fake.Fake10[p][0] = 1
                    if fake.Fake10[p][0] == 1:
                        Thorn.clip_draw(32 * fake.Fake10[p][1], 0, 32, 32, fake.Fake10[p][2], fake.Fake10[p][3])
            if guy.x < 0:
                write(2, 790, guy.y, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step)
                game_framework.change_state(stage2)
        drawThorn()




        if(guy.move == False and guy.jump == False and guy.step == True):
            guy.frame = (guy.frame + 1) % 2
        elif(guy.move == 1):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove and guy.stage != 8:
                guy.x += 5
            if guy.stage == 8:
                for p in range(100):
                    fake.Fake8[p][2] -= 16




        elif(guy.move == 2):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove:
                guy.x -= 5
            if(guy.stage == 1 and guy.x < 5):
                guy.x += 5

        if (guy.jump == False and guy.step == False) :
            if guy.ablejump == 0:
                guy.ablejump = 1
            guy.height = 0

        if guy.jump :
            #print("guy.jump")
            if guy.height < 80:
                guy.y += 10
                guy.height += 10
                guy.frame = 6
            elif guy.height >= 80:
                guy.frame = 7
                guy.jump = False
                guy.height = 0
        elif guy.jump == False and guy.step == False :
                guy.frame = (guy.frame) % 2 + 7


        if showboundary == 1 :
            for p in range(guy.rangex, guy.rangex +1):
                for q in range(guy.rangey, guy.rangey + 1):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
            for p in range(guy.rangex, guy.rangex +1):
                for q in range(guy.rangey, guy.rangey + 1):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                        draw_rectangle(block.Maparr[guy.stage - 1][p][q][1] + 16,block.Maparr[guy.stage - 1][p][q][4] + 16, block.Maparr[guy.stage - 1][p][q][3] + 16,block.Maparr[guy.stage - 1][p][q][2] + 16)



        bar.update(guy)
        enemy.update(bullet)
        morejump()
        font.draw(10,520,'%2d' % guy.body[0])
        font.draw(10,500,'%2d' % guy.body[2])
        font.draw(10,470,'%2d' % guy.y)
        guy.update()
        draw_rectangle(guy.body[0], guy.body[3], guy.body[2], guy.body[1])
        if bullet != None:
            for i in bullet:
                i.update(bullet)
        line.draw(400, 15)
        line.draw(400, 585)
        update_canvas()
        handle_events()
        delay(0.04)

    running = False


if __name__ == '__main__':
    main()

