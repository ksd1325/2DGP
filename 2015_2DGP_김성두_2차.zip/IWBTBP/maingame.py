from pico2d import*

import block
import fake
import morejumping

open_canvas()

#Bulletimage = None
Boss = load_image('Boss(87X98).png')
blank = load_image('blank.png')
line = load_image('Line.png')
Thorn = load_image('Thorn(32x32).png')
tile = load_image('Tile(32x32).png')
Itemimage = load_image('Morejumping(10x10).png')
savezone = load_image('Save(32x32).png')



class Guy:
    global Ablejump
    global checkbar

    def __init__(self):
        self.Guyimage = load_image('Guy(25X23).png')
        self.frame = 0
        self.state = 0
        self.canMove = True
        self.x, self.y = 0, 176+25
        self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
        self.body = [self.x - 30, self.y + 11, self.x + 10, self.y - 20]
        self.step = False
    def draw(self):
        self.Guyimage.clip_draw(25 * self.frame, self.state * 23, 25, 23, self.x, self.y)
    def update(self):
        global saveY , jump
        if self.state == 0:
            self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
            self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        elif self.state == 1:
            self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
            self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        for p in range(0, 26):
            for q in range(0, 19):
                if p <= 24 and block.Maparr[stage - 1][p+1][q][0] == 1:
                    if (Move == 1 and guy.body[0] < block.Maparr[stage - 1][p+1][q][3] + 16 and guy.body[2]+5 > block.Maparr[stage - 1][p+1][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p+1][q][4] + 16 and guy.body[3] < block.Maparr[stage - 1][p+1][q][2] + 16):
                        #print("collision")
                        if self.canMove == True:
                            guy.x -= 5
                        elif self.canMove == False:
                            guy.x = block.Maparr[stage - 1][p+1][q][1] + 16 - 15
                        self.canMove = False
                    else:
                        self.canMove = True
                elif block.Maparr[stage - 1][p-1][q][0] == 1 and p >= 0:
                    if (Move == 2 and guy.body[0]- 10 < block.Maparr[stage - 1][p-1][q][3] + 16 and guy.body[2] > block.Maparr[stage - 1][p-1][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p-1][q][4] + 16 and guy.body[3] < block.Maparr[stage - 1][p-1][q][2] + 16):
                        #print("collision")
                        if self.canMove == True:
                            guy.x += 5
                        elif self.canMove == False:
                            guy.x = block.Maparr[stage - 1][p-1][q][3] + 16 + 15
                        self.canMove = False

                    else:
                        self.canMove = True
                        if (Move == 2 and block.Maparr[stage - 1][p][q][0] == 1 and guy.body[0]- 5 < block.Maparr[stage - 1][p][q][3] + 16 and guy.body[2] > block.Maparr[stage - 1][p][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p][q][4] + 16 and guy.body[3] < block.Maparr[stage - 1][p][q][2] + 16) :
                            guy.x = block.Maparr[stage - 1][p][q][3] + 16 + 15
                            self.canMove = False

                if block.Maparr[stage - 1][p][q][0] == 1:
                    if (guy.body[0] < block.Maparr[stage - 1][p][q][3] + 16 and guy.body[2] > block.Maparr[stage - 1][p][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p][q][4] + 16 and guy.body[3] < block.Maparr[stage - 1][p][q][2] + 16):
                        #print("col",jump)
                        self.step = True
                        if Move == 1:
                            guy.x += 5
                        elif Move == 2:
                            guy.x -= 5
                        if ( guy.y >= block.Maparr[stage - 1][p][q][2] + 16  and jump == False):
                            guy.y = block.Maparr[stage - 1][p][q][2] + 27
                        elif ( guy.y <= block.Maparr[stage - 1][p][q][2] -16  and jump):
                            guy.y = block.Maparr[stage - 1][p][q][2] - 27
                            jump = False
                            self.step = False
                            if(stage == 4 and p == 1 and q == 8):
                                fake.Fake4[0][0] = 1
                            elif stage == 4 and p == 2 and q == 10:
                                fake.Fake4[1][0] = 1

                elif block.Maparr[stage - 1][p][q - 1][0] != 1:
                    if (guy.body[0] + 18 < block.Maparr[stage - 1][p][q][3] + 16 and guy.body[2]- 19 > block.Maparr[stage - 1][p][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p][q][4] + 16 and guy.body[3] - 1 < block.Maparr[stage - 1][p][q][2] + 16):
                        self.step = False

        if (stage == 4 or stage == 5 or stage == 6) and guy.x > bar.bar_x - 64 and guy.x < bar.bar_x + 64 and guy.y >= bar.bar_y + 10 and guy.y <= bar.bar_y + 20:
            self.step = True
            if jump == False:
                guy.y = bar.bar_y + 12
            if bar.checkbar == 0:
                bar.checkbar = 1

    def get_bb(self):
        return self.head[0], self.head[1], self.head[2], self.head[3], self.body[0], self.body[1], self.body[2], self.body[3]

def collide(a, b, stage, x, y):
    head_left, head_top, head_right, head_bottom, body_left, body_top, body_right, body_bottom = a.get_bb()
    map_left, map_top, map_right, map_bottom = b.get_bb(stage - 1, x, y - 2)
    global collision
    collision = [0 for i in range(4)]
    if (head_left <= map_right or body_left <= map_right) : collision[0] = 1
    if (head_right >= map_left or body_right >= map_left) : collision[1] = 1
    if head_top >= map_bottom :  collision[2] = 1
    if body_bottom <= map_top :  collision[3] = 1


class Dialog():
    def __init__(self):
        self.diaimage = load_image('Dialog.png')
        self.dialog = 0

    def show(self):
        if self.dialog != 0:
            self.diaimage.draw(400, 150)
            if self.dialog == 1:
                font.draw(200, 180, 'Hello, I am Programmer K.')
            elif self.dialog == 2:
                font.draw(200, 180, 'There are too Much Error and Bug.')
            elif self.dialog == 3:
                font.draw(200, 180, 'Please Help me.')
            elif self.dialog == 4:
                font.draw(200, 180, 'You can Shot press button Z.')
                font.draw(200, 150, 'And can Jump press button X.')
            elif self.dialog == 5:
                font.draw(200, 180, 'If you want to Save,')
                font.draw(200, 150, 'press UP in Save Zone.')
            elif self.dialog == 6:
                font.draw(200, 180, 'You can Restart press button R.')
            elif self.dialog == 7:
                font.draw(200, 180, 'Gook LUCK, GUY.')
            elif self.dialog == 8:
                self.dialog = 0


class Bullet():
    Bulletimage = None
    def __init__(self):
        self.x = guy.x
        self.y = guy.y + 1
        self.length = 0
        self.direction = guy.state
        if Bullet.Bulletimage == None:
            Bullet.Bulletimage = load_image('Bullet(4x4).png')
    def update(self):
        if self.direction == 0:
            self.length -= 20
            self.x -= 20
            if self.length < -500:
                delete()
        elif self.direction == 1:
            self.length += 20
            self.x += 20
            if self.length > 500:
                delete()
        for p in range(26):
            for q in range(19):
                if self.x >= block.Maparr[stage - 1][p][q][1] and self.x <= block.Maparr[stage - 1][p][q][3] + 32 and self.y <= block.Maparr[stage - 1][p][q][2] + 16 and self.y >= block.Maparr[stage - 1][p][q][4] + 16 and block.Maparr[stage - 1][p][q][0] == 1:
                    bullet.remove(self)
        self.Bulletimage.draw(self.x, self.y)


class Bar():
    Barimage = None
    def __init__(self):
        self.checkbar = 0
        self.bar_x = 704
        self.bar_y = 100
        if Bar.Barimage == None:
            Bar.Barimage = load_image('Bar(128x10).png')

    def update(self):
        if stage == 4 or stage == 5 or stage == 6:
            if bar.checkbar == 1:
                bar.bar_y += 2
                if guy.step == True and guy.x < bar.bar_x + 64 and guy.x > bar.bar_x - 64 and guy.y >= bar.bar_y + 10 and guy.y < bar.bar_y + 30:
                    guy.y += 2
            if stage == 6 and bar.bar_y > block.Maparr[5][0][9][2]:
                bar.checkbar = 2
            bar.Barimage.draw(bar.bar_x, bar.bar_y)

class Enemy():
    global stage
    Enemyimage = None

    def __init__(self):
        self.stage = 1
        self.ex = 19 * 32 + 16
        self.ey = 2 * 32 + 16
        self.box = [self.ex - 15, self.ey + 15, self.ex + 15, self.ey - 15]
        self.frame = 0
        self.state = 0
        self.count = 0
        self.crash = 0
        if Enemy.Enemyimage == None:
            Enemy.Enemyimage = load_image('Enemy(30x30).png')

    def update(self):
        if(self.stage != stage):
            self.stage = stage
            self.count = 0
            self.state = 0
            self.frame = 0
            self.crash = 0
        if self.crash == 0:
            if self.count == 0:
                if self.stage == 2:
                    self.ex = 19 * 32 + 16
                    self.ey = 2 * 32 + 16
                elif self.stage == 3:
                    self.ex = 21 * 32 + 16
                    self.ey = 16 * 32 + 16
                elif self.stage == 4:
                    self.ex = 8 * 32 + 16
                    self.ey = 9 * 32 + 16
                elif self.stage == 11:
                    self.ex = 8 * 32 + 16
                    self.ey = 7 * 32 + 16

                self.count = 1
            if self.state == 0:
                self.ex += 5
                self.frame = (self.frame + 1) % 2
                if self.ex > 23 * 32 + 16 and self.stage == 2:
                    self.state = 1
                elif self.ex > 21 * 32 + 16 and self.stage == 3:
                    self.state = 1
                elif self.ex > 12 * 32 + 16 and self.stage == 4:
                    self.state = 1
                elif self.ex > 10 * 32 + 16 and self.stage == 11:
                    self.state = 1
            elif self.state == 1:
                self.ex -= 5
                self.frame = (self.frame + 1) % 2
                if self.ex < 13 * 32 + 16 and self.stage == 2:
                    self.state = 0
                elif self.ex < 16 * 32 + 16 and self.stage == 3:
                    self.state = 0
                elif self.ex < 6 * 32 + 16 and self.stage == 4:
                    self.state = 0
                elif self.ex < 5 * 32 + 16 and self.stage == 11:
                    self.state = 0

            self.box = [self.ex - 15, self.ey + 15, self.ex + 15, self.ey - 15]
        for i in bullet:
            if i.x >= self.box[0] and i.x <= self.box[2] and i.y <= self.box[1] and i.y >= self.box[3] and self.crash == 0:
                bullet.remove(i)
                self.crash = 1
        if self.crash == 1:
            if self.count == 1:
                self.frame = 1
                self.count = 2
            self.frame += 1
            if self.frame > 4:
                self.state = 2

        if self.state < 2 and (self.stage == 2 or self.stage == 3 or self.stage == 4 or self.stage == 11):
            self.Enemyimage.clip_draw(30 * self.frame, 30 * self.state, 30, 30, self.ex, self.ey)


def morejump():
    global Ablejump
    if stage == 3:
        for p in range(5):
            for q in range(4):
                if morejumping.item[p][0] == 0:
                    Itemimage.draw(morejumping.item[p][1], morejumping.item[p][2])
                elif morejumping.item[p][0] == 1:
                    morejumping.item[p][3] += 1
                    if morejumping.item[p][3] == 100:
                        morejumping.item[p][3] = 0
                        morejumping.item[p][0] = 0
                if morejumping.item[p][0] == 0 and morejumping.item[p][1] >= guy.body[0] and  morejumping.item[p][1] <= guy.body[2] and  morejumping.item[p][2] >= guy.body[3] and  morejumping.item[p][2] <= guy.body[1] :
                    morejumping.item[p][0] = 1
                    Ablejump = 1
    elif stage == 4:
        if morejumping.item[5][0] == 0:
            Itemimage.draw(morejumping.item[5][1], morejumping.item[5][2])
        elif morejumping.item[5][0] == 1:
            morejumping.item[5][3] += 1
            if morejumping.item[5][3] == 100:
                morejumping.item[5][3] = 0
                morejumping.item[5][0] = 0
        if morejumping.item[5][0] == 0 and morejumping.item[5][1] >= guy.body[0] and  morejumping.item[5][1] <= guy.body[2] and  morejumping.item[5][2] >= guy.body[3] and  morejumping.item[5][2] <= guy.body[1] :
            morejumping.item[5][0] = 1
            Ablejump = 1


    
#global Guyframe
Guyframe = 0
Bossframe  = 0
map1 = load_image('1.png')
map2 = load_image('2.png')
map2_1 = load_image('2-1.png')
map3 = load_image('3.png')
map4 = load_image('4.png')
map5 = load_image('5.png')
map6 = load_image('6.png')
map6_1 = load_image('6-1.png')
map7 = load_image('7.png')
map8 = load_image('8.png')
map9 = load_image('9.png')
        

stage = int(1)
tx = 0
ty = 0
collision = [0 for i in range(4)]

def save():
    global sx
    global sy
    global sstage
    global sground
    global stop
    global stage
    global ground
    global top
    sx = guy.x
    sy = guy.y
    sstage = stage
    sground = ground
    stop = top

def load():
    global sx
    global sy
    global sstage
    global sground
    global stop
    global stage
    global ground
    global top
    global Ablejump
    stage = sstage
    ground = sground
    guy.x = sx
    guy.y = sy
    top = stop
    Ablejump = 0


def handle_events():
    global running
    global Move
    global jump
    global Ablejump
    global ground
    global height
    global top
    global saveY
    global bullet
    global showboundary
    global stage
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                    close_canvas()
                    running = False
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    Move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    Move = 2
                    guy.state = 0
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet()]
                elif event.key == SDLK_x:
                    guy.step = False
                    saveY = guy.y
                    jump = True
                    Ablejump = Ablejump + 1
                    if Ablejump > 2:
                        jump = False
                elif event.key == SDLK_s:
                    save()
                elif event.key == SDLK_r:
                    load()
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

            if stage == 7 or stage == 8:
                if event.key == SDLK_n:
                    guy.x = 100
                    guy.y = 500
                    if stage == 7 :
                        stage = 8
                    elif stage == 8:
                        stage = 9
                
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and Move == 1:
                Move = 0
            elif event.key == SDLK_LEFT and Move == 2:
                Move = 0
            elif event.key == SDLK_x:
                jump = False

def delete():
    for i in bullet:
        if i.length > 500 or i.length < -500:
            bullet.remove(i)

def deletebullet():
    for i in bullet:
        bullet.remove(i)

def drawThorn():
    for p in range(26):
        for r in range(19):
            if block.Maparr[stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[stage - 1][p][r][3],  block.Maparr[stage - 1][p][r][2])
                
            
ground = 176
running = True
guy = Guy()
dialogue = Dialog()
bar = Bar()
enemy = Enemy()
bullet = []
guy.x = 10
guy.y = 176 + 25

#guy.x = 520
#guy.y = 500
guy.state = 1
Move = 0
jump = False
Ablejump = 0
height = 0
top = 800
sx = 0
sy = 0
sstage = 1
stop = 0
sground = 0
candia = 0
showboundary = 0
font = load_font('HYTBRB.TTF')

fake.redefine()
global saveY
while(running):
    clear_canvas()

    if guy.step == False and jump == False:
        guy.y = guy.y - 10
    elif guy.step == True:
        Ablejump =0
    
    if stage == 1:
        map1.draw(400, 302)
        Boss.clip_draw(87 * Bossframe, 0, 87, 98, 450, 176 + 63)
        if guy.x > 800:
            stage = 2
            guy.x = 0
            deletebullet()
        if guy.x >= 420 and guy.x <= 480:
            candia = 1
        else:
            candia = 0
            
    elif stage == 2:
        map2.draw(400, 302)
        if guy.y < 0:
            stage = 3
            guy.y = 600
            deletebullet()
        elif guy.x < 0 :
            stage = 1
            guy.x = 790
            deletebullet()
        elif guy.x > 800 :
            guy.x = 0
            stage = 10
            deletebullet()
        if guy.x > block.Maparr[1][9][0][1] and fake.Fake2[0][0] == 0:
            fake.Fake2[0][0] = 1
        if guy.x > block.Maparr[1][14][0][3] and fake.Fake2[1][0] == 0:
            fake.Fake2[1][0] = 1
        if guy.x > block.Maparr[1][19][0][3] and guy.y > block.Maparr[1][0][3][2] and fake.Fake2[2][0] == 0:
            fake.Fake2[2][0] = 1

        if fake.Fake2[0][0] == 1:
            fake.Fake2[0][3] += 15
            if fake.Fake2[0][3] > 700:
                fake.Fake2[0][0] = 2

        if fake.Fake2[1][0] == 1:
            fake.Fake2[1][2] += 16
            if fake.Fake2[1][2] >= block.Maparr[1][16][0][3]:
                fake.Fake2[1][0] = 2

        if fake.Fake2[2][0] == 1:
            fake.Fake2[2][2] -= 16
            if fake.Fake2[2][2] < -30:
                fake.Fake2[2][0] = 2

        Thorn.clip_draw(32 * fake.Fake2[0][1], 0, 32, 32, fake.Fake2[0][2], fake.Fake2[0][3])
        Thorn.clip_draw(32 * fake.Fake2[1][1], 0, 32, 32, fake.Fake2[1][2], fake.Fake2[1][3])
        Thorn.clip_draw(32 * fake.Fake2[2][1], 0, 32, 32, fake.Fake2[2][2], fake.Fake2[2][3])

    elif stage == 10:
        map2_1.draw(400, 302)

        if guy.x > block.Maparr[0][1][0][3] or fake.Fake10[0][0] == 1 :
            for p in range(10):
                fake.Fake10[p][0] = 1
                if fake.Fake10[p][0] == 1:
                    Thorn.clip_draw(32 * fake.Fake10[p][1], 0, 32, 32, fake.Fake10[p][2], fake.Fake10[p][3])
        
    elif stage == 3:
        map3.draw(400, 302)
        if guy.x > 800:
            stage = 4
            guy.x = 0
            deletebullet()
        elif guy.y > 600:
            stage = 2
            guy.y = 0
            deletebullet()

        if guy.x > block.Maparr[2][4][0][3] and guy.y < block.Maparr[2][1][3][2] and fake.Fake3[0][0] == 0:
            fake.Fake3[0][0] = 1

        if guy.y < block.Maparr[2][2][3][2] and fake.Fake3[1][0] == 0:
            fake.Fake3[1][0] = 1

        if guy.x > block.Maparr[2][3][0][3] and  guy.y < block.Maparr[2][0][4][2] and fake.Fake3[2][0] == 0:
            fake.Fake3[2][0] = 1

        if guy.x > block.Maparr[2][16][0][3] + 25 and fake.Fake3[3][0] == 0:
            fake.Fake3[3][0] = 1

        if guy.x > block.Maparr[2][20][0][3] and guy.y < block.Maparr[2][0][11][2] and fake.Fake3[4][0] == 0:
            fake.Fake3[4][0] = 1


        if fake.Fake3[0][0] == 1:
            fake.Fake3[0][2] += 5
            if fake.Fake3[0][2] > block.Maparr[2][11][0][3]:
                fake.Fake3[0][2] = block.Maparr[2][11][0][3]
                fake.Fake3[0][0] = 2

        if fake.Fake3[1][0] == 1:
            fake.Fake3[1][2] -= 16
            if fake.Fake3[1][2] == block.Maparr[2][1][0][3]:
                fake.Fake3[1][0] = 2

        if fake.Fake3[2][0] == 1:
            fake.Fake3[2][3] -= 32
            if fake.Fake3[2][3] < - 10:
                fake.Fake3[2][0] = 2

        if fake.Fake3[3][0] == 1:
            fake.Fake3[3][3] -= 16
            if fake.Fake3[3][3] < - 10:
                fake.Fake3[3][0] = 2

        if fake.Fake3[4][0] == 1:
            fake.Fake3[4][2] += 16
            if fake.Fake3[4][2] == block.Maparr[2][22][0][3]:
                fake.Fake3[4][0] = 2


        Thorn.clip_draw(32 * fake.Fake3[0][1], 0, 32, 32, fake.Fake3[0][2], fake.Fake3[0][3])
        Thorn.clip_draw(32 * fake.Fake3[1][1], 0, 32, 32, fake.Fake3[1][2], fake.Fake3[1][3])
        Thorn.clip_draw(32 * fake.Fake3[2][1], 0, 32, 32, fake.Fake3[2][2], fake.Fake3[2][3])
        Thorn.clip_draw(32 * fake.Fake3[3][1], 0, 32, 32, fake.Fake3[3][2], fake.Fake3[3][3])
        Thorn.clip_draw(32 * fake.Fake3[4][1], 0, 32, 32, fake.Fake3[4][2], fake.Fake3[4][3])

    elif stage == 4:
        map4.draw(400, 302)
        if guy.y > 600:
            stage = 5
            guy.y = 10
            bar.bar_y = -10
            deletebullet()
        elif guy.x < 0 and guy.y < 176 + 63:
            stage = 3
            guy.x = 790
            deletebullet()

        if guy.x > block.Maparr[3][3][0][3] and guy.y >= block.Maparr[3][0][6][4] and guy.y <= block.Maparr[3][0][8][2] and fake.Fake4[2][0] == 0:
            fake.Fake4[2][0] = 1
        if guy.x > block.Maparr[3][4][0][3] and guy.y >= block.Maparr[3][0][6][4] and guy.y <= block.Maparr[3][0][8][2] and fake.Fake4[3][0] == 0:
            fake.Fake4[3][0] = 1
        if guy.x > block.Maparr[3][3][0][3] - 16 and guy.y >= block.Maparr[3][0][11][2] and fake.Fake4[4][0] == 0:
            fake.Fake4[4][0] = 1
        if guy.x > block.Maparr[3][5][0][3] and fake.Fake4[5][0] == 0:
            fake.Fake4[5][0] = 1
        if guy.x > block.Maparr[3][6][0][3] and fake.Fake4[6][0] == 0:
            fake.Fake4[6][0] = 1
        if guy.x > block.Maparr[3][11][0][3] and fake.Fake4[7][0] == 0:
            fake.Fake4[7][0] = 1




        if fake.Fake4[0][0] == 1:
            tile.clip_draw(32 * fake.Fake4[0][1], 0, 32, 32, fake.Fake4[0][2], fake.Fake4[0][3])
        if fake.Fake4[1][0] == 1:
            tile.clip_draw(32 * fake.Fake4[1][1], 0, 32, 32, fake.Fake4[1][2], fake.Fake4[1][3])
        if fake.Fake4[2][0] == 1:
            Thorn.clip_draw(32 * fake.Fake4[2][1], 0, 32, 32, fake.Fake4[2][2], fake.Fake4[2][3])
        if fake.Fake4[3][0] == 1:
            Thorn.clip_draw(32 * fake.Fake4[3][1], 0, 32, 32, fake.Fake4[3][2], fake.Fake4[3][3])
        if fake.Fake4[4][0] == 1:
            Thorn.clip_draw(32 * fake.Fake4[4][1], 0, 32, 32, fake.Fake4[4][2], fake.Fake4[4][3])
        if fake.Fake4[5][0] == 1:
            Thorn.clip_draw(32 * fake.Fake4[5][1], 0, 32, 32, fake.Fake4[5][2], fake.Fake4[5][3])
        if fake.Fake4[6][0] == 1:
            Thorn.clip_draw(32 * fake.Fake4[6][1], 0, 32, 32, fake.Fake4[6][2], fake.Fake4[6][3])
        if fake.Fake4[7][0] == 1:
            if guy.x - fake.Fake4[7][2] > 0:
                fake.Fake4[7][2] = guy.x
                if fake.Fake4[7][2] >= block.Maparr[3][14][0][3]:
                    fake.Fake4[7][2] = block.Maparr[3][14][0][3]
            elif guy.x - fake.Fake4[7][2] < 0:
                fake.Fake4[7][2] = guy.x
                if fake.Fake4[7][2] <= block.Maparr[3][12][0][3]:
                    fake.Fake4[7][2] = block.Maparr[3][12][0][3]


        Thorn.clip_draw(32 * fake.Fake4[7][1], 0, 32, 32, fake.Fake4[7][2], fake.Fake4[7][3])


    elif stage == 5:
        map5.draw(400, 302)
        if guy.y > 600:
            stage = 6
            guy.y = 10
            bar.bar_y = -10
            deletebullet()
        elif guy.y < 0:
            stage = 4
            guy.y = 600
            deletebullet()
        elif guy.x < 5:
            guy.x = 5

        if guy.x < block.Maparr[4][19][0][3] and fake.Fake5[0][0] == 0:
            fake.Fake5[0][0] = 1
        if guy.y < block.Maparr[4][0][6][2]:
            if guy.x < block.Maparr[4][18][0][3] and fake.Fake5[1][0] == 0:
                fake.Fake5[1][0] = 1
            if guy.x < block.Maparr[4][17][0][3] and fake.Fake5[2][0] == 0:
                fake.Fake5[2][0] = 1
            if guy.x < block.Maparr[4][16][0][3] and fake.Fake5[3][0] == 0:
                fake.Fake5[3][0] = 1
            if guy.x < block.Maparr[4][15][0][3] and fake.Fake5[4][0] == 0:
                fake.Fake5[4][0] = 1
            if guy.x < block.Maparr[4][14][0][3] and fake.Fake5[5][0] == 0:
                fake.Fake5[5][0] = 1
            if guy.x < block.Maparr[4][13][0][3] and fake.Fake5[6][0] == 0:
                fake.Fake5[6][0] = 1

        for p in range(7):
            if fake.Fake5[p][0] == 1:
                Thorn.clip_draw(32 * fake.Fake5[p][1], 0, 32, 32, fake.Fake5[p][2], fake.Fake5[p][3])



    elif stage == 6:
        map6.draw(400, 302)
        if guy.x > 800:
            stage = 7
            guy.x = 0
            deletebullet()
        elif guy.x < 0:
            guy.x = 800
            stage = 11
            deletebullet()

        if guy.y > block.Maparr[5][0][6][2] and guy.x < block.Maparr[5][21][0][3] and fake.Fake6[0][0] == 0:
            fake.Fake6[0][0] = 1

        if fake.Fake6[0][0] == 1:
            fake.Fake6[0][3] -= 32
            if fake.Fake6[0][3] < - 30:
                fake.Fake6[0][0] = 2



        Thorn.clip_draw(32 * fake.Fake6[0][1], 0, 32, 32, fake.Fake6[0][2], fake.Fake6[0][3])


    elif stage == 11:
        map6_1.draw(400,302)
        if guy.x > 800:
            stage = 6
            guy.x = 0
            deletebullet()

    elif stage == 7:
        map7.draw(400, 302)
        if guy.x < 0:
            stage = 6
            guy.x = 800
            deletebullet()

    elif stage == 8:
        map8.draw(400, 302)

        for p in range(100):
            fake.Fake8[p][2] -= 5
            if(fake.Fake8[p][2] > - 20 and fake.Fake8[p][2] < 820):
                Thorn.clip_draw(32 * fake.Fake8[p][1], 0, 32, 32, fake.Fake8[p][2], fake.Fake8[p][3])
            if(fake.Fake8[99][2] < - 20):
                stage = 9
                guy.x = 100
                guy.y = 100

    elif stage == 9:
        map9.draw(400, 302)

    drawThorn()
    
    
        

    if(Move == False and jump == False and guy.step == True):
        guy.frame = (guy.frame + 1) % 2
    elif(Move == 1):
        if jump == False and guy.step == True:
            guy.frame = (guy.frame + 1) % 4 + 2
        if guy.canMove and stage != 8:
            guy.x += 5
        if stage == 8:
            for p in range(100):
                fake.Fake8[p][2] -= 16



                
    elif(Move == 2):
        if jump == False and guy.step == True:
            guy.frame = (guy.frame + 1) % 4 + 2
        if guy.canMove:
            guy.x -= 5
        if(stage == 1 and guy.x < 5):
            guy.x += 5
         
    for p in range(0, 26):
        for q in range(0, 18):
            if block.Maparr[stage - 1][p][q][0] == 6:
                savezone.draw(block.Maparr[stage - 1][p][q][3], block.Maparr[stage - 1][p][q][2])
            if (jump == False and guy.step == False) :
                if Ablejump == 0:
                    Ablejump = 1
                height = 0

    if jump :
        #print("jump")
        if height < 80:
            guy.y += 10
            height += 10
            guy.frame = 6
        elif height >= 80:
            guy.frame = 7
            jump = False
            height = 0
    elif jump == False and guy.step == False :
            guy.frame = (guy.frame) % 2 + 7
   
    if showboundary == 1 :
        for p in range(0, 26):
            for q in range(0, 19):
                if(block.Maparr[stage - 1][p][q][0] == 1):
                    blank.draw(block.Maparr[stage - 1][p][q][3], block.Maparr[stage - 1][p][q][2])
        for p in range(0, 26):
            for q in range(0, 19):
                if(block.Maparr[stage - 1][p][q][0] == 1):
                    blank.draw(block.Maparr[stage - 1][p][q][3], block.Maparr[stage - 1][p][q][2])
                    draw_rectangle(block.Maparr[stage - 1][p][q][1] + 16,block.Maparr[stage - 1][p][q][4] + 16, block.Maparr[stage - 1][p][q][3] + 16,block.Maparr[stage - 1][p][q][2] + 16)


    bar.update()
    enemy.update()
    morejump()
    font.draw(10,520,'%2d' % guy.body[0])
    font.draw(10,500,'%2d' % guy.body[2])
    font.draw(10,470,'%2d' % guy.y)
    #print(Ablejump)
    guy.update()
    draw_rectangle(guy.body[0], guy.body[3], guy.body[2], guy.body[1])
    guy.draw()
    if bullet != None:
        for i in bullet:
            i.update()
    line.draw(400, 15)
    line.draw(400, 585)
    dialogue.show()
    update_canvas()
    handle_events()
    delay(0.04)

running = False


