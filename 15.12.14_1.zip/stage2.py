

from class_file import*
from pico2d import*
from read_or_write import*
import game_framework

import block

import stage1
import stage2
import stage2_1
import stage3
import stage4
import stage5
import stage6
import stage6_1
import stage7
import stage8
import stage9
import time

import logo
name = "stage2"

def update(frame_time):
    pass
def pause():
    pass
def resume():
    pass
def draw(frame_time):
    pass
def exit():
    global guy
    global dialogue
    global bullet
    global enemy
    global bar
    global map2
    global savezone
    global Thorn
    global fake
    del(fake)
    del(dialogue)
    del(bullet)
    del(enemy)
    del(bar)
    del(Thorn)
    del(map2)
    del(savezone)
    del(guy)
    global background_s
    del (background_s)
    pass
def enter():
    global guy
    global bar
    global font
    global Thorn
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global map2
    global running
    global candia


    game_framework.reset_time()
    guy = Guy('guy_playing')
    reset_guy_playing(guy.savestage, guy.savestate, guy.savex, guy.savey, guy.savedeath)
    line = load_image('./image/Line.png')
    Thorn = load_image('./image/Thorn(32x32).png')
    savezone = load_image('./image/Save(32x32).png')
    running = True
    bar = Bar(guy.stage)
    dialogue = Dialog()
    enemy = Enemy(guy.stage)
    bullet = []
    fake_data = read_fake()
    global fake
    fake = [Fake(guy, fake_data, i + 1) for i in range(fake_data[str(guy.stage)]['count'])]

    global cansave
    cansave = False
    candia = 0
    map2 = load_image('./image/2.png')

    global background_s
    background_s = load_wav('./sound/bluefield.ogg')
    background_s.set_volume(20)
    background_s.repeat_play()

    font = load_font('./font/HYTBRB.TTF')
    main()






def handle_events(frame_time):
    global running
    global ground
    global top
    global bullet
    global showboundary
    global candia
    global cansave

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
            game_framework.quit()
        if event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            running = False
            guy.savedeath = guy.deathcount
            save(guy.savestage, guy.savestate, guy.savex, guy.savey, guy.savedeath)
            game_framework.change_state(logo)
        elif event.type == SDL_KEYDOWN and guy.state != guy.DEAD:
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    guy.move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    guy.move = 2
                    guy.state = 0
                elif event.key == SDLK_UP and cansave:
                    guy.savestage = guy.stage
                    guy.savestate = guy.state
                    guy.savex = guy.x
                    guy.savey = guy.y
                    guy.savedeath = guy.deathcount
                    save(guy.savestage, guy.savestate, guy.savex, guy.savey, guy.savedeath)
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet(guy.x, guy.y, guy.state, guy.stage)]
                    guy.shot_s.play()
                elif event.key == SDLK_x:
                    if guy.ablejump != 2:
                        guy.step = False
                        guy.jump = True
                        guy.ablejump += 1
                        guy.jump_s.play()
                    elif guy.ablejump > 2:
                        guy.jump = False
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and guy.move == 1:
                guy.move = 0
            elif event.key == SDLK_LEFT and guy.move == 2:
                guy.move = 0
            elif event.key == SDLK_x:
                guy.jump = False
        if event.type == SDL_KEYDOWN and event.key == SDLK_r:
            if guy.state != guy.DEAD:
                guy.deathcount += 1
            guy.savedeath = guy.deathcount
            write(guy.savestage, guy.savex, guy.savey, 0, 0, str(True), 0, 0, str(False), 0, str(False), guy.savestage, guy.savestate, guy.savex, guy.savey, guy.deathcount, guy.savedeath)
            load_data = load()
            if load_data == 1:
                game_framework.change_state(stage1)
            elif load_data == 2:
                game_framework.change_state(stage2)
            elif load_data == 3:
                game_framework.change_state(stage3)
            elif load_data == 4:
                game_framework.change_state(stage4)
            elif load_data == 5:
                game_framework.change_state(stage5)
            elif load_data == 6:
                game_framework.change_state(stage6)
            elif load_data == 7:
                game_framework.change_state(stage7)
            elif load_data == 8:
                game_framework.change_state(stage8)
            elif load_data == 9:
                game_framework.change_state(stage9)
            elif load_data == 10:
                game_framework.change_state(stage2_1)
            elif load_data == 11:
                game_framework.change_state(stage6_1)

def drawThorn():
    global cansave
    global guy
    for p in range(26):
        for r in range(19):
            if block.Maparr[guy.stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[guy.stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[guy.stage - 1][p][r][3],  block.Maparr[guy.stage - 1][p][r][2])
            if block.Maparr[guy.stage - 1][p][r][0] == 6:
                savezone.draw(block.Maparr[guy.stage - 1][p][r][3], block.Maparr[guy.stage - 1][p][r][2])
                if savezonecrash(guy, p, r):
                    cansave = True
                else:
                    cansave = False

def savezonecrash(guy, p, r):
    if guy.body[0] > block.Maparr[guy.stage - 1][p][r][3] + 16: return False
    if guy.body[2] < block.Maparr[guy.stage - 1][p][r][1] + 16: return False
    if guy.body[1] < block.Maparr[guy.stage - 1][p][r][4] + 16: return False
    if guy.body[3] > block.Maparr[guy.stage - 1][p][r][2] + 16: return False

    return True
def main():
    global guy
    global font
    global Thorn
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global map2
    global running
    global fake



    current_time = time.clock()
    frame_time = time.clock() - current_time
    while(running):
        clear_canvas()
        current_time += frame_time

        if guy.stage == 2:
            map2.draw(400, 302)
            if guy.y < 0:
                write(3, guy.x, 600, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step, guy.savestage, guy.savestate, guy.savex, guy.savey, guy.deathcount, guy.savedeath)
                game_framework.change_state(stage3)
            elif guy.x < 0 :
                write(1, 790, guy.y, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step, guy.savestage, guy.savestate, guy.savex, guy.savey, guy.deathcount, guy.savedeath)
                game_framework.change_state(stage1)
            elif guy.x > 800 :
                write(10, 10, guy.y, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step, guy.savestage, guy.savestate, guy.savex, guy.savey, guy.deathcount, guy.savedeath)
                game_framework.change_state(stage2_1)

        drawThorn()

        enemy.update(bullet, guy, frame_time)
        for i in fake:
            i.update(guy, fake, frame_time)
        guy.update(frame_time)
        if bullet != None:
            for i in bullet:
                i.update(bullet, frame_time)
        line.draw(400, 15)
        line.draw(400, 585)
        guy.show_deathcount()
        update_canvas()
        handle_events(frame_time)
        frame_time = time.clock() - current_time

    running = False


if __name__ == '__main__':
    enter()