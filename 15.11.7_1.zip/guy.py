


from pico2d import*
import json


import block
import fake


guy_data_file = open("guy_data.txt", "r")
guy_data = json.load(guy_data_file)





class Guy:

    guy_state_table = {
        'True' : True,
        'False': False
    }
    global checkbar
    global guy_data


    def __init__(self, choice_data):
        self.guyimage = load_image('Guy(25X23).png')
        self.frame = guy_data[choice_data]['frame']
        self.state = guy_data[choice_data]['state']
        self.canmove = Guy.guy_state_table[guy_data[choice_data]['canmove']]
        self.x, self.y = guy_data[choice_data]['x'], guy_data[choice_data]['y']
        self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
        self.body = [self.x - 30, self.y + 11, self.x + 10, self.y - 20]
        self.step = Guy.guy_state_table[guy_data[choice_data]['step']]
        self.stage = guy_data[choice_data]['stage']
        self.move = guy_data[choice_data]['move']
        self.jump = Guy.guy_state_table[guy_data[choice_data]['jump']]
        self.ablejump = guy_data[choice_data]['ablejump']
        self.height = guy_data[choice_data]['height']

    def draw(self):
        self.guyimage.clip_draw(25 * self.frame, self.state * 23, 25, 23, self.x, self.y)
    def update(self):
        if self.state == 0:
            self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
            self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        elif self.state == 1:
            self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
            self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        for p in range(0, 26):
            for q in range(0, 19):
                if p <= 24 and block.Maparr[self.stage - 1][p+1][q][0] == 1:
                    if (self.move == 1 and self.body[0] < block.Maparr[self.stage - 1][p+1][q][3] + 16 and self.body[2]+5 > block.Maparr[self.stage - 1][p+1][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p+1][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p+1][q][2] + 16):
                        #print("collision")
                        if self.canmove == True:
                            self.x -= 5
                        elif self.canmove == False:
                            self.x = block.Maparr[self.stage - 1][p+1][q][1] + 16 - 15
                        self.canmove = False
                    else:
                        self.canmove = True
                elif block.Maparr[self.stage - 1][p-1][q][0] == 1 and p >= 0:
                    if (self.move == 2 and self.body[0]- 10 < block.Maparr[self.stage - 1][p-1][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p-1][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p-1][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p-1][q][2] + 16):
                        #print("collision")
                        if self.canmove == True:
                            self.x += 5
                        elif self.canmove == False:
                            self.x = block.Maparr[self.stage - 1][p-1][q][3] + 16 + 15
                        self.canmove = False

                    else:
                        self.canmove = True
                        if (self.move == 2 and block.Maparr[self.stage - 1][p][q][0] == 1 and self.body[0]- 5 < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p][q][2] + 16) :
                            self.x = block.Maparr[self.stage - 1][p][q][3] + 16 + 15
                            self.canmove = False

                if block.Maparr[self.stage - 1][p][q][0] == 1:
                    if (self.body[0] < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p][q][2] + 16):
                        #print("col",jump)
                        self.step = True
                        if self.move == 1:
                            self.x += 5
                        elif self.move == 2:
                            self.x -= 5
                        if ( self.y >= block.Maparr[self.stage - 1][p][q][2] + 16  and self.jump == False):
                            self.y = block.Maparr[self.stage - 1][p][q][2] + 27
                        elif ( self.y <= block.Maparr[self.stage - 1][p][q][2] -16  and self.jump):
                            self.y = block.Maparr[self.stage - 1][p][q][2] - 27
                            self.jump = False
                            self.step = False
                            if(self.stage == 4 and p == 1 and q == 8):
                                fake.Fake4[0][0] = 1
                            elif self.stage == 4 and p == 2 and q == 10:
                                fake.Fake4[1][0] = 1

                elif block.Maparr[self.stage - 1][p][q - 1][0] != 1:
                    if (self.body[0] + 18 < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2]- 19 > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] - 1 < block.Maparr[self.stage - 1][p][q][2] + 16):
                        self.step = False



guy_data_file.close()