
from guy import*

from pico2d import*
import game_framework

import block
import fake
import morejumping
import stage2
name = "stage1"



#open_canvas()

#Bulletimage = None
def update():
    pass
def pause():
    pass
def resume():
    pass
def draw():
    pass
def exit():
    pass
def enter():
    global guy
    global font
    global Boss
    global blank
    global savezone
    global bullet
    global dialogue
    global line
    global showboundary
    global map1
    global Bossframe
    global running
    global candia


    Boss = load_image('Boss(87X98).png')
    blank = load_image('blank.png')
    line = load_image('Line.png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy('guy_playing')
    dialogue = Dialog()
    bullet = []


    guy.height = 0
    candia = 0
    showboundary = 0
    Bossframe  = 0
    map1 = load_image('1.png')


    font = load_font('HYTBRB.TTF')
    main()




class Dialog():
    def __init__(self):
        self.diaimage = load_image('Dialog.png')
        self.dialog = 0

    def show(self):
        if self.dialog != 0:
            self.diaimage.draw(400, 150)
            if self.dialog == 1:
                font.draw(200, 180, 'Hello, I am Programmer K.')
            elif self.dialog == 2:
                font.draw(200, 180, 'There are too Much Error and Bug.')
            elif self.dialog == 3:
                font.draw(200, 180, 'Please Help me.')
            elif self.dialog == 4:
                font.draw(200, 180, 'You can Shot press button Z.')
                font.draw(200, 150, 'And can Jump press button X.')
            elif self.dialog == 5:
                font.draw(200, 180, 'If you want to Save,')
                font.draw(200, 150, 'press UP in Save Zone.')
            elif self.dialog == 6:
                font.draw(200, 180, 'You can Restart press button R.')
            elif self.dialog == 7:
                font.draw(200, 180, 'Gook LUCK, GUY.')
            elif self.dialog == 8:
                self.dialog = 0


class Bullet():
    Bulletimage = None
    def __init__(self):
        self.x = guy.x
        self.y = guy.y + 1
        self.length = 0
        self.direction = guy.state
        if Bullet.Bulletimage == None:
            Bullet.Bulletimage = load_image('Bullet(4x4).png')
    def update(self):
        if self.direction == 0:
            self.length -= 20
            self.x -= 20
            if self.length < -500:
                delete()
        elif self.direction == 1:
            self.length += 20
            self.x += 20
            if self.length > 500:
                delete()
        for p in range(26):
            for q in range(19):
                if self.x >= block.Maparr[guy.stage - 1][p][q][1] and self.x <= block.Maparr[guy.stage - 1][p][q][3] + 32 and self.y <= block.Maparr[guy.stage - 1][p][q][2] + 16 and self.y >= block.Maparr[guy.stage - 1][p][q][4] + 16 and block.Maparr[guy.stage - 1][p][q][0] == 1:
                    bullet.remove(self)
        self.Bulletimage.draw(self.x, self.y)


def handle_events():
    global running
    global ground
    global top
    global bullet
    global showboundary
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                    close_canvas()
                    running = False
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    guy.move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    guy.move = 2
                    guy.state = 0
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet()]
                elif event.key == SDLK_x:
                    guy.step = False
                    guy.jump = True
                    guy.ablejump += 1
                    if guy.ablejump > 2:
                        guy.jump = False
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and guy.move == 1:
                guy.move = 0
            elif event.key == SDLK_LEFT and guy.move == 2:
                guy.move = 0
            elif event.key == SDLK_x:
                guy.jump = False

def delete():
    for i in bullet:
        if i.length > 500 or i.length < -500:
            bullet.remove(i)

def main():
    global guy
    global font
    global Boss
    global blank
    global savezone
    global bullet
    global dialogue
    global line
    global showboundary
    global map1
    global Bossframe
    global running
    global candia


    while(running):
        clear_canvas()

        if guy.step == False and guy.jump == False:
            guy.y = guy.y - 10
        elif guy.step == True:
            guy.ablejump =0

        if guy.stage == 1:
            map1.draw(400, 302)
            Boss.clip_draw(87 * Bossframe, 0, 87, 98, 450, 176 + 63)
            if guy.x > 800:
                game_framework.change_state(stage2)
            if guy.x >= 420 and guy.x <= 480:
                candia = 1
            else:
                candia = 0


        if(guy.move == False and guy.jump == False and guy.step == True):
            guy.frame = (guy.frame + 1) % 2
        elif(guy.move == 1):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove and guy.stage != 8:
                guy.x += 5
            if guy.stage == 8:
                for p in range(100):
                    fake.Fake8[p][2] -= 16




        elif(guy.move == 2):
            if guy.jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canmove:
                guy.x -= 5
            if(guy.stage == 1 and guy.x < 5):
                guy.x += 5

        for p in range(0, 26):
            for q in range(0, 18):
                if block.Maparr[guy.stage - 1][p][q][0] == 6:
                    savezone.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                if (guy.jump == False and guy.step == False) :
                    if guy.ablejump == 0:
                        guy.ablejump = 1
                    guy.height = 0

        if guy.jump :
            if guy.height < 80:
                guy.y += 10
                guy.height += 10
                guy.frame = 6
            elif guy.height >= 80:
                guy.frame = 7
                guy.jump = False
                guy.height = 0
        elif guy.jump == False and guy.step == False :
                guy.frame = (guy.frame) % 2 + 7

        if showboundary == 1 :
            for p in range(0, 26):
                for q in range(0, 19):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
            for p in range(0, 26):
                for q in range(0, 19):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                        draw_rectangle(block.Maparr[guy.stage - 1][p][q][1] + 16,block.Maparr[guy.stage - 1][p][q][4] + 16, block.Maparr[guy.stage - 1][p][q][3] + 16,block.Maparr[guy.stage - 1][p][q][2] + 16)


        font.draw(10,520,'%2d' % guy.body[0])
        font.draw(10,500,'%2d' % guy.body[2])
        font.draw(10,470,'%2d' % guy.y)
        guy.update()
        draw_rectangle(guy.body[0], guy.body[3], guy.body[2], guy.body[1])
        guy.draw()
        if bullet != None:
            for i in bullet:
                i.update()
        line.draw(400, 15)
        line.draw(400, 585)
        dialogue.show()
        update_canvas()
        handle_events()
        delay(0.04)

    running = False


if __name__ == '__main__':
    main()

