from pico2d import*


def define():
    global guy
    global font
    global Boss
    global blank
    global savezone
    global bullet
    global dialogue
    global line
    global Move
    global showboundary
    global jump
    global map1
    global Bossframe
    global running
    global candia
    global stage
    global Ablejump
    global height


    Boss = load_image('Boss(87X98).png')
    blank = load_image('blank.png')
    line = load_image('Line.png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy()
    dialogue = Dialog()
    bullet = []
    guy.x = 10
    guy.y = 176 + 25

    Move = 0
    jump = False
    Ablejump = 0
    height = 0
    candia = 0
    showboundary = 0
    Bossframe  = 0
    map1 = load_image('1.png')


    stage = int(1)
    font = load_font('HYTBRB.TTF')