from pico2d import*
import game_framework

import block
import fake
import morejumping
import stage6

name = "stage2"

#open_canvas()

#Bulletimage = None
def update():
    pass
def pause():
    pass
def resume():
    pass
def draw():
    pass
def exit():
    pass
def enter():
    global guy
    global bar
    global font
    global Boss
    global blank
    global Thorn
    global tile
    global Itemimage
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global Move
    global showboundary
    global jump
    global map1
    global map2
    global map3
    global map4
    global map5
    global map6
    global map7
    global map8
    global map9
    global map2_1
    global map6_1
    global Bossframe
    global running
    global candia
    global stage
    global Ablejump
    global height

    Boss = load_image('Boss(87X98).png')
    blank = load_image('blank.png')
    line = load_image('Line.png')
    Thorn = load_image('Thorn(32x32).png')
    tile = load_image('Tile(32x32).png')
    Itemimage = load_image('Morejumping(10x10).png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy()
    dialogue = Dialog()
    bar = Bar()
    enemy = Enemy()
    bullet = []
    guy.x = 10
    guy.y = 176 + 25

    guy.state = 1
    Move = 0
    jump = False
    Ablejump = 0
    height = 0
    candia = 0
    showboundary = 0
    Bossframe  = 0
    map6_1 = load_image('6-1.png')


    stage = int(11)
    font = load_font('HYTBRB.TTF')
    main()


class Guy:
    global Ablejump
    global checkbar

    def __init__(self):
        self.Guyimage = load_image('Guy(25X23).png')
        self.frame = 0
        self.state = 0
        self.canMove = True
        self.x, self.y = 0, 176+25
        self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
        self.body = [self.x - 30, self.y + 11, self.x + 10, self.y - 20]
        self.step = False
    def draw(self):
        self.Guyimage.clip_draw(25 * self.frame, self.state * 23, 25, 23, self.x, self.y)
    def update(self):
        global saveY , jump
        if self.state == 0:
            self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
            self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        elif self.state == 1:
            self.head = [self.x - 5, self.y + 22, self.x + 5, self.y + 11]
            self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        for p in range(0, 26):
            for q in range(0, 19):
                if p <= 24 and block.Maparr[stage - 1][p+1][q][0] == 1:
                    if (Move == 1 and guy.body[0] < block.Maparr[stage - 1][p+1][q][3] + 16 and guy.body[2]+5 > block.Maparr[stage - 1][p+1][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p+1][q][4] + 16 and guy.body[3] < block.Maparr[stage - 1][p+1][q][2] + 16):
                        #print("collision")
                        if self.canMove == True:
                            guy.x -= 5
                        elif self.canMove == False:
                            guy.x = block.Maparr[stage - 1][p+1][q][1] + 16 - 15
                        self.canMove = False
                    else:
                        self.canMove = True
                elif block.Maparr[stage - 1][p-1][q][0] == 1 and p >= 0:
                    if (Move == 2 and guy.body[0]- 10 < block.Maparr[stage - 1][p-1][q][3] + 16 and guy.body[2] > block.Maparr[stage - 1][p-1][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p-1][q][4] + 16 and guy.body[3] < block.Maparr[stage - 1][p-1][q][2] + 16):
                        #print("collision")
                        if self.canMove == True:
                            guy.x += 5
                        elif self.canMove == False:
                            guy.x = block.Maparr[stage - 1][p-1][q][3] + 16 + 15
                        self.canMove = False

                    else:
                        self.canMove = True
                        if (Move == 2 and block.Maparr[stage - 1][p][q][0] == 1 and guy.body[0]- 5 < block.Maparr[stage - 1][p][q][3] + 16 and guy.body[2] > block.Maparr[stage - 1][p][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p][q][4] + 16 and guy.body[3] < block.Maparr[stage - 1][p][q][2] + 16) :
                            guy.x = block.Maparr[stage - 1][p][q][3] + 16 + 15
                            self.canMove = False

                if block.Maparr[stage - 1][p][q][0] == 1:
                    if (guy.body[0] < block.Maparr[stage - 1][p][q][3] + 16 and guy.body[2] > block.Maparr[stage - 1][p][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p][q][4] + 16 and guy.body[3] < block.Maparr[stage - 1][p][q][2] + 16):
                        #print("col",jump)
                        self.step = True
                        if Move == 1:
                            guy.x += 5
                        elif Move == 2:
                            guy.x -= 5
                        if ( guy.y >= block.Maparr[stage - 1][p][q][2] + 16  and jump == False):
                            guy.y = block.Maparr[stage - 1][p][q][2] + 27
                        elif ( guy.y <= block.Maparr[stage - 1][p][q][2] -16  and jump):
                            guy.y = block.Maparr[stage - 1][p][q][2] - 27
                            jump = False
                            self.step = False
                            if(stage == 4 and p == 1 and q == 8):
                                fake.Fake4[0][0] = 1
                            elif stage == 4 and p == 2 and q == 10:
                                fake.Fake4[1][0] = 1

                elif block.Maparr[stage - 1][p][q - 1][0] != 1:
                    if (guy.body[0] + 18 < block.Maparr[stage - 1][p][q][3] + 16 and guy.body[2]- 19 > block.Maparr[stage - 1][p][q][1] + 16  and guy.body[1] >  block.Maparr[stage - 1][p][q][4] + 16 and guy.body[3] - 1 < block.Maparr[stage - 1][p][q][2] + 16):
                        self.step = False

        if (stage == 4 or stage == 5 or stage == 6) and guy.x > bar.bar_x - 64 and guy.x < bar.bar_x + 64 and guy.y >= bar.bar_y + 10 and guy.y <= bar.bar_y + 20:
            self.step = True
            if jump == False:
                guy.y = bar.bar_y + 12
            if bar.checkbar == 0:
                bar.checkbar = 1

    def get_bb(self):
        return self.head[0], self.head[1], self.head[2], self.head[3], self.body[0], self.body[1], self.body[2], self.body[3]

def collide(a, b, stage, x, y):
    head_left, head_top, head_right, head_bottom, body_left, body_top, body_right, body_bottom = a.get_bb()
    map_left, map_top, map_right, map_bottom = b.get_bb(stage - 1, x, y - 2)
    global collision
    collision = [0 for i in range(4)]
    if (head_left <= map_right or body_left <= map_right) : collision[0] = 1
    if (head_right >= map_left or body_right >= map_left) : collision[1] = 1
    if head_top >= map_bottom :  collision[2] = 1
    if body_bottom <= map_top :  collision[3] = 1


class Dialog():
    def __init__(self):
        self.diaimage = load_image('Dialog.png')
        self.dialog = 0

    def show(self):
        if self.dialog != 0:
            self.diaimage.draw(400, 150)
            if self.dialog == 1:
                font.draw(200, 180, 'Hello, I am Programmer K.')
            elif self.dialog == 2:
                font.draw(200, 180, 'There are too Much Error and Bug.')
            elif self.dialog == 3:
                font.draw(200, 180, 'Please Help me.')
            elif self.dialog == 4:
                font.draw(200, 180, 'You can Shot press button Z.')
                font.draw(200, 150, 'And can Jump press button X.')
            elif self.dialog == 5:
                font.draw(200, 180, 'If you want to Save,')
                font.draw(200, 150, 'press UP in Save Zone.')
            elif self.dialog == 6:
                font.draw(200, 180, 'You can Restart press button R.')
            elif self.dialog == 7:
                font.draw(200, 180, 'Gook LUCK, GUY.')
            elif self.dialog == 8:
                self.dialog = 0


class Bullet():
    Bulletimage = None
    def __init__(self):
        self.x = guy.x
        self.y = guy.y + 1
        self.length = 0
        self.direction = guy.state
        if Bullet.Bulletimage == None:
            Bullet.Bulletimage = load_image('Bullet(4x4).png')
    def update(self):
        if self.direction == 0:
            self.length -= 20
            self.x -= 20
            if self.length < -500:
                delete()
        elif self.direction == 1:
            self.length += 20
            self.x += 20
            if self.length > 500:
                delete()
        for p in range(26):
            for q in range(19):
                if self.x >= block.Maparr[stage - 1][p][q][1] and self.x <= block.Maparr[stage - 1][p][q][3] + 32 and self.y <= block.Maparr[stage - 1][p][q][2] + 16 and self.y >= block.Maparr[stage - 1][p][q][4] + 16 and block.Maparr[stage - 1][p][q][0] == 1:
                    bullet.remove(self)
        self.Bulletimage.draw(self.x, self.y)


class Bar():
    Barimage = None
    def __init__(self):
        self.checkbar = 0
        self.bar_x = 704
        self.bar_y = 100
        if Bar.Barimage == None:
            Bar.Barimage = load_image('Bar(128x10).png')

    def update(self):
        if stage == 4 or stage == 5 or stage == 6:
            if bar.checkbar == 1:
                bar.bar_y += 2
                if guy.step == True and guy.x < bar.bar_x + 64 and guy.x > bar.bar_x - 64 and guy.y >= bar.bar_y + 10 and guy.y < bar.bar_y + 30:
                    guy.y += 2
            if stage == 6 and bar.bar_y > block.Maparr[5][0][9][2]:
                bar.checkbar = 2
            bar.Barimage.draw(bar.bar_x, bar.bar_y)

class Enemy():
    global stage
    Enemyimage = None

    def __init__(self):
        self.stage = 1
        self.ex = 19 * 32 + 16
        self.ey = 2 * 32 + 16
        self.box = [self.ex - 15, self.ey + 15, self.ex + 15, self.ey - 15]
        self.frame = 0
        self.state = 0
        self.count = 0
        self.crash = 0
        if Enemy.Enemyimage == None:
            Enemy.Enemyimage = load_image('Enemy(30x30).png')

    def update(self):
        if(self.stage != stage):
            self.stage = stage
            self.count = 0
            self.state = 0
            self.frame = 0
            self.crash = 0
        if self.crash == 0:
            if self.count == 0:
                if self.stage == 2:
                    self.ex = 19 * 32 + 16
                    self.ey = 2 * 32 + 16
                elif self.stage == 3:
                    self.ex = 21 * 32 + 16
                    self.ey = 16 * 32 + 16
                elif self.stage == 4:
                    self.ex = 8 * 32 + 16
                    self.ey = 9 * 32 + 16
                elif self.stage == 11:
                    self.ex = 8 * 32 + 16
                    self.ey = 7 * 32 + 16

                self.count = 1
            if self.state == 0:
                self.ex += 5
                self.frame = (self.frame + 1) % 2
                if self.ex > 23 * 32 + 16 and self.stage == 2:
                    self.state = 1
                elif self.ex > 21 * 32 + 16 and self.stage == 3:
                    self.state = 1
                elif self.ex > 12 * 32 + 16 and self.stage == 4:
                    self.state = 1
                elif self.ex > 10 * 32 + 16 and self.stage == 11:
                    self.state = 1
            elif self.state == 1:
                self.ex -= 5
                self.frame = (self.frame + 1) % 2
                if self.ex < 13 * 32 + 16 and self.stage == 2:
                    self.state = 0
                elif self.ex < 16 * 32 + 16 and self.stage == 3:
                    self.state = 0
                elif self.ex < 6 * 32 + 16 and self.stage == 4:
                    self.state = 0
                elif self.ex < 5 * 32 + 16 and self.stage == 11:
                    self.state = 0

            self.box = [self.ex - 15, self.ey + 15, self.ex + 15, self.ey - 15]
        for i in bullet:
            if i.x >= self.box[0] and i.x <= self.box[2] and i.y <= self.box[1] and i.y >= self.box[3] and self.crash == 0:
                bullet.remove(i)
                self.crash = 1
        if self.crash == 1:
            if self.count == 1:
                self.frame = 1
                self.count = 2
            self.frame += 1
            if self.frame > 4:
                self.state = 2

        if self.state < 2 and (self.stage == 2 or self.stage == 3 or self.stage == 4 or self.stage == 11):
            self.Enemyimage.clip_draw(30 * self.frame, 30 * self.state, 30, 30, self.ex, self.ey)


def morejump():
    global Ablejump
    if stage == 3:
        for p in range(5):
            for q in range(4):
                if morejumping.item[p][0] == 0:
                    Itemimage.draw(morejumping.item[p][1], morejumping.item[p][2])
                elif morejumping.item[p][0] == 1:
                    morejumping.item[p][3] += 1
                    if morejumping.item[p][3] == 100:
                        morejumping.item[p][3] = 0
                        morejumping.item[p][0] = 0
                if morejumping.item[p][0] == 0 and morejumping.item[p][1] >= guy.body[0] and  morejumping.item[p][1] <= guy.body[2] and  morejumping.item[p][2] >= guy.body[3] and  morejumping.item[p][2] <= guy.body[1] :
                    morejumping.item[p][0] = 1
                    Ablejump = 1
    elif stage == 4:
        if morejumping.item[5][0] == 0:
            Itemimage.draw(morejumping.item[5][1], morejumping.item[5][2])
        elif morejumping.item[5][0] == 1:
            morejumping.item[5][3] += 1
            if morejumping.item[5][3] == 100:
                morejumping.item[5][3] = 0
                morejumping.item[5][0] = 0
        if morejumping.item[5][0] == 0 and morejumping.item[5][1] >= guy.body[0] and  morejumping.item[5][1] <= guy.body[2] and  morejumping.item[5][2] >= guy.body[3] and  morejumping.item[5][2] <= guy.body[1] :
            morejumping.item[5][0] = 1
            Ablejump = 1





def handle_events():
    global running
    global Move
    global jump
    global Ablejump
    global ground
    global height
    global top
    global bullet
    global showboundary
    global stage
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                    close_canvas()
                    running = False
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    Move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    Move = 2
                    guy.state = 0
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet()]
                elif event.key == SDLK_x:
                    guy.step = False
                    saveY = guy.y
                    jump = True
                    Ablejump = Ablejump + 1
                    if Ablejump > 2:
                        jump = False
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

            if stage == 7 or stage == 8:
                if event.key == SDLK_n:
                    guy.x = 100
                    guy.y = 500
                    if stage == 7 :
                        stage = 8
                    elif stage == 8:
                        stage = 9
                
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and Move == 1:
                Move = 0
            elif event.key == SDLK_LEFT and Move == 2:
                Move = 0
            elif event.key == SDLK_x:
                jump = False

def delete():
    for i in bullet:
        if i.length > 500 or i.length < -500:
            bullet.remove(i)

def deletebullet():
    for i in bullet:
        bullet.remove(i)

def drawThorn():
    for p in range(26):
        for r in range(19):
            if block.Maparr[stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[stage - 1][p][r][3],  block.Maparr[stage - 1][p][r][2])
                

def main():
    global guy
    global bar
    global font
    global Boss
    global blank
    global Thorn
    global tile
    global Itemimage
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global Move
    global showboundary
    global Ablejump
    global jump
    global map6_1
    global Bossframe
    global running
    global candia
    global stage
    global height

    fake.redefine()
    global saveY
    while(running):
        clear_canvas()

        if guy.step == False and jump == False:
            guy.y = guy.y - 10
        elif guy.step == True:
            Ablejump =0


        if stage == 11:
            map6_1.draw(400,302)
            if guy.x > 800:
                game_framework.change_state(stage6)

        drawThorn()




        if(Move == False and jump == False and guy.step == True):
            guy.frame = (guy.frame + 1) % 2
        elif(Move == 1):
            if jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canMove and stage != 8:
                guy.x += 5
            if stage == 8:
                for p in range(100):
                    fake.Fake8[p][2] -= 16




        elif(Move == 2):
            if jump == False and guy.step == True:
                guy.frame = (guy.frame + 1) % 4 + 2
            if guy.canMove:
                guy.x -= 5
            if(stage == 1 and guy.x < 5):
                guy.x += 5

        for p in range(0, 26):
            for q in range(0, 18):
                if block.Maparr[stage - 1][p][q][0] == 6:
                    savezone.draw(block.Maparr[stage - 1][p][q][3], block.Maparr[stage - 1][p][q][2])
                if (jump == False and guy.step == False) :
                    if Ablejump == 0:
                        Ablejump = 1
                    height = 0

        if jump :
            #print("jump")
            if height < 80:
                guy.y += 10
                height += 10
                guy.frame = 6
            elif height >= 80:
                guy.frame = 7
                jump = False
                height = 0
        elif jump == False and guy.step == False :
                guy.frame = (guy.frame) % 2 + 7

        if showboundary == 1 :
            for p in range(0, 26):
                for q in range(0, 19):
                    if(block.Maparr[stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[stage - 1][p][q][3], block.Maparr[stage - 1][p][q][2])
            for p in range(0, 26):
                for q in range(0, 19):
                    if(block.Maparr[stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[stage - 1][p][q][3], block.Maparr[stage - 1][p][q][2])
                        draw_rectangle(block.Maparr[stage - 1][p][q][1] + 16,block.Maparr[stage - 1][p][q][4] + 16, block.Maparr[stage - 1][p][q][3] + 16,block.Maparr[stage - 1][p][q][2] + 16)


        bar.update()
        enemy.update()
        morejump()
        font.draw(10,520,'%2d' % guy.body[0])
        font.draw(10,500,'%2d' % guy.body[2])
        font.draw(10,470,'%2d' % guy.y)
        guy.update()
        draw_rectangle(guy.body[0], guy.body[3], guy.body[2], guy.body[1])
        guy.draw()
        if bullet != None:
            for i in bullet:
                i.update()
        line.draw(400, 15)
        line.draw(400, 585)
        dialogue.show()
        update_canvas()
        handle_events()
        delay(0.04)

    running = False


if __name__ == '__main__':
    main()

