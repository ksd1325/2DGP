

import json

def read_guy():
    guy_file = open("guy_data.txt", "r")
    data = json.load(guy_file)
    guy_file.close()
    return data

def write(stage, x, y, frame, ablejump, canmove, state, move, jump, height, step, savestage, savestate, savex, savey, death, savedeath):
    my_dict={
	"guy_playing" : {"stage" : stage, "frame" : frame, "ablejump" : ablejump, "canmove" : str(canmove), "state" : state, "x" : x, "y" : y, "move" : move, "jump" : str(jump), "step" : str(step), "height" : height, "death" : death},
	"guy_saved" : {"stage" : savestage, "frame" : 0, "ablejump" : 0, "canmove" : "True", "state" : savestate, "x" : savex, "y" : savey, "move" : 0, "jump" : "False", "step" : "True", "height" : 0, "death" : savedeath}
    }


    with open("guy_data.txt", "w") as data_file:
        json.dump(my_dict, data_file)

    data_file.close()

def reset_guy_playing( savestage, savestate, savex, savey, savedeath):
    my_dict={
	"guy_saved" : {"stage" : savestage, "frame" : 0, "ablejump" : 0, "canmove" : "True", "state" : savestate, "x" : savex, "y" : savey, "move" : 0, "jump" : "False", "step" : "True", "height" : 0, "death" : savedeath},
	"guy_playing": {"x": 10, "canmove": "True", "move": 0 , "stage": 1, "height": 0, "state": 1, "y": 201, "frame": 0, "step": "True", "ablejump": 0, "jump": "False", "death" : 0}
    }

    with open("guy_data.txt", "w") as data_file:
        json.dump(my_dict, data_file)

    data_file.close()

def save(savestage, savestate, savex, savey, savedeath):
    reset_guy_playing(savestage, savestate, savex, savey, savedeath)

def load(death = 0):
    guy_file = open("guy_data.txt", "r")
    data = json.load(guy_file)
    guy_file.close()
    savestage = data['guy_saved']['stage']
    savestate = data['guy_saved']['state']
    savex = data['guy_saved']['x']
    savey = data['guy_saved']['y']
    savedeath = data['guy_saved']['death']

    my_dict={
	"guy_saved" : {"stage" : savestage, "frame" : 0, "ablejump" : 0, "canmove" : "True", "state" : savestate, "x" : savex, "y" : savey, "move" : 0, "jump" : "False", "step" : "True", "height" : 0, "death" : savedeath},
	"guy_playing" : {"stage" : savestage, "frame" : 0, "ablejump" : 0, "canmove" : "True", "state" : savestate, "x" : savex, "y" : savey, "move" : 0, "jump" : "False", "step" : "True", "height" : 0, "death" : savedeath}
    }
    with open("guy_data.txt", "w") as data_file:
        json.dump(my_dict, data_file)

    data_file.close()
    if death == 0:
        return savestage
    else:
        return savedeath



def read_enemy():
    enemy_file = open("enemy_data.txt", "r")
    data = json.load(enemy_file)
    enemy_file.close()
    return data

def read_bar():
    bar_file = open("bar_data.txt", "r")
    data = json.load(bar_file)
    bar_file.close()
    return data

def read_fake():
    fake_file = open("fake_data.txt", "r")
    data = json.load(fake_file)
    fake_file.close()
    return data

def read_midboss():
    midboss_file = open("midboss_data.txt", "r")
    data = json.load(midboss_file)
    midboss_file.close()
    return data

def reset_data():
    write(1, 10, 201, 0, 0, True, 1, 0, False, 0, True, 1, 1, 10, 201, 0, 0)