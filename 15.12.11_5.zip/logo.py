import game_framework
from pico2d import *
import title


name = "logo"
image = None
logo_time = 0.0


def enter():
    global image
    image = load_image('kpu_credit.png')

    main()


def exit():
    global image
    del(image)
    close_canvas()


def update(frame_time):
    global logo_time

    while logo_time <= 1.0:
        delay(0.01)
        logo_time += 0.01
    logo_time = 0
    game_framework.push_state(title)


def draw(frame_time):
    global image
    clear_canvas()
    image.draw(400, 300)
    update_canvas()

def main():
    draw(1)
    update(1)


def handle_events(frame_time):
    events = get_events()
    pass


def pause(): pass


def resume(): pass




