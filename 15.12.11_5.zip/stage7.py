
from class_file import*
from pico2d import*
from read_or_write import*
import game_framework

import block
#import fake
import morejumping
import stage1
import stage2
import stage2_1
import stage3
import stage4
import stage5
import stage6
import stage6_1
import stage7
import stage8
import stage9
import time


import logo
name = "stage7"

#open_canvas()

#Bulletimage = None
def update(frame_time):
    pass
def pause():
    pass
def resume():
    pass
def draw(frame_time):
    pass
def exit():
    global guy
    global dialogue
    global bullet
    global enemy
    global bar
    global map7
    global savezone
    global blank
    global Thorn
    global fake
    global midboss
    del(midboss)
    del(fake)
    del(dialogue)
    del(bullet)
    del(enemy)
    del(bar)
    del(Thorn)
    del(map7)
    del(savezone)
    del(blank)
    del(guy)
    pass
def enter():
    global guy
    global bar
    global font
    global blank
    global Thorn
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map7
    global bossframe
    global running
    global candia
    global midboss
    global caninput

    blank = load_image('blank.png')
    line = load_image('Line.png')
    Thorn = load_image('Thorn(32x32).png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy('guy_playing')
    reset_guy_playing(guy.savestage, guy.savestate, guy.savex, guy.savey, guy.savedeath)
    dialogue = Dialog()
    bar = Bar(guy.stage)
    enemy = Enemy(guy.stage)
    bullet = []

    caninput = 0
    candia = 0
    showboundary = 0
    bossframe  = 0
    map7 = load_image('7.png')
    fake_data = read_fake()
    global fake
    fake = [Fake(guy, fake_data, i + 1) for i in range(fake_data[str(guy.stage)]['count'])]

    global cansave
    cansave = False

    midboss = Midboss()

    font = load_font('HYTBRB.TTF')
    main()




def handle_events(frame_time):
    global running
    global ground
    global top
    global dialogue
    global bullet
    global showboundary
    global cansave

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
            game_framework.quit()
        if event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            guy.savedeath = guy.deathcount
            save(guy.savestage, guy.savestate, guy.savex, guy.savey, guy.savedeath)
            game_framework.change_state(logo)
        elif event.type == SDL_KEYDOWN and guy.state != guy.DEAD:
            if dialogue.dialog == 0 and candia == 0:
                if event.key == SDLK_RIGHT:
                    guy.move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    guy.move = 2
                    guy.state = 0
                elif event.key == SDLK_UP and cansave:
                    guy.savestage = guy.stage
                    guy.savestate = guy.state
                    guy.savex = guy.x
                    guy.savey = guy.y
                    guy.savedeath = guy.deathcount
                    save(guy.savestage, guy.savestate, guy.savex, guy.savey, guy.savedeath)
                elif event.key == SDLK_s:
                    guy.savestage = guy.stage
                    guy.savestate = guy.state
                    guy.savex = guy.x
                    guy.savey = guy.y
                    guy.savedeath = guy.deathcount
                    save(guy.savestage, guy.savestate, guy.savex, guy.savey, guy.savedeath)
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet(guy.x, guy.y, guy.state, guy.stage)]
                elif event.key == SDLK_x:
                    guy.step = False
                    saveY = guy.y
                    guy.jump = True
                    guy.ablejump = guy.ablejump + 1
                    if guy.ablejump > 2:
                        guy.jump = False
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 14

            if guy.stage == 7 or guy.stage == 8:
                if event.key == SDLK_n:
                    guy.x = 100
                    guy.y = 500
                    if guy.stage == 7 :
                        guy.stage = 8
                    elif guy.stage == 8:
                        guy.stage = 9
                
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and guy.move == 1:
                guy.move = 0
            elif event.key == SDLK_LEFT and guy.move == 2:
                guy.move = 0
            elif event.key == SDLK_x:
                guy.jump = False
        if event.type == SDL_KEYDOWN and event.key == SDLK_r:
            if guy.state != guy.DEAD:
                guy.deathcount += 1
            guy.savedeath = guy.deathcount
            write(guy.savestage, guy.savex, guy.savey, 0, 0, str(True), 0, 0, str(False), 0, str(False), guy.savestage, guy.savestate, guy.savex, guy.savey, guy.deathcount, guy.savedeath)
            load_data = load()
            if load_data == 1:
                game_framework.change_state(stage1)
            elif load_data == 2:
                game_framework.change_state(stage2)
            elif load_data == 3:
                game_framework.change_state(stage3)
            elif load_data == 4:
                game_framework.change_state(stage4)
            elif load_data == 5:
                game_framework.change_state(stage5)
            elif load_data == 6:
                game_framework.change_state(stage6)
            elif load_data == 7:
                game_framework.change_state(stage7)
            elif load_data == 8:
                game_framework.change_state(stage8)
            elif load_data == 9:
                game_framework.change_state(stage9)
            elif load_data == 10:
                game_framework.change_state(stage2_1)
            elif load_data == 11:
                game_framework.change_state(stage6_1)




def drawThorn():
    global cansave
    global guy
    for p in range(26):
        for r in range(19):
            if block.Maparr[guy.stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[guy.stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[guy.stage - 1][p][r][3],  block.Maparr[guy.stage - 1][p][r][2])
            if block.Maparr[guy.stage - 1][p][r][0] == 6:
                savezone.draw(block.Maparr[guy.stage - 1][p][r][3], block.Maparr[guy.stage - 1][p][r][2])
                if savezonecrash(guy, p, r):
                    cansave = True
                else:
                    cansave = False

def savezonecrash(guy, p, r):
    if guy.body[0] > block.Maparr[guy.stage - 1][p][r][3] + 16: return False
    if guy.body[2] < block.Maparr[guy.stage - 1][p][r][1] + 16: return False
    if guy.body[1] < block.Maparr[guy.stage - 1][p][r][4] + 16: return False
    if guy.body[3] > block.Maparr[guy.stage - 1][p][r][2] + 16: return False

    return True
def main():
    global guy
    global bar
    global font
    global blank
    global Thorn
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map7
    global running
    global candia
    global fake
    global midboss
    global caninput

    current_time = time.clock()
    frame_time = time.clock() - current_time
    print(current_time)
    while(running):
        clear_canvas()
        current_time += frame_time


        if guy.stage == 7:
            map7.draw(400, 302)
            if guy.x < 0:
                write(6, 790, guy.y, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step, guy.savestage, guy.savestate, guy.savex, guy.savey, guy.deathcount, guy.savedeath)
                game_framework.change_state(stage6)
            elif midboss.bossin == 2 and dialogue.dialog == 0:
                candia = 1
                dialogue.dialog = 9
            elif midboss.bossin == 4:
                write(8, 100, 580, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, str(False), guy.savestage, guy.savestate, guy.savex, guy.savey, guy.deathcount, guy.savedeath)
                game_framework.change_state(stage8)
        if dialogue.dialog == 10:
            midboss.bossin = 3
            dialogue.dialog = 0
            caninput = 1
        elif caninput == 1 and midboss.bossframe == 8:
            delay(1)
            dialogue.dialog = 11
            caninput = 0
        if dialogue.dialog >= 14:
            dialogue.dialog = 0
            midboss.bossin = 4



        drawThorn()






        enemy.update(bullet, guy, frame_time)

        midboss.update(guy, bullet, frame_time)
        font.draw(600,520, '%2d' % midboss.hp)
        for i in fake:
            i.update(guy, fake, frame_time)
        guy.update(frame_time)
        if bullet != None:
            for i in bullet:
                i.update(bullet, frame_time)

        line.draw(400, 15)
        line.draw(400, 585)
        guy.show_deathcount()
        dialogue.show(font)
        update_canvas()
        handle_events(frame_time)
        frame_time = time.clock() - current_time

    running = False


if __name__ == '__main__':
    main()

