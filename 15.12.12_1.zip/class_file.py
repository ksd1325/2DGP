


from pico2d import*
from read_or_write import*


import block
import random
import math






class Guy:
    RIGHT, LEFT, DEAD = 0, 1 , 2
    PIXEL_PER_METER = (10.0 / 0.5)
    RUN_SPEED_KMPH = 25
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)
    FALL_SPEED_PPS = (RUN_SPEED_PPS * 2)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 9

    guy_state_table = {
        'True' : True,
        'False': False
    }
    global checkbar
    global guy_data



    def __init__(self, choice_data):

        guy_data = read_guy()
        self.guyimage = load_image('./image/Guy(25X23).png')
        self.bloodimage = load_image('./image/Blood(259x259).png')
        self.gameoverimage = load_image('./image/GameOver(754X155).png')
        self.frame = guy_data[choice_data]['frame']
        self.bloodframe = 0
        self.state = guy_data[choice_data]['state']
        self.canmove = Guy.guy_state_table[guy_data[choice_data]['canmove']]
        self.x, self.y = guy_data[choice_data]['x'], guy_data[choice_data]['y']
        self.body = [self.x - 30, self.y + 11, self.x + 10, self.y - 20]
        self.step = Guy.guy_state_table[guy_data[choice_data]['step']]
        self.stage = guy_data[choice_data]['stage']
        self.move = guy_data[choice_data]['move']
        self.jump = Guy.guy_state_table[guy_data[choice_data]['jump']]
        self.ablejump = guy_data[choice_data]['ablejump']
        self.height = guy_data[choice_data]['height']
        self.rangex = int(self.x / 32)
        self.rangey = int(self.y / 32)
        self.savestage = guy_data['guy_saved']['stage']
        self.savestate = guy_data['guy_saved']['state']
        self.savex = guy_data['guy_saved']['x']
        self.savey = guy_data['guy_saved']['y']
        self.savedeath = guy_data['guy_saved']['death']
        self.deathcount = guy_data[choice_data]['death']
        self.total_frames = 0

        self.font = load_font('./font/HYTBRB.TTF', 15)
        self.deathcheck = 0


    def _guydraw(self):
        self.guyimage.clip_draw(25 * self.frame, self.state * 23, 25, 23, self.x, self.y)

    def _blooddraw(self):
        self.bloodimage.clip_draw(259 * int(self.bloodframe / 4), (self.state - 2), 259, 259, self.x, self.y)

    def _overdraw(self):
        self.gameoverimage.draw(400,300)


    def update(self, frame_time):
        if self.deathcheck == 0 and self.state == self.DEAD:
            self.deathcount += 1
            self.deathcheck = 1
        if self.stage != 8:
            distance = Guy.RUN_SPEED_PPS * (frame_time)
        else:
            distance = 0
        falldistance = Guy.FALL_SPEED_PPS * (frame_time)
        self.total_frames += Guy.FRAMES_PER_ACTION * Guy.ACTION_PER_TIME * frame_time

        if self.move == 1:
            self.x += distance
        elif self.move == 2:
            self.x -= distance

        if self.step == False and self.jump == False and self.state != self.DEAD:
            self.y = self.y - falldistance
        elif self.step == True and self.state != self.DEAD:
            self.ablejump =0

        if(self.move == False and self.jump == False and self.step == True):
            self.frame = int(self.total_frames + 1) % 2
        elif(self.move == 1 and self.state != self.DEAD):
            if self.jump == False and self.step == True:
                self.frame = int(self.total_frames + 1) % 4 + 2




        elif(self.move == 2 and self.state != self.DEAD):
            if self.jump == False and self.step == True:
                self.frame = int(self.total_frames + 1) % 4 + 2


        if (self.jump == False and self.step == False and self.state != self.DEAD) :
            if self.ablejump == 0:
                self.ablejump = 1
            self.height = 0

        if self.jump  and self.state != self.DEAD:
            if self.height < 80:
                self.y += falldistance
                self.height += falldistance
                self.frame = 6
            elif self.height >= 80:
                self.frame = 7
                self.jump = False
                self.height = 0
        elif self.jump == False and self.step == False :
                self.frame = int(self.total_frames) % 2 + 7
        self.rangex = int(self.x / 32)
        self.rangey = int(self.y / 32)
        self.body = [self.x - 10, self.y + 11, self.x + 10, self.y - 10]
        if self.state < self.DEAD:
            for p in range(self.rangex - 1, self.rangex + 2):
                for q in range(self.rangey - 1, self.rangey + 2):
                    if p <= 24 and q <= 18 and p >= -1 and q >= 0 and block.Maparr[self.stage - 1][p+1][q][0] == 1:
                        if (self.move == 1 and self.body[0] < block.Maparr[self.stage - 1][p+1][q][3] + 16 and self.body[2]+5 > block.Maparr[self.stage - 1][p+1][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p+1][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p+1][q][2] + 16):
                            if self.canmove == True:
                                self.x -= distance
                            self.canmove = False
                        else:
                            self.canmove = True
                    elif p <= 26 and q <= 18 and p >= 1 and q >= 0 and block.Maparr[self.stage - 1][p-1][q][0] == 1:
                        if (self.move == 2 and self.body[0]- 5 < block.Maparr[self.stage - 1][p-1][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p-1][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p-1][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p-1][q][2] + 16):
                            if self.canmove == True:
                                self.x += distance
                            self.canmove = False

                        elif p <= 25 and q <= 18 and p >= 0 and q >= 0:
                            self.canmove = True
                            if (self.move == 1 and block.Maparr[self.stage - 1][p][q][0] == 1 and self.body[0]- 5 < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p][q][2] + 16) :
                                self.canmove = False

                    if p <= 25 and q <= 18 and p >= 0 and q >= 0 and  block.Maparr[self.stage - 1][p][q][0] == 1:
                        if (self.body[0] < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2] > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] < block.Maparr[self.stage - 1][p][q][2] + 16):
                            self.step = True
                            if ( self.y >= block.Maparr[self.stage - 1][p][q][2] + 16  and self.jump == False):
                                self.y = block.Maparr[self.stage - 1][p][q][2] + 27
                            elif ( self.y <= block.Maparr[self.stage - 1][p][q + 1][4]  and self.jump):
                                self.y = block.Maparr[self.stage - 1][p][q + 1][4] - 27
                                self.jump = False
                                self.step = False

                    elif p <= 25 and q <= 19 and p >= 0 and q >= 1 and block.Maparr[self.stage - 1][p][q - 1][0] != 1:
                        if (self.body[0] + 18 < block.Maparr[self.stage - 1][p][q][3] + 16 and self.body[2]- 19 > block.Maparr[self.stage - 1][p][q][1] + 16  and self.body[1] >  block.Maparr[self.stage - 1][p][q][4] + 16 and self.body[3] - 1 < block.Maparr[self.stage - 1][p][q][2] + 16):
                            self.step = False

                    for k in range(17):
                        if p <= 25 and q <= 18 and p >= 0 and q >= 0:
                            if self.state == self.DEAD:
                                break
                            if ( block.Maparr[self.stage - 1][p][q][0] == 2 and self.body[3] >= block.Maparr[self.stage - 1][p][q][4] + 16 + 2 * k and self.body[3] <= block.Maparr[self.stage - 1][p][q][4] + 16 + 2 * (k + 1) and ((self.body[0] <= block.Maparr[self.stage - 1][p][q][1] + 16 + k and self.body[2] >= block.Maparr[self.stage - 1][p][q][1] + 16 + k) or (self.body[0] <= block.Maparr[self.stage - 1][p][q][3] + 16 - k and self.body[2] >= block.Maparr[self.stage - 1][p][q][3] + 16 - k))):
                                self.state = self.DEAD
                            elif ( block.Maparr[self.stage - 1][p][q][0] == 3 and (self.body[2] <= block.Maparr[self.stage - 1][p][q][3] + 16 - 2 * k and self.body[2] >= block.Maparr[self.stage - 1][p][q][3] + 16 - 2 * (k + 1) and ((self.body[1] >= block.Maparr[self.stage - 1][p][q][4] + 32 - k and self.body[3] <= block.Maparr[self.stage - 1][p][q][4] + 32 - k ) or (self.body[1] >= block.Maparr[self.stage - 1][p][q][4] + 32 + k and self.body[3] <= block.Maparr[self.stage - 1][p][q][4] + 32 + k )) )):
                                self.state = self.DEAD
                            elif ( block.Maparr[self.stage - 1][p][q][0] == 4 and (self.body[0] >= block.Maparr[self.stage - 1][p][q][1] + 16 + 2 * k and self.body[0] <= block.Maparr[self.stage - 1][p][q][1] + 16 + 2 * (k + 1) and ((self.body[1] >= block.Maparr[self.stage - 1][p][q][4] + 16 + k and self.body[3] <= block.Maparr[self.stage - 1][p][q][4] + 16 + k ) or (self.body[1] >= block.Maparr[self.stage - 1][p][q][2] + 16 - k and self.body[3] <= block.Maparr[self.stage - 1][p][q][2] + 16 - k )) )):
                                self.state = self.DEAD
                            elif ( block.Maparr[self.stage - 1][p][q][0] == 5 and self.body[1] <= block.Maparr[self.stage - 1][p][q][2] + 16 - 2 * k and self.body[1] >= block.Maparr[self.stage - 1][p][q][2] + 16 - 2 * (k + 1) and ((self.body[0] <= block.Maparr[self.stage - 1][p][q][1] + 32 - k and self.body[2] >= block.Maparr[self.stage - 1][p][q][1] + 32 - k) or (self.body[0] <= block.Maparr[self.stage - 1][p][q][1] + 32 + k and self.body[2] >= block.Maparr[self.stage - 1][p][q][1] + 32 + k))):
                                self.state = self.DEAD

        if self.state < self.DEAD:
            self._guydraw()
        else:
            self.bloodframe += 1
            self.move = 0

            if self.bloodframe > 16:
                self.bloodframe = 16
            self._blooddraw()
            if self.bloodframe == 16:
                self._overdraw()

    def show_deathcount(self):
        self.font.draw(700, 10, 'death :   %3d' % self.deathcount, (255, 255, 255))



class Dialog:
    def __init__(self):
        self.diaimage = load_image('./image/Dialog.png')
        self.dialog = 0

    def show(self,font):
        if self.dialog != 0:
            self.diaimage.draw(400, 150)
            if self.dialog == 1:
                font.draw(200, 180, '안녕하십니까, 저는 프로그래머 K입니다.')
            elif self.dialog == 2:
                font.draw(200, 180, '에러하고 버그가 너무 많아요.')
            elif self.dialog == 3:
                font.draw(200, 180, '처리하는 걸 도와주시죠.')
            elif self.dialog == 4:
                font.draw(200, 180, 'Z버튼을 누르면 총을 쏠 수 있습니다.')
                font.draw(200, 150, 'X버튼을 누르면 점프를 할 수 있습니다.')
            elif self.dialog == 5:
                font.draw(200, 180, '진행사항을 저장하길 원하신다면,')
                font.draw(200, 150, '세이브존 위에서 UP키를 누르세요.')
            elif self.dialog == 6:
                font.draw(200, 180, 'R버튼을 누르면,')
                font.draw(200, 150, '저장상황을 재시작할 수 있습니다.')
            elif self.dialog == 7:
                font.draw(200, 180, '행운을 빕니다, GUY.')
            elif self.dialog == 8:
                self.dialog = 0
            elif self.dialog == 9:
                font.draw(200, 180, '좋아.')
            elif self.dialog == 11:
                font.draw(200, 180, '에러 때문에 포맷이 안되고 있었는데,')
                font.draw(200, 150, '잘 해결했군, GUY.')
            elif self.dialog == 12:
                font.draw(200, 180, '그럼 이제 포맷을 시작해볼까?')
            elif self.dialog == 13:
                font.draw(200, 180, '바탕화면에 있는 휴지통에나 들어가도록.')
            elif self.dialog == 15:
                font.draw(200, 180, '끈질기게 여기까지 쫓아오다니.')
            elif self.dialog == 16:
                font.draw(200, 180, '파이참 여는데 5분은 걸리는,')
                font.draw(200, 150, '노트북은 이제 질렸어.')
            elif self.dialog == 17:
                font.draw(200, 180, '새로운 노트북을 사기 위해')
            elif self.dialog == 18:
                font.draw(200, 180, '너를 삭제시키고 포맷한 후에,')
                font.draw(200, 150, '노트북을 중고나라에 팔아버리겠다.')
            elif self.dialog == 19:
                self.dialog = 0
            elif self.dialog == 20:
                font.draw(200, 180, '이럴수가..')
            elif self.dialog == 21:
                font.draw(200, 180, '꼭, 새 노트북을..')
                font.draw(200, 150, '사고 싶었는데....')
            elif self.dialog == 22:
                pass


class Bullet:
    Bulletimage = None
    PIXEL_PER_METER = (10.0 / 0.5)
    RUN_SPEED_KMPH = 100
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self, x, y, state, stage):
        self.x = x
        self.y = y + 1
        self.length = 0
        self.direction = state
        self.stage = stage
        self.crash = 0
        self.distance = 0
        if Bullet.Bulletimage == None:
            Bullet.Bulletimage = load_image('./image/Bullet(4x4).png')
    def update(self, bullet, frame_time):
        distance = Bullet.RUN_SPEED_PPS * (frame_time)
        if self.direction == 0:
            self.length -= distance
            self.x -= distance
            if self.length < -500:
                self.crash = 1
        elif self.direction == 1:
            self.length += distance
            self.x += distance
            if self.length > 500:
                self.crash = 1

        self._checkcrash()
        self._drawbullet()
        if self.crash == 1:
            self._deletebullet(bullet)

    def _deletebullet(self, bullet):
        bullet.remove(self)

    def _drawbullet(self):
        self.Bulletimage.draw(self.x, self.y)

    def _checkcrash(self):
        for p in range(26):
            for q in range(19):
                if self.x >= block.Maparr[self.stage - 1][p][q][1] and self.x <= block.Maparr[self.stage - 1][p][q][3] + 32 and self.y <= block.Maparr[self.stage - 1][p][q][2] + 16 and self.y >= block.Maparr[self.stage - 1][p][q][4] + 16 and block.Maparr[self.stage - 1][p][q][0] == 1:
                    self.crash = 1



class Enemy:
    enemyimage = None
    RIGHT, LEFT, DEAD = 0, 1, 2
    PIXEL_PER_METER = (10.0 / 0.5)
    RUN_SPEED_KMPH = 25
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 2

    def __init__(self, stage):
        enemy_data = read_enemy()
        self.stage = stage
        self.enemyin = enemy_data[str(stage)]['enemyin']
        self.x = enemy_data[str(stage)]['x']
        self.y = enemy_data[str(stage)]['y']
        self.box = [self.x - 15, self.y + 15, self.x + 15, self.y - 15]
        self.frame = enemy_data[str(stage)]['frame']
        self.state = self.RIGHT
        self.count = enemy_data[str(stage)]['count']
        self.crash = enemy_data[str(stage)]['crash']
        self.left_limit = enemy_data[str(stage)]['left_limit']
        self.right_limit = enemy_data[str(stage)]['right_limit']
        self.total_frames = 0
        if Enemy.enemyimage == None:
            Enemy.enemyimage = load_image('./image/Enemy(30x30).png')

    def update(self, bullet, guy, frame_time):
        distance = Enemy.RUN_SPEED_PPS * (frame_time)
        self.total_frames += Enemy.FRAMES_PER_ACTION * Enemy.ACTION_PER_TIME * frame_time
        if self.crash == 0 and self.enemyin == 1:
            if self.state == self.RIGHT:
                self.x += distance
                self.frame = int(self.total_frames + 1) % 2
                if self.x > self.right_limit:
                    self.state = self.LEFT
            elif self.state == self.LEFT:
                self.x -= distance
                self.frame = int(self.total_frames + 1) % 2
                if self.x < self.left_limit:
                    self.state = self.RIGHT

            self.box = [self.x - 15, self.y + 15, self.x + 15, self.y - 15]
            for i in bullet:
                if i.x >= self.box[0] and i.x <= self.box[2] and i.y <= self.box[1] and i.y >= self.box[3]:
                    i.crash = 1
                    self.crash = 1
        if self.crash == 1 and self.state != self.DEAD:
            if self.count == 0:
                self.frame = 1
                self.count = 1
            self.frame += 1
            if self.frame > 4:
                self.state = self.DEAD

        if self.state != self.DEAD:
            self.enemyimage.clip_draw(30 * self.frame, 30 * self.state, 30, 30, self.x, self.y)

        if self._crashcheck(guy):
            guy.state = guy.DEAD

    def _crashcheck(self, guy):
        if self.state == self.DEAD: return False
        if guy.body[0] > self.box[2]: return False
        if guy.body[2] < self.box[0]: return False
        if guy.body[1] < self.box[3]: return False
        if guy.body[3] > self.box[1]: return False

        return True




class Bar:
    barimage = None
    PIXEL_PER_METER = (10.0 / 0.5)
    RUN_SPEED_KMPH = 20
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self, stage):
        bar_data = read_bar()
        self.stage = stage
        self.bar_in = bar_data[str(self.stage)]['in']
        self.bar_x = bar_data[str(self.stage)]['x']
        self.bar_y = bar_data[str(self.stage)]['y']
        self.checkbar = bar_data[str(self.stage)]['checkbar']
        self.boundary = [self.bar_x - 64, self.bar_y + 5, self.bar_x + 64, self.bar_y - 5]
        if Bar.barimage == None:
            Bar.barimage = load_image('./image/Bar(128x10).png')

    def update(self, guy, frame_time):
        distance = Bar.RUN_SPEED_PPS * (frame_time)
        if self.bar_in:
            self.boundary = [self.bar_x - 64, self.bar_y + 5, self.bar_x + 64, self.bar_y - 5]
            if(self.checkbar != 2 and guy.jump == False and (guy.body[2] > self.boundary[0] and guy.body[0] < self.boundary[2]) and (guy.body[3] < self.boundary[1] + 10 and guy.body[3] > self.boundary[3])):
                self.checkbar = 1
                self.bar_y += distance
                guy.y = self.bar_y + 10
                guy.step = True
            elif self.checkbar == 1:
                self.bar_y += distance
            if guy.stage == 6 and self.bar_y > block.Maparr[5][0][9][2]:
                self.checkbar = 2
            self.barimage.draw(self.bar_x, self.bar_y)


class Fake:
    thornimage = None
    blockimage = None
    UP, DOWN, UP_DOWN = 0, 1, 2
    MOVETYPE, APEENDTHORNTYPE, APEENDTILETYPE = 0, 1, 2
    fake_state_table = {
        'UP' : UP,
        'DOWN': DOWN,
        'UD' : UP_DOWN
    }


    PIXEL_PER_METER = (10.0 / 0.5)
    RUN_SPEED_KMPH = 6
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self, guy, fake_data, count):
        self.stage = guy.stage
        if self.stage != 8:
            self.shape = fake_data[str(guy.stage)][str(count)]['shape']
            self.x = fake_data[str(guy.stage)][str(count)]['x'] * 32 + 16 - 1
            self.y = fake_data[str(guy.stage)][str(count)]['y'] * 32 + 16 - 2
            self.fakein = 0
            self.triggerx, self.triggery =  fake_data[str(guy.stage)][str(count)]['trigger']['x'] * 32 + 16 - 1, fake_data[str(guy.stage)][str(count)]['trigger']['y'] * 32 + 16 - 2
            self.checkx, self.checky =  Fake.fake_state_table[fake_data[str(guy.stage)][str(count)]['trigger']['checkx']], Fake.fake_state_table[fake_data[str(guy.stage)][str(count)]['trigger']['checky']]
            self.direction = fake_data[str(guy.stage)][str(count)]['direction']
            self.speed = fake_data[str(guy.stage)][str(count)]['speed']
            self.min, self.max = fake_data[str(guy.stage)][str(count)]['limit']['min'] * 32 + 16, fake_data[str(guy.stage)][str(count)]['limit']['max'] * 32 + 16
            self.type = fake_data[str(guy.stage)][str(count)]['type']
            self.box = [self.x - 16, self.y + 16, self.x + 16, self.y - 16]


        elif self.stage == 8:
            self.shape = random.randint(0, 3)
            if self.shape == 0 or self.shape == 3:
                self.x = 300 * (count + 3)
            elif self.shape == 1:
                self.x = 310 * (count + 3)
            elif self.shape == 2:
                self.x = 290 * (count + 3)

            if self.shape == 3:
                self.y = 8 * 32 + 16 - 2
            else:
                self.y = 7 * 32 + 16 - 2
            self.fakein = 1
            self.triggerx, self.triggery = 0, 0
            self.checkx, self.checky =  self.UP, self.UP
            self.direction = 0
            self.speed = -5
            self.min, self.max = -20, 9999
            self.type = self.MOVETYPE


        if Fake.blockimage == None:
            Fake.blockimage = load_image('./image/Tile(32X32).png')
            Fake.thornimage = load_image('./image/Thorn(32X32).png')

    def update(self, guy, fake, frame_time):
        distance = Fake.RUN_SPEED_PPS * (frame_time) * self.speed
        if self.fakein != 1:
            if self.checkx == self.UP:
                if self.checky == self.UP:
                    if guy.x > self.triggerx and guy.y > self.triggery:
                        self.fakein = 1
                elif self.checky == self.DOWN:
                    if guy.x > self.triggerx and guy.y < self.triggery:
                        self.fakein = 1
                elif self.checky == self.UP_DOWN:
                    if guy.x > self.triggerx and guy.y < self.triggery + 32 and guy.y > self.triggery - 32:
                        self.fakein = 1
            elif self.checkx == self.DOWN:
                if self.checky == self.UP:
                    if guy.x < self.triggerx and guy.y > self.triggery:
                        self.fakein = 1
                elif self.checky == self.DOWN:
                    if guy.x < self.triggerx and guy.y < self.triggery:
                        self.fakein = 1
                elif self.checky == self.UP_DOWN:
                    if guy.x < self.triggerx and guy.y < self.triggery + 32 and guy.y > self.triggery - 32:
                        self.fakein = 1
            elif self.checkx == self.UP_DOWN:
                if self.checky == self.UP:
                    if guy.x > self.triggerx - 32 and guy.x < self.triggerx + 32 and guy.y > self.triggery:
                        self.fakein = 1
                elif self.checky == self.DOWN:
                    if guy.x > self.triggerx - 32 and guy.x < self.triggerx + 32 and guy.y < self.triggery:
                        self.fakein = 1
                elif self.checky == self.UP_DOWN:
                    if guy.x > self.triggerx - 32 and guy.x < self.triggerx + 32 and guy.y < self.triggery + 32 and guy.y > self.triggery - 32:
                        self.fakein = 1

        if self.fakein == 1:
            if self.direction == 0:
                if guy.stage == 8 and guy.move == 1:
                    self.speed = -10
                elif guy.stage == 8:
                    self.speed = -3
                self.x += self.speed
                if self.x > self.max or self.x < self.min:
                    self.x -= distance
                    self.speed = 0
                    if self.max > 26 * 32 + 16 or self.min < 16:
                        fake.remove(self)
                if self.max == 14 * 32 + 16 and self.min == 12 * 32 + 16:
                    if guy.x >= self.x:
                        self.speed = 5
                    elif guy.x < self.x:
                        self.speed = -5
                    if self.x > self.max or self.x < self.min:
                        self.speed = 0
                        if self.x > self.max:
                            self.x = self.max
                        else:
                            self.x = self.min


            elif self.direction == 1:
                self.y += distance
                if self.y > self.max or self.y < self.min:
                    self.y -= distance
                    self.speed = 0
                    if self.max > 26 * 32 + 16 or self.min < 16:
                        fake.remove(self)

        self.box = [self.x - 16, self.y + 16, self.x + 16, self.y - 16]
        self._crashcheck(guy)

        if self.type == self.MOVETYPE:
            self.thornimage.clip_draw(32 * self.shape, 0, 32, 32, self.x, self.y)
        if self.type == self.APEENDTHORNTYPE and self.fakein == 1:
            self.thornimage.clip_draw(32 * self.shape, 0, 32, 32, self.x, self.y)
        if self.type == self.APEENDTILETYPE and self.fakein == 1:
            self.blockimage.clip_draw(32 * self.shape, 0, 32, 32, self.x, self.y)



    def _crashcheck(self, guy):
        for k in range(17):
            if guy.state == guy.DEAD:
                break
            if self.type != self.APEENDTILETYPE:
                if ( self.shape == 0 and guy.body[3] >=  self.y + 2 * k and guy.body[3] <= self.y + 2 * (k + 1) and ((guy.body[0] <=  self.x - 16 + k and guy.body[2] >=  self.x - 16 + k) or (guy.body[0] <=  self.x + 16 - k and guy.body[2] >=  self.x + 16 - k))):
                    guy.state = guy.DEAD
                elif ( self.shape == 1 and (guy.body[2] <=  self.x + 16 - 2 * k and guy.body[2] >=  self.x + 16 - 2 * (k + 1) and ((guy.body[1] >= self.y + 16 - k and guy.body[3] <= self.y + 16 - k ) or (guy.body[1] >= self.y - 16 + k and guy.body[3] <= self.y - 16 + k )) )):
                    guy.state = guy.DEAD
                elif ( self.shape == 2 and (guy.body[0] >= self.x - 16 + 2 * k and guy.body[0] <=  self.x - 16 + 2 * (k + 1) and ((guy.body[1] >= self.y - 16 + k and guy.body[3] <= self.y - 16 + k ) or (guy.body[1] >= self.y + 16 - k and guy.body[3] <= self.y + 16 - k )) )):
                    guy.state = guy.DEAD
                elif ( self.shape == 3 and guy.body[1] <= self.y + 16 - 2 * k and guy.body[1] >= self.y + 16 - 2 * (k + 1) and ((guy.body[0] <=  self.x + 16 - k and guy.body[2] >=  self.x + 16 - k) or (guy.body[0] <=  self.x - 16 + k and guy.body[2] >=  self.x - 16 + k))):
                    guy.state = guy.DEAD

class Midboss:
    DONT_MOVE, LEFT, RIGHT, UP, DOWN = 0, 1, 2, 3, 4
    midbossimage = None
    bossimage = None

    PIXEL_PER_METER = (10.0 / 0.5)
    RUN_SPEED_KMPH = 4
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)
    RUN_FALLSPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self):
        midboss_data = read_midboss()

        self.bossin = midboss_data['in']
        self.directionx, self.directiony = midboss_data['move']['x'], midboss_data['move']['y']
        self.x, self.y =  midboss_data['position']['x'], midboss_data['position']['y']
        self.speedx, self.speedy = midboss_data['speed']['x'], midboss_data['speed']['y']
        self.hp = midboss_data['hp']
        self.pattern = midboss_data['pattern']
        self.press = 1
        self.height = 0
        self.count = 0
        self.box = [self.x - 183, self.y + 85, self.x + 183, self.y - 85]
        self.bossx, self.bossy = 400, 700
        self.bossframe = 7

        if Midboss.midbossimage == None:
            Midboss.midbossimage = load_image('./image/MidBoss(366X170).png')
            Midboss.bossimage = load_image('./image/Boss.png')

    def update(self, guy, bullet, frame_time):
        distance = Midboss.RUN_SPEED_PPS * (frame_time) * self.speedx
        falldistance = Midboss.RUN_FALLSPEED_PPS * (frame_time) * self.speedy
        if guy.x > 150 and self.bossin == 0:
            self.bossin = 1
        if self.bossin == 1:
            self.box = [self.x - 183, self.y + 85, self.x + 183, self.y - 85]
            if self.pattern == 0:
                self.x += distance
                if self.x < 400:
                    self.pattern = 1
                    self.directionx = self.RIGHT
                    self.directiony = self.DOWN
                    self.speedx, self.speedy = 10, 0
            elif self.pattern == 1 and self.count >= 0:
                if self.directionx == self.LEFT:
                    self.x += distance
                    if self.box[0] < 2 * 32:
                        self.directionx = self.RIGHT
                        self.speedx = 10
                elif self.directionx == self.RIGHT:
                    self.x += distance
                    if self.box[2] > 23 * 32:
                        self.directionx = self.LEFT
                        self.speedx = -10

                if self.directiony == self.UP:
                    self.speedy -= self.press
                    self.y += falldistance
                    self.height += falldistance
                    if self.speedy <= 0:
                        self.speedy = 0
                        self.directiony = self.DOWN
                elif self.directiony == self.DOWN:
                    self.speedy += self.press
                    self.y -= falldistance
                    if self.box[3] < 2* 32:
                        self.y = 130
                        self.speedy = 30 - (self.count)
                        self.directiony = self.UP
                        self.height = 0
                        self.count += 1
                        guy.jump = True
                        guy.step = False
                        if self.count > 3:
                            self._patternsuffle(guy)

            elif self.count < 0:
                self.count += 1
            elif self.pattern == 2:
                self.speedy -= self.press
                self.y += falldistance
                if self.box[3] < 2* 32:
                    self._patternsuffle(guy)

            self._hitcheck(bullet)
            if self._crashcheck(guy):
                guy.state = guy.DEAD

            self.midbossimage.draw(self.x, self.y)

        elif self.bossin == 3:
            self.speedy = 80
            self.bossy -= falldistance
            if self.bossy - 50 < 2 * 32:
                self.bossy = 45 + 2 *32
                self.speedy = 0
                self.bossframe = 8
            self.bossimage.clip_draw(87 * self.bossframe, 0, 87, 98, self.bossx, self.bossy)

    def _patternsuffle(self, guy):
        self.pattern = random.randint(1,2)
        if self.pattern == 1:
            self.y = 500
            self.directionx = self.RIGHT
            self.directiony = self.DOWN
            self.speedy = 0
            self.speedx = 10
            self.count = -100
            self.x = guy.x
        elif self.pattern == 2:
            self.y = 2300
            self.directionx = self.DONT_MOVE
            self.directiony = self.DOWN
            self.speedy = 0
            self.speedx = 0
            self.x = guy.x
            self.count = -50

    def _crashcheck(self, guy):
        if self.bossin == 2: return False
        if guy.body[0] > self.box[2]: return False
        if guy.body[2] < self.box[0]: return False
        if guy.body[1] < self.box[3]: return False
        if guy.body[3] > self.box[1]: return False

        return True

    def _hitcheck(self, bullet):
        for i in bullet:
            if i.x >= self.box[0] and i.x <= self.box[2] and i.y <= self.box[1] and i.y >= self.box[3]:
                #bullet.remove(i)
                i.crash = 1
                self.hp -= 40
            if self.hp <= 0:
                self.bossin = 2



class Boss:
    bossimage = None
    ballimage = None
    keyimage = None
    beamimage = None
    LEFT, RIGHT = 0, 1

    PIXEL_PER_METER = (10.0 / 0.5)
    RUN_SPEED_KMPH = 4
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self):
        self.x = 500
        self.y = 107
        self.direction = self.LEFT
        self.hp = 100
        self.frame = 0
        self.bossin = 0
        self.pattern = 0
        self.count = 0
        self.check = 0
        self.ball =[[-500, -500] for i in range(30)]
        self.ballrange = [-500 for i in range(30)]
        self.beamrange = [-500 for i in range(3)]
        self.speed = 0
        self.keyin = 0
        self.box = [self.x - 30, self.y + 45, self.x + 30, self.y - 45]
        if Boss.bossimage == None:
            Boss.bossimage = load_image('./image/Boss.png')
            Boss.ballimage = load_image('./image/ball.png')
            Boss.keyimage = load_image('./image/press.png')
            Boss.beamimage = load_image('./image/beam.png')

    def update(self, guy, bullet, frame_time):
        distance = Midboss.RUN_SPEED_PPS * (frame_time) * self.speed

        if self.bossin == 1:
            self.pattern = random.randint(1, 5)
            if self.x - guy.x >= 0:
                self.direction = self.LEFT
                if self.pattern == 3 or self.pattern == 4:
                    self.direction == self.RIGHT
            else:
                self.direction = self.RIGHT
                if self.pattern == 3 or self.pattern == 4:
                    self.direction == self.LEFT
            self.frame = 1
            self.y = 107
            self.box = [self.x - 30, self.y + 45, self.x + 30, self.y - 45]
            if self.direction == self.RIGHT:
                self.frame = 13 - self.frame
            self.bossin = 2
            self.count = 0

        elif self.bossin == 2:
            if self.pattern == 1:
                if self.count == 20:
                    self.x = random.randint(100, 500)
                    self.box = [self.x - 30, self.y + 45, self.x + 30, self.y - 45]
                elif self.count == 100:
                    self.y = random.randint(200, 400)
                    self.box = [self.x - 30, self.y + 45, self.x + 30, self.y - 45]
                elif self.count == 110:
                    self.frame = 2
                    if self.direction == self.RIGHT:
                        self.frame = 13 - self.frame
                elif self.count == 112:
                    self.frame = 3
                    if self.direction == self.RIGHT:
                        self.frame = 13 - self.frame
                elif self.count >= 114:
                    self.check = 0
                    for i in range(0, 10):
                        self.ball[i][0], self.ball[i][1] = self.x + math.sin(3.141592 / 360 * (i * 72)) * (15 * (int(self.count / 2) - 57)), self.y + math.cos(3.141592 / 360 * (i * 72)) * (15 * (int(self.count / 2) - 57))
                        self.ballrange[i] = [self.ball[i][0] - 15, self.ball[i][1] + 15, self.ball[i][0] + 15, self.ball[i][1] - 15]
                        if self._ballcrash(guy, self.ballrange[i]):
                            guy.state = guy.DEAD
                        self.ballimage.clip_draw(0, 0, 30, 30, self.ball[i][0], self.ball[i][1])
                    if self.count > 140:
                        for i in range(10, 20):
                            self.ball[i][0], self.ball[i][1] = self.x + math.sin((3.141592 / 360 * (i * 72)) + (3.141592 / 2)) * (15 * (int(self.count / 2) - 70)), self.y + math.cos((3.141592 / 360 * (i * 72)) + (3.141592 / 2)) * (15 * (int(self.count / 2) - 70))
                            self.ballrange[i] = [self.ball[i][0] - 15, self.ball[i][1] + 15, self.ball[i][0] + 15, self.ball[i][1] - 15]
                            if self._ballcrash(guy, self.ballrange[i]):
                                guy.state = guy.DEAD
                            self.ballimage.clip_draw(0, 0, 30, 30, self.ball[i][0], self.ball[i][1])
                    if self.count > 166:
                        for i in range(20, 30):
                            self.ball[i][0], self.ball[i][1] = self.x + math.sin(3.141592 / 360 * (i * 72)) * (15 * (int(self.count / 2) - 83)), self.y + math.cos(3.141592 / 360 * (i * 72)) * (15 * (int(self.count / 2) - 83))
                            self.ballrange[i] = [self.ball[i][0] - 15, self.ball[i][1] + 15, self.ball[i][0] + 15, self.ball[i][1] - 15]
                            if self._ballcrash(guy, self.ballrange[i]):
                                guy.state = guy.DEAD
                            self.ballimage.clip_draw(0, 0, 30, 30, self.ball[i][0], self.ball[i][1])
                    for i in range(30):
                        if self.ball[i][0] > 0 and self.ball[i][0] < 800 and self.ball[i][1] > 0 and self.ball[i][1] < 600:
                            self.check = 1
                    if self.check == 0:
                        self.count = -1
                        self.bossin = 1
                self.count += 1
            elif self.pattern == 2:
                if self.count == 90:
                    self.x = random.randint(100, 500)
                    self.y = random.randint(300, 500)
                    self.box = [self.x - 30, self.y + 45, self.x + 30, self.y - 45]
                    self.frame = 4
                    if self.direction == self.RIGHT:
                        self.frame = 13 - self.frame
                elif self.count == 92:
                    self.frame = 5
                    if self.direction == self.RIGHT:
                        self.frame = 13 - self.frame
                elif self.count == 96:
                    self.frame = 6
                    if self.direction == self.RIGHT:
                        self.frame = 13 - self.frame
                elif self.count >= 114:
                    self.check = 0
                    for i in range(0, 10):
                        self.ball[i][0], self.ball[i][1] = self.x + math.sin(3.141592 / 360 * ((i + 1) * int(self.count/2))) * (15 * (int(self.count / 2) - 57)), self.y + math.cos(3.141592 / 360 * ((i + 1) * int(self.count/2))) * (15 * (int(self.count / 2) - 57))
                        self.ballrange[i] = [self.ball[i][0] - 15, self.ball[i][1] + 15, self.ball[i][0] + 15, self.ball[i][1] - 15]
                        if self._ballcrash(guy, self.ballrange[i]):
                            guy.state = guy.DEAD
                        self.ballimage.clip_draw(0, 0, 30, 30, self.ball[i][0], self.ball[i][1])
                    if self.count > 140:
                        for i in range(10, 20):
                            self.ball[i][0], self.ball[i][1] = self.x + math.sin((3.141592 / 360 * ((i - 9) * int(self.count/2)))) * (15 * (int(self.count / 2) - 70)), self.y + math.cos((3.141592 / 360 * ((i - 9) * int(self.count/2)))) * (15 * (int(self.count / 2) - 70))
                            self.ballrange[i] = [self.ball[i][0] - 15, self.ball[i][1] + 15, self.ball[i][0] + 15, self.ball[i][1] - 15]
                            if self._ballcrash(guy, self.ballrange[i]):
                                guy.state = guy.DEAD
                            self.ballimage.clip_draw(0, 0, 30, 30, self.ball[i][0], self.ball[i][1])
                    if self.count > 166:
                        for i in range(20, 30):
                            self.ball[i][0], self.ball[i][1] = self.x + math.sin(3.141592 / 360 * ((i - 19) * int(self.count/2))) * (15 * (int(self.count / 2) - 83)), self.y + math.cos(3.141592 / 360 * ((i - 19) * int(self.count/2))) * (15 * (int(self.count / 2) - 83))
                            self.ballrange[i] = [self.ball[i][0] - 15, self.ball[i][1] + 15, self.ball[i][0] + 15, self.ball[i][1] - 15]
                            if self._ballcrash(guy, self.ballrange[i]):
                                guy.state = guy.DEAD
                            self.ballimage.clip_draw(0, 0, 30, 30, self.ball[i][0], self.ball[i][1])
                    for i in range(30):
                        if self.ball[i][0] > 0 and self.ball[i][0] < 800 and self.ball[i][1] > 0 and self.ball[i][1] < 600:
                            self.check = 1
                        if self.check == 1:
                            break
                    if self.check == 0:
                        self.count = -1
                        self.bossin = 1
                        for i in range(30):
                            self.ball[i][0], self.ball[i][1] = -500, -500
                            self.ballrange[i] = [self.ball[i][0] - 15, self.ball[i][1] + 15, self.ball[i][0] + 15, self.ball[i][1] - 15]
                self.count += 1
            elif self.pattern == 3:
                if self.count == 0:
                    self.x = 100
                    self.speed = 100
                self.x += distance
                self.box = [self.x - 30, self.y + 45, self.x + 30, self.y - 45]
                if self.x >= 650 and self.keyin == 0:
                    self.speed = 0
                    self.keyimage.clip_draw(0, 0, 100, 100, 400, 300)
                    if self.count > 50 and self.keyin == 0:
                        guy.state = guy.DEAD
                        self.bossin = 3
                elif self.keyin == 1:
                    self.count = -1
                    self.bossin = 1
                    self.keyin = 0

                self.count += 1

            elif self.pattern == 4:
                if self.count == 0:
                    self.x = 700
                    self.speed = -100
                self.x += distance
                self.box = [self.x - 30, self.y + 45, self.x + 30, self.y - 45]
                if self.x <= 150 and self.keyin == 0:
                    self.speed = 0
                    self.keyimage.clip_draw(100, 0, 100, 100, 400, 300)
                    if self.count > 50 and self.keyin == 0:
                        guy.state = guy.DEAD
                        self.bossin = 3
                elif self.keyin == 1:
                    self.count = -1
                    self.bossin = 1
                    self.keyin = 0

                self.count += 1

            elif self.pattern == 5:
                if self.count == 0:
                    self.x = guy.x
                    self.y = 3000
                    self.speed = -100
                    self.frame = 7
                    if self.direction == self.RIGHT:
                        self.frame = 13 - self.frame
                self.y += distance
                self.box = [self.x - 30, self.y + 45, self.x + 30, self.y - 45]
                if self.y - 50 < 2 * 32:
                    self.y = 45 + 2 * 32
                    self.speed = 0
                    self.frame = 8
                    if self.direction == self.RIGHT:
                        self.frame = 13 - self.frame

                if self.count > 60 and self.count < 74:
                    for i in range(3):
                        self.beamimage.clip_draw(0, 0, 70, 100 + ((int(self.count / 2) - 30) * 200), self.x + ((i - 1) * 70), 600)
                elif self.count == 76:
                    for i in range(3):
                        self.beamimage.clip_draw(70, 0, 70, 100 + (6 * 200), self.x + ((i - 1) * 70), 600)
                elif self.count == 78:
                    for i in range(3):
                        self.beamimage.clip_draw(140, 0, 70, 100 + (6 * 200), self.x + ((i - 1) * 70), 600)
                elif self.count >= 80 and self.count < 100:
                    for i in range(3):
                        self.beamimage.clip_draw(210, 0, 70, 100 + (6 * 200), self.x + ((i - 1) * 70), 600)
                        self.beamrange[i] = [self.x + ((i - 1) * 70) - 35, 600, self.x + ((i - 1) * 70) + 35, 0]
                        if self._beamcrash(guy, self.beamrange[i]):
                            guy.state = guy.DEAD

                elif self.count == 120:
                    self.count -= 1
                    self.bossin = 1


                self.count += 1

        if guy.state == guy.DEAD:
            if self.bossin != 3:
                self.bossin = 3
                self.pattern = random.randint(1, 2)
                self.x = 500
                self.y = 107
                self.speed = 0
                self.count = 1
                self.direction == self.LEFT

                if self.pattern == 1:
                    self.frame = 9
                elif self.pattern == 2:
                    self.frame = 11
            if self.pattern == 1 and self.count % 10 == 0:
                if self.frame == 9:
                    self.frame = 10
                else:
                    self.frame = 9
            elif self.pattern == 2 and self.count % 10 == 0:
                if self.frame == 11:
                    self.frame = 12
                elif self.frame == 12:
                    self.frame = 13

            self.count += 1



        self._hitcheck(bullet)
        self.bossimage.clip_draw(87 * self.frame, 98 * self.direction, 87, 98, self.x, self.y)



    def _hitcheck(self, bullet):
        for i in bullet:
            if i.x >= self.box[0] and i.x <= self.box[2] and i.y <= self.box[1] and i.y >= self.box[3]:
                i.crash = 1
                self.hp -= 100
            if self.hp <= 0:
                self.bossin = 4

    def _ballcrash(self, guy, beamrange):
        if guy.body[0] > beamrange[2]: return False
        if guy.body[2] < beamrange[0]: return False
        if guy.body[1] < beamrange[3]: return False
        if guy.body[3] > beamrange[1]: return False

        return True

    def _beamcrash(self, guy, ballrange):
        if guy.body[0] > ballrange[2]: return False
        if guy.body[2] < ballrange[0]: return False
        if guy.body[1] < ballrange[3]: return False
        if guy.body[3] > ballrange[1]: return False

        return True


