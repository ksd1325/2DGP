

import game_framework
from pico2d import *

import logo
from read_or_write import*


name = "ending"
image = None


def enter():
    global image
    global bigfont
    global smallfont
    global running

    image = load_image('./image/ending.png')
    bigfont = load_font('./font/HYTBRB.TTF', 50)
    smallfont = load_font('./font/HYTBRB.TTF', 10)
    running = True

    main()


def exit():
    global image
    global bigfont
    global smallfont
    del(bigfont)
    del(smallfont)
    del(image)


def handle_events(frame_time):
    global running
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
            game_framework.quit()
        if event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(logo)



def draw(frame_time):
    global running
    global bigfont
    global smallfont
    global image

    while running:
        clear_canvas()
        image.draw(400, 300)

        load_data = load(1)
        bigfont.draw(70, 400, '당신은 노트북을 구하기 위해,',(255,255,255))
        bigfont.draw(170, 200, '총 %3d번 죽었습니다.' % load_data,(255,255,255))
        smallfont.draw(600, 100, '메인으로 돌아가려면 ESC키를 누르세요.',(255,255,255))
        update_canvas()
        handle_events(frame_time)


def main():
    draw(1)




def update(frame_time):
    pass


def pause():
    pass


def resume():
    pass





if __name__ == '__main__':
    main()

