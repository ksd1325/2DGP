
item = [[[0] for p in range(4)] for q in range(6)]

for p in range(6):
    for q in range(4):
        item[p][q] = 0

item[0][1] = 14 * 32 + 32 - 1
item[0][2] = 7 * 32 + 16 - 2

item[1][1] = 14 * 32 + 32 - 1
item[1][2] = 9 * 32 + 16 - 2

item[2][1] = 14 * 32 + 32 - 1
item[2][2] = 11 * 32 + 16 - 2

item[3][1] = 14 * 32 + 32 - 1
item[3][2] = 13 * 32 + 16 - 2

item[4][1] = 14 * 32 + 32 - 1
item[4][2] = 15 * 32 + 16 - 2

item[5][1] = 18 * 32 + 16 - 1
item[5][2] = 3 * 32 + 16 - 2