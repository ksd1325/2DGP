import game_framework
from pico2d import *

import stage1
import stage2
import stage2_1
import stage3
import stage4
import stage5
import stage6
import stage6_1
import stage7
import stage8
import stage9
from read_or_write import*


name = "TitleState"
image = None


def enter():
    global image
    global select
    global running
    global selectbox

    image = load_image('./image/title.png')
    selectbox = load_image('./image/selectbox.png')

    select = 1
    running = True

    main()


def exit():
    global image
    del(image)


def handle_events(frame_time):
    global running
    global select
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
            game_framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                running = False
                game_framework.quit()
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
                if select == 1:
                    reset_data()
                    game_framework.change_state(stage1)
                elif select == 2:
                    load_data = load()
                    if load_data == 1:
                        game_framework.change_state(stage1)
                    elif load_data == 2:
                        game_framework.change_state(stage2)
                    elif load_data == 3:
                        game_framework.change_state(stage3)
                    elif load_data == 4:
                        game_framework.change_state(stage4)
                    elif load_data == 5:
                        game_framework.change_state(stage5)
                    elif load_data == 6:
                        game_framework.change_state(stage6)
                    elif load_data == 7:
                        game_framework.change_state(stage7)
                    elif load_data == 8:
                        game_framework.change_state(stage8)
                    elif load_data == 9:
                        game_framework.change_state(stage9)
                    elif load_data == 10:
                        game_framework.change_state(stage2_1)
                    elif load_data == 11:
                        game_framework.change_state(stage6_1)
                elif select == 3:
                    running = False
                    game_framework.quit()

            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
                if select != 1:
                    select -= 1
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN):
                if select != 3:
                    select += 1


def draw(frame_time):
    global running
    global select
    global selectbox

    while running:
        clear_canvas()
        image.draw(400, 300)

        if select == 1:
            selectbox.draw(410, 230)
        elif select == 2:
            selectbox.draw(410, 150)
        elif select == 3:
            selectbox.draw(410, 70)
        update_canvas()
        handle_events(frame_time)



def main():
    draw(1)



def update(frame_time):
    pass


def pause():
    pass


def resume():
    pass






