global Maparr
Maparr = [[[[0 for p in range(5)] for q in range(20)] for r in range(26)] for s in range(11)]

for p in range(0,11):
    for q in range(0,26):
        for r in range(0,19):
            Maparr[p][q][r][1] = 32 * q - 16 - 1
            Maparr[p][q][r][2] = 32 * r + 16 - 2
            Maparr[p][q][r][3] = 32 * q + 16 - 1
            Maparr[p][q][r][4] = 32 * r - 16 - 2


for p in range(26):
    for r in range(6):
        Maparr[0][p][r][0] = 1

for p in range(26):
    for r in range(6):
        if (p < 10 or p > 12) and r < 2:
            Maparr[1][p][r][0] = 1
        if (p == 0 or p >= 24):
            Maparr[1][p][r][0] = 1

Maparr[1][1][5][0] = 4
Maparr[1][1][2][0] = 2
Maparr[1][9][2][0] = 2
Maparr[1][14][2][0] = 2
Maparr[1][20][2][0] = 2
Maparr[1][23][2][0] = 2

for p in range(26):
    for r in range(19):
        if r == 0:
            if p != 10 and p != 11 and p != 14 and p != 15 and p != 21 and p != 22:
                Maparr[2][p][r][0] = 1
        elif r >= 1 and r <= 3:
            if p == 0 or (p >= 7 and p <= 9) or p == 12 or p == 13 or (p >= 16 and p <= 20) or p >= 23 :
                Maparr[2][p][r][0] = 1
                if r != 1:
                    Maparr[2][3][r][0] = 1
        elif r >= 4 and r <= 5:
            if p == 0 or (p >= 16 and p <= 20) or p >= 23 :
                Maparr[2][p][r][0] = 1
                Maparr[2][3][r][0] = 1
        elif r >= 6 and r <= 10:
            if p == 0 or (p >= 3 and p <= 13) or (p >= 16 and p <= 20) or p >= 23 :
                Maparr[2][p][r][0] = 1
                if( r >= 6 and r < 8) :
                    Maparr[2][23][r][0] = 0
                    Maparr[2][24][r][0] = 0
                    Maparr[2][25][r][0] = 0
        elif r == 11:
            if p == 0 or (p >= 3 and p <= 9) or p == 13 or (p >= 16 and p <= 20) or p >= 23 :
                Maparr[2][p][r][0] = 1
        elif r == 12:
            if p == 0 or (p >= 3 and p <= 7) or p == 13 or (p >= 16 and p <= 20) or p >= 23 :
                Maparr[2][p][r][0] = 1
        elif r == 13:
            if p == 0 or (p >= 3 and p <= 6) or p == 13 or (p >= 16 and p <= 20) or p >= 23 :
                Maparr[2][p][r][0] = 1
        elif r == 14:
            if p == 0 or (p >= 3 and p <= 5) or p == 13 or (p >= 16 and p <= 20) or p >= 23 :
                Maparr[2][p][r][0] = 1
        elif r == 15:
            if p == 0 or (p >= 8 and p <= 9) or p == 13 or (p >= 16 and p <= 20) or p >= 23 :
                Maparr[2][p][r][0] = 1
        elif r == 16:
            if p == 0 or (p >= 7 and p <= 9) or p == 13 or p >= 23 :
                Maparr[2][p][r][0] = 1
        elif r == 16:
            if (p >= 0 and p <= 9) or p == 13 or p >= 23 :
                Maparr[2][p][r][0] = 1
        elif r == 17:
            if (p >= 0 and p <= 9) or p == 13 or p >= 23 :
                Maparr[2][p][r][0] = 1
        elif r >= 18:
            if (p >= 0 and p <= 9) or p >= 13 :
                Maparr[2][p][r][0] = 1


Maparr[2][10][16][0] = 4
Maparr[2][10][11][0] = 2
Maparr[2][11][11][0] = 2
Maparr[2][12][11][0] = 2
Maparr[2][8][12][0] = 2
Maparr[2][3][15][0] = 2
Maparr[2][2][11][0] = 3
Maparr[2][1][5][0] = 4
Maparr[2][1][1][0] = 2
Maparr[2][6][2][0] = 3
Maparr[2][11][5][0] = 5
Maparr[2][12][5][0] = 5
Maparr[2][17][17][0] = 5
Maparr[2][19][17][0] = 5
Maparr[2][20][17][0] = 5

for p in range(26):
    for r in range(19):
        if r < 4:
            if p == 0 or p == 1 or (p >=4 and p <= 14) or p > 23:
                Maparr[3][p][r][0] = 1
        elif r >= 4 and r < 7:
            if p == 0 or p == 1 or (p >=4 and p <= 11) or p > 23:
                Maparr[3][p][r][0] = 1
                Maparr[3][0][6][0] = 0
                Maparr[3][1][6][0] = 0
        elif r >= 7 and r <= 8:
            if (p >=6 and p <= 11) or p > 23:
                Maparr[3][p][r][0] = 1
                Maparr[3][1][8][0] = 1
                Maparr[3][19][8][0] = 1
        elif r >= 9 and r <= 14:
            if (p >= 27 -r and p <= 19) or p > 23:
                Maparr[3][p][r][0] = 1
                Maparr[3][4][10][0] = 1
                Maparr[3][2][10][0] = 1
        elif r >= 15:
            if (p >= 13 and p <= 19) or p > 23:
                Maparr[3][p][r][0] = 1

Maparr[3][19][7][0] = 5
Maparr[3][18][8][0] = 5
Maparr[3][17][9][0] = 5
Maparr[3][16][10][0] = 5
Maparr[3][15][11][0] = 5
Maparr[3][14][12][0] = 5
Maparr[3][13][13][0] = 5

for p in range(26):
    for r in range(19):
        if r < 2:
            if p > 23 or (p >= 13 and p <= 19):
                Maparr[4][p][r][0] = 1
        elif r >= 2 and r <= 12:
            if p > 22 or (p >= 19 and p <= 20):
                Maparr[4][p][r][0] = 1
        Maparr[4][21][15][0] = 1
        Maparr[4][22][18][0] = 1

Maparr[4][20][1][0] = 5
Maparr[4][23][1][0] = 5
Maparr[4][21][5][0] = 4
Maparr[4][22][8][0] = 3
Maparr[4][21][14][0] = 5

for p in range(26):
    for r in range(19):
        if r <= 6 :
            if p <= 19 or p > 23:
                Maparr[5][p][r][0] = 1
        elif r >= 7 and r <= 8:
            if (p >= 3 and p <= 4) or p > 23:
                Maparr[5][p][r][0] = 1
                Maparr[5][24][9][0] = 1
        elif r == 10:
            if p >= 7:
                Maparr[5][p][r][0] = 1
        elif r == 11:
            if p >= 14:
                Maparr[5][p][r][0] = 1
        elif r == 12:
            if p >= 19:
                Maparr[5][p][r][0] = 1

Maparr[5][23][3][0] = 3
Maparr[5][22][3][0] = 3
Maparr[5][21][3][0] = 3
Maparr[5][23][9][0] = 5
Maparr[5][22][9][0] = 5
Maparr[5][21][9][0] = 5

for r in range(19):
    for p in range(26):
        if p < 2:
            if r <= 12:
                Maparr[6][p][r][0] = 1
        elif p <= 22:
            if r < 2:
                Maparr[6][p][r][0] = 1
        else :
            Maparr[6][p][r][0] = 1

for p in range(26):
    for r in range(7):
        Maparr[7][p][r][0] = 1
        
for r in range(19):
    for p in range(26):
        if p < 2:
            Maparr[8][p][r][0] = 1
        elif p <= 22:
            if r < 2:
                Maparr[8][p][r][0] = 1
        else :
            Maparr[8][p][r][0] = 1

for p in range(9):
    for r in range(6):
        if p <= 3 + r:
            Maparr[9][p][r][0] = 1
        if r <= 5 and p == 4:
            Maparr[9][p + r][r][0] = 4

for p in range(26):
    for r in range(7):
        if (p >= 5 and p <= 10) or p >= 17:
            Maparr[10][p][r][0] = 1
        

Maparr[0][5][6][0] = 6
Maparr[1][5][2][0] = 6
Maparr[2][9][12][0] = 6
Maparr[2][13][4][0] = 6
Maparr[3][1][6][0] = 6
Maparr[5][4][9][0] = 6
Maparr[6][1][13][0] = 6

def get_bb(stage, x , y):
    return Maparr[stage][x][y][1], Maparr[stage][x][y][2], Maparr[stage][x][y][3], Maparr[stage][x][y][4]


