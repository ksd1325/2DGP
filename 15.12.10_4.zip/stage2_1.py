

from class_file import*
from pico2d import*
from read_or_write import*
import game_framework

import block
#import fake
import morejumping
import stage1
import stage2
import stage2_1
import stage3
import stage4
import stage5
import stage6
import stage6_1
import stage7
import stage8
import stage9
import time
name = "stage2_1"

#open_canvas()

#Bulletimage = None
def update(frame_time):
    pass
def pause():
    pass
def resume():
    pass
def draw(frame_time):
    pass
def exit():
    global guy
    global dialogue
    global bullet
    global enemy
    global bar
    global map2_1
    global savezone
    global blank
    global Thorn
    global fake
    del(fake)
    del(dialogue)
    del(bullet)
    del(enemy)
    del(bar)
    del(Thorn)
    del(map2_1)
    del(savezone)
    del(blank)
    del(guy)
    pass
def enter():
    global guy
    global bar
    global font
    global blank
    global Thorn
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map2_1
    global running
    global candia

    blank = load_image('blank.png')
    line = load_image('Line.png')
    Thorn = load_image('Thorn(32x32).png')
    savezone = load_image('Save(32x32).png')
    running = True
    guy = Guy('guy_playing')
    reset_guy_playing(guy.savestage, guy.savestate, guy.savex, guy.savey)
    dialogue = Dialog()
    bar = Bar(guy.stage)
    enemy = Enemy(guy.stage)
    bullet = []
    fake_data = read_fake()
    global fake
    fake = [Fake(guy, fake_data, i + 1) for i in range(fake_data[str(guy.stage)]['count'])]

    global cansave
    cansave = False
    showboundary = 0
    candia = 0
    map2_1 = load_image('2-1.png')


    font = load_font('HYTBRB.TTF')
    main()



def morejump():
    if guy.stage == 3:
        for p in range(5):
            for q in range(4):
                if morejumping.item[p][0] == 0:
                    Itemimage.draw(morejumping.item[p][1], morejumping.item[p][2])
                elif morejumping.item[p][0] == 1:
                    morejumping.item[p][3] += 1
                    if morejumping.item[p][3] == 100:
                        morejumping.item[p][3] = 0
                        morejumping.item[p][0] = 0
                if morejumping.item[p][0] == 0 and morejumping.item[p][1] >= guy.body[0] and  morejumping.item[p][1] <= guy.body[2] and  morejumping.item[p][2] >= guy.body[3] and  morejumping.item[p][2] <= guy.body[1] :
                    morejumping.item[p][0] = 1
                    guy.ablejump = 1
    elif guy.stage == 4:
        if morejumping.item[5][0] == 0:
            Itemimage.draw(morejumping.item[5][1], morejumping.item[5][2])
        elif morejumping.item[5][0] == 1:
            morejumping.item[5][3] += 1
            if morejumping.item[5][3] == 100:
                morejumping.item[5][3] = 0
                morejumping.item[5][0] = 0
        if morejumping.item[5][0] == 0 and morejumping.item[5][1] >= guy.body[0] and  morejumping.item[5][1] <= guy.body[2] and  morejumping.item[5][2] >= guy.body[3] and  morejumping.item[5][2] <= guy.body[1] :
            morejumping.item[5][0] = 1
            guy.ablejump = 1





def handle_events(frame_time):
    global running
    global ground
    global top
    global bullet
    global showboundary
    global candia
    global cansave

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            close_canvas()
            running = False
        elif event.type == SDL_KEYDOWN and guy.state != guy.DEAD:
            if event.key == SDLK_ESCAPE:
                    close_canvas()
                    running = False
            if dialogue.dialog == 0:
                if event.key == SDLK_RIGHT:
                    guy.move = 1
                    guy.state = 1
                elif event.key == SDLK_LEFT:
                    guy.move = 2
                    guy.state = 0
                elif event.key == SDLK_UP and cansave:
                    guy.savestage = guy.stage
                    guy.savestate = guy.state
                    guy.savex = guy.x
                    guy.savey = guy.y
                    save(guy.savestage, guy.savestate, guy.savex, guy.savey)
                elif event.key == SDLK_s:
                    guy.savestage = guy.stage
                    guy.savestate = guy.state
                    guy.savex = guy.x
                    guy.savey = guy.y
                    save(guy.savestage, guy.savestate, guy.savex, guy.savey)
                elif event.key == SDLK_z:
                    bullet = bullet + [Bullet(guy.x, guy.y, guy.state, guy.stage)]
                elif event.key == SDLK_x:
                    guy.step = False
                    saveY = guy.y
                    guy.jump = True
                    guy.ablejump = guy.ablejump + 1
                    if guy.ablejump > 2:
                        guy.jump = False
                elif event.key == SDLK_b:
                    if showboundary == 0:
                        showboundary = 1
                    elif showboundary == 1:
                        showboundary = 0
                elif event.key == SDLK_p:
                    print((guy.x, guy.y))
            if candia == 1 or dialogue.dialog != 0:
                if event.key == SDLK_z:
                    dialogue.dialog += 1
                elif event.key == SDLK_x:
                    dialogue.dialog = 0

            if guy.stage == 7 or guy.stage == 8:
                if event.key == SDLK_n:
                    guy.x = 100
                    guy.y = 500
                    if guy.stage == 7 :
                        guy.stage = 8
                    elif guy.stage == 8:
                        guy.stage = 9
                
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT and guy.move == 1:
                guy.move = 0
            elif event.key == SDLK_LEFT and guy.move == 2:
                guy.move = 0
            elif event.key == SDLK_x:
                guy.jump = False
        if event.type == SDL_KEYDOWN and event.key == SDLK_r:
            load_data = load()
            if load_data == 1:
                game_framework.change_state(stage1)
            elif load_data == 2:
                game_framework.change_state(stage2)
            elif load_data == 3:
                game_framework.change_state(stage3)
            elif load_data == 4:
                game_framework.change_state(stage4)
            elif load_data == 5:
                game_framework.change_state(stage5)
            elif load_data == 6:
                game_framework.change_state(stage6)
            elif load_data == 7:
                game_framework.change_state(stage7)
            elif load_data == 8:
                game_framework.change_state(stage8)
            elif load_data == 9:
                game_framework.change_state(stage9)
            elif load_data == 10:
                game_framework.change_state(stage2_1)
            elif load_data == 11:
                game_framework.change_state(stage6_1)

def drawThorn():
    global cansave
    global guy
    for p in range(26):
        for r in range(19):
            if block.Maparr[guy.stage - 1][p][r][0] >= 2:
                Thorn.clip_draw(32 * (block.Maparr[guy.stage - 1][p][r][0] - 2), 0, 32, 32, block.Maparr[guy.stage - 1][p][r][3],  block.Maparr[guy.stage - 1][p][r][2])
            if block.Maparr[guy.stage - 1][p][r][0] == 6:
                savezone.draw(block.Maparr[guy.stage - 1][p][r][3], block.Maparr[guy.stage - 1][p][r][2])
                if savezonecrash(guy, p, r):
                    cansave = True
                else:
                    cansave = False

def savezonecrash(guy, p, r):
    if guy.body[0] > block.Maparr[guy.stage - 1][p][r][3] + 16: return False
    if guy.body[2] < block.Maparr[guy.stage - 1][p][r][1] + 16: return False
    if guy.body[1] < block.Maparr[guy.stage - 1][p][r][4] + 16: return False
    if guy.body[3] > block.Maparr[guy.stage - 1][p][r][2] + 16: return False

    return True
def main():
    global guy
    global bar
    global font
    global Boss
    global blank
    global Thorn
    global tile
    global Itemimage
    global savezone
    global bullet
    global dialogue
    global line
    global enemy
    global showboundary
    global map2_1
    global Bossframe
    global running
    global candia
    global fake



    current_time = time.clock()
    frame_time = time.clock() - current_time
    print(current_time)
    while(running):
        clear_canvas()
        current_time += frame_time

        if guy.stage == 10:
            map2_1.draw(400, 302)
            if guy.x < 0:
                write(2, 790, guy.y, guy.frame, guy.ablejump, guy.canmove, guy.state, guy.move, guy.jump, guy.height, guy.step, guy.savestage, guy.savestate, guy.savex, guy.savey)
                game_framework.change_state(stage2)
            elif guy.y < 10:
                guy.state = guy.DEAD
        drawThorn()





        if showboundary == 1 :
            for p in range(guy.rangex, guy.rangex +1):
                for q in range(guy.rangey, guy.rangey + 1):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
            for p in range(guy.rangex, guy.rangex +1):
                for q in range(guy.rangey, guy.rangey + 1):
                    if(block.Maparr[guy.stage - 1][p][q][0] == 1):
                        blank.draw(block.Maparr[guy.stage - 1][p][q][3], block.Maparr[guy.stage - 1][p][q][2])
                        draw_rectangle(block.Maparr[guy.stage - 1][p][q][1] + 16,block.Maparr[guy.stage - 1][p][q][4] + 16, block.Maparr[guy.stage - 1][p][q][3] + 16,block.Maparr[guy.stage - 1][p][q][2] + 16)



        bar.update(guy, frame_time)
        enemy.update(bullet, guy, frame_time)
        morejump()
        font.draw(10,520,'%2d' % guy.body[0])
        font.draw(10,500,'%2d' % guy.body[2])
        font.draw(10,470,'%2d' % guy.y)
        guy.update(frame_time)
        for i in fake:
            i.update(guy, fake, frame_time)
        draw_rectangle(guy.body[0], guy.body[3], guy.body[2], guy.body[1])
        if bullet != None:
            for i in bullet:
                i.update(bullet, frame_time)
        line.draw(400, 15)
        line.draw(400, 585)
        update_canvas()
        handle_events(frame_time)
        frame_time = time.clock() - current_time

    running = False


if __name__ == '__main__':
    main()

